#!/usr/bin/env node
/**
 * Procedurally composes the music bed and synthesises every ambience / SFX file
 * referenced by src/timing.ts. Output: public/audio/*.wav (44.1 kHz, 16-bit, stereo).
 *
 * The music follows the scene boundaries from timing.ts: each scene gets its own
 * chord progression, accompaniment pattern and melody, all in C major / A minor,
 * played by a soft felt-piano voice over a warm pad, with reverb.
 *
 * Deterministic: the same timing.ts always produces the same files.
 */
const path = require("path");
const {
  SR,
  TAU,
  mtof,
  mulberry32,
  stereo,
  panGains,
  whiteNoise,
  pinkNoise,
  brownNoise,
  lowpass,
  highpass,
  bandpass,
  reverb,
  fade,
  writeWav,
} = require("./lib/dsp");
const { loadTiming } = require("./lib/load-timing");

const T = loadTiming();
const OUT = path.join(__dirname, "..", "public");
const TOTAL_SECONDS = T.TOTAL_FRAMES / T.FPS;

/* ------------------------------------------------------------------ */
/* Instruments                                                         */
/* ------------------------------------------------------------------ */

const PARTIALS = [1, 0.42, 0.2, 0.11, 0.05, 0.025];

/** Soft felt piano: decaying harmonic partials, gentle hammer, equal-power pan by pitch. */
function piano([L, R], t0, midi, dur, vel, rnd) {
  const f = mtof(midi);
  const start = Math.floor(t0 * SR);
  const len = Math.floor((dur + 2.4) * SR);
  const pan = Math.min(0.85, Math.max(0.15, 0.5 + (midi - 62) / 50));
  const [gl, gr] = panGains(pan);
  const baseDecay = 0.5 + f / 1100;
  const detune = 1 + (rnd() - 0.5) * 0.0006;
  for (let i = 0; i < len; i++) {
    const idx = start + i;
    if (idx >= L.length) break;
    const t = i / SR;
    const attack = Math.min(1, t / 0.006);
    const release = t > dur ? Math.exp(-(t - dur) * 4.5) : 1;
    let s = 0;
    for (let k = 0; k < PARTIALS.length; k++) {
      const n = k + 1;
      const fk = f * n * (1 + 0.00035 * n * n) * detune;
      if (fk > SR * 0.45) break;
      s += PARTIALS[k] * Math.sin(TAU * fk * t) * Math.exp(-t * baseDecay * (1 + 0.8 * k));
    }
    const v = s * vel * attack * release;
    L[idx] += v * gl;
    R[idx] += v * gr;
  }
}

/** Warm pad: three slightly detuned sines per note, slow attack and release. */
function pad([L, R], t0, midis, dur, gain) {
  const start = Math.floor(t0 * SR);
  const attack = 1.1;
  const rel = 1.6;
  const len = Math.floor((dur + rel) * SR);
  midis.forEach((m, j) => {
    const f = mtof(m);
    const [gl, gr] = panGains(0.3 + (j / Math.max(1, midis.length - 1)) * 0.4);
    for (let i = 0; i < len; i++) {
      const idx = start + i;
      if (idx >= L.length) break;
      const t = i / SR;
      const env = Math.min(1, t / attack) * (t > dur ? Math.max(0, 1 - (t - dur) / rel) : 1);
      const trem = 1 + 0.08 * Math.sin(TAU * 0.18 * (t0 + t) + j);
      const s =
        Math.sin(TAU * f * 0.9977 * t) * 0.33 +
        Math.sin(TAU * f * t + j) * 0.34 +
        Math.sin(TAU * f * 1.0023 * t + 2 * j) * 0.33 +
        Math.sin(TAU * f * 2 * t) * 0.06;
      const v = s * env * trem * gain;
      L[idx] += v * gl;
      R[idx] += v * gr;
    }
  });
}

/* ------------------------------------------------------------------ */
/* Composition                                                         */
/* ------------------------------------------------------------------ */

const CH = {
  Fmaj7: { bass: 41, notes: [57, 60, 64] },
  Fmaj9: { bass: 41, notes: [57, 60, 64, 67] },
  CE: { bass: 40, notes: [55, 60, 64] },
  Dm7: { bass: 38, notes: [53, 57, 60] },
  Amadd9: { bass: 45, notes: [60, 64, 71] },
  C: { bass: 48, notes: [55, 60, 64] },
  GB: { bass: 47, notes: [55, 59, 62] },
  Am7: { bass: 45, notes: [55, 60, 64] },
  Cmaj7: { bass: 48, notes: [55, 59, 64] },
  Em7: { bass: 40, notes: [55, 59, 62] },
  G6: { bass: 43, notes: [59, 62, 64] },
  G: { bass: 43, notes: [59, 62, 67] },
  Cadd9: { bass: 36, notes: [55, 62, 64, 67] },
};

/**
 * Per-scene arrangement. melody entries: [chordIndex, subdivision, midi, lengthInSubdivisions].
 * weights: relative chord durations inside the scene.
 */
const ARRANGEMENT = {
  s01: {
    chords: ["Fmaj7", "CE", "Dm7", "Amadd9"],
    weights: [1, 1, 1, 1],
    sub: 4,
    pattern: "sparse",
    padGain: 0.07,
    gain: [0.8, 0.85],
    melody: [[0, 1, 76, 2], [1, 1, 74, 2], [2, 1, 72, 1], [2, 2, 69, 2], [3, 1, 71, 1.5], [3, 2.5, 72, 1.5]],
  },
  s02: {
    chords: ["C", "GB", "Am7", "Fmaj7"],
    weights: [1, 1, 1, 1],
    sub: 6,
    pattern: "broken",
    padGain: 0.06,
    gain: [0.85, 0.9],
    melody: [
      [0, 0, 76, 2], [0, 2, 74, 1], [0, 3, 72, 2], [0, 5, 74, 1],
      [1, 0, 74, 3], [1, 3, 71, 2], [1, 5, 67, 1],
      [2, 0, 72, 2], [2, 2, 76, 2], [2, 4, 69, 2],
      [3, 0, 69, 3], [3, 3, 72, 2], [3, 5, 67, 1],
    ],
  },
  s03: {
    chords: ["Am7", "Fmaj7", "Cmaj7", "Em7"],
    weights: [1, 1, 1, 1],
    sub: 4,
    pattern: "minimal",
    padGain: 0.1,
    gain: [0.75, 0.75],
    melody: [[0, 1, 76, 3], [1, 2, 72, 2], [2, 1, 71, 3], [3, 2, 67, 2]],
  },
  s04: {
    chords: ["Fmaj7", "G6", "Em7", "Am7", "Fmaj7", "G6", "Am7", "G"],
    weights: [1, 1, 1, 1, 1, 1, 1, 1],
    sub: 8,
    pattern: "arp",
    padGain: 0.075,
    gain: [0.78, 1.0],
    melody: [
      [0, 0, 72, 5], [1, 0, 74, 5], [2, 0, 71, 5], [3, 0, 76, 4], [3, 6, 74, 2],
      [4, 0, 72, 5], [5, 0, 74, 5], [6, 0, 76, 4], [6, 5, 79, 3], [7, 0, 74, 7],
    ],
  },
  s05: {
    chords: ["Fmaj9", "G", "Cadd9"],
    weights: [3, 3, 5],
    sub: 6,
    pattern: "resolve",
    padGain: 0.08,
    gain: [0.9, 0.85],
    melody: [[0, 0, 69, 2], [0, 2, 72, 2], [0, 4, 76, 2], [1, 0, 74, 3], [1, 3, 71, 3], [2, 0, 72, 6], [2, 4, 79, 6]],
  },
};

function composeMusic() {
  const rnd = mulberry32(2020);
  const length = TOTAL_SECONDS;
  const pianoBus = stereo(length);
  const padBus = stereo(length);

  T.SCENES.forEach((scene) => {
    const arr = ARRANGEMENT[scene.id];
    if (!arr) throw new Error(`No music arrangement for scene ${scene.id}`);
    const s0 = scene.from / T.FPS;
    const s1 = scene.to / T.FPS;
    const total = arr.weights.reduce((a, b) => a + b, 0);
    let t = s0;
    const chordTimes = arr.weights.map((w) => {
      const d = ((s1 - s0) * w) / total;
      const c = { start: t, dur: d };
      t += d;
      return c;
    });

    arr.chords.forEach((name, ci) => {
      const chord = CH[name];
      const { start, dur } = chordTimes[ci];
      const subLen = dur / arr.sub;
      const progress = (start - s0) / (s1 - s0);
      const g = arr.gain[0] + (arr.gain[1] - arr.gain[0]) * progress;
      const human = () => (rnd() - 0.5) * 0.02;

      pad(padBus, start, chord.notes, dur, arr.padGain * g);
      piano(pianoBus, start, chord.bass, dur * 0.9, 0.22 * g, rnd);

      switch (arr.pattern) {
        case "sparse":
          chord.notes.forEach((m, k) => piano(pianoBus, start + 0.05 + k * 0.06, m, subLen * 2, 0.12 * g, rnd));
          piano(pianoBus, start + subLen * 2 + human(), chord.notes[1] + 12, subLen * 1.5, 0.08 * g, rnd);
          break;
        case "broken":
          for (let s = 1; s < arr.sub; s++) {
            const m = chord.notes[(s - 1) % chord.notes.length];
            piano(pianoBus, start + s * subLen + human(), m, subLen * 1.6, 0.1 * g, rnd);
          }
          break;
        case "minimal":
          piano(pianoBus, start + subLen * 2 + human(), chord.notes[chord.notes.length - 1], subLen * 2, 0.08 * g, rnd);
          break;
        case "arp": {
          const seq = [chord.notes[0], chord.notes[1], chord.notes[2], chord.notes[0] + 12, chord.notes[2], chord.notes[1], chord.notes[0], chord.notes[1]];
          for (let s = 0; s < arr.sub; s++) {
            piano(pianoBus, start + s * subLen + human(), seq[s], subLen * 1.8, (s % 4 === 0 ? 0.1 : 0.075) * g, rnd);
          }
          break;
        }
        case "resolve": {
          const last = ci === arr.chords.length - 1;
          if (last) {
            chord.notes.forEach((m, k) => piano(pianoBus, start + k * 0.09, m, dur, 0.11 * g, rnd));
          } else {
            for (let s = 1; s < arr.sub; s += 1) {
              piano(pianoBus, start + s * subLen + human(), chord.notes[(s - 1) % chord.notes.length], subLen * 1.6, 0.085 * g, rnd);
            }
          }
          break;
        }
        default:
          throw new Error(`Unknown pattern ${arr.pattern}`);
      }

      arr.melody
        .filter(([c]) => c === ci)
        .forEach(([, sub, midi, subs]) => {
          piano(pianoBus, start + sub * subLen + human(), midi, subs * subLen, 0.2 * g, rnd);
        });
    });
  });

  // pad is softened, everything shares one gentle room
  const padL = lowpass(lowpass(padBus[0], 1400), 1400);
  const padR = lowpass(lowpass(padBus[1], 1400), 1400);
  const pianoL = lowpass(pianoBus[0], 4800);
  const pianoR = lowpass(pianoBus[1], 4800);
  const mixL = new Float32Array(pianoL.length);
  const mixR = new Float32Array(pianoR.length);
  for (let i = 0; i < mixL.length; i++) {
    mixL[i] = pianoL[i] + padL[i];
    mixR[i] = pianoR[i] + padR[i];
  }
  const out = reverb([mixL, mixR], { wet: 0.32, room: 0.86, damp: 0.35 });
  fade(out, 1.5, 4.5);
  return out;
}

/* ------------------------------------------------------------------ */
/* Ambience                                                            */
/* ------------------------------------------------------------------ */

const toStereo = (mono, width = 0) => {
  if (!width) return [mono, Float32Array.from(mono)];
  // cheap decorrelation: a few ms of delay on the right channel
  const d = Math.floor(width * SR);
  const r = new Float32Array(mono.length);
  for (let i = 0; i < mono.length; i++) r[i] = mono[Math.max(0, i - d)];
  return [mono, r];
};

function addChirps([L, R], seconds, rnd, { density = 1, level = 1, distance = 0.5 } = {}) {
  let t = 0.4 + rnd();
  while (t < seconds - 0.6) {
    const chirps = 2 + Math.floor(rnd() * 4);
    const base = 2600 + rnd() * 1800;
    const [gl, gr] = panGains(0.15 + rnd() * 0.7);
    for (let c = 0; c < chirps; c++) {
      const len = 0.05 + rnd() * 0.08;
      const f0 = base * (0.95 + rnd() * 0.1);
      const f1 = f0 * (1.15 + rnd() * 0.35);
      const start = Math.floor((t + c * (0.09 + rnd() * 0.06)) * SR);
      const n = Math.floor(len * SR);
      let ph = 0;
      for (let i = 0; i < n && start + i < L.length; i++) {
        const u = i / n;
        const f = f0 + (f1 - f0) * Math.sin(u * Math.PI * 0.5);
        ph += (TAU * f) / SR;
        const env = Math.pow(Math.sin(Math.PI * u), 2);
        const v = (Math.sin(ph) + 0.2 * Math.sin(2 * ph)) * env * 0.25 * level * (1 - distance * 0.6);
        L[start + i] += v * gl;
        R[start + i] += v * gr;
      }
    }
    t += (1.1 + rnd() * 2.2) / density;
  }
}

function ambCity(seconds) {
  const rnd = mulberry32(11);
  const n = Math.ceil(seconds * SR);
  const rumble = lowpass(brownNoise(n, rnd), 260);
  const hiss = bandpass(pinkNoise(n, rnd), 900, 0.6);
  const L = new Float32Array(n);
  const R = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const v = rumble[i] * 0.6 + hiss[i] * 0.12;
    L[i] = v;
    R[i] = v;
  }
  const hissR = bandpass(pinkNoise(n, rnd), 950, 0.6);
  for (let i = 0; i < n; i++) R[i] = R[i] - hiss[i] * 0.12 + hissR[i] * 0.12;
  // passing vehicles: filtered noise swells panning across
  let t = 0.3;
  while (t < seconds) {
    const dur = 2.2 + rnd() * 1.6;
    const dir = rnd() > 0.5 ? 1 : -1;
    const level = 0.25 + rnd() * 0.25;
    const len = Math.floor(dur * SR);
    const src = bandpass(pinkNoise(len, rnd), (u) => 520 - (u / dur) * 180, 1.2);
    const start = Math.floor(t * SR);
    for (let i = 0; i < len && start + i < n; i++) {
      const u = i / len;
      const env = Math.exp(-Math.pow((u - 0.5) * 3.2, 2));
      const pan = dir > 0 ? u : 1 - u;
      const [gl, gr] = panGains(pan);
      L[start + i] += src[i] * env * level * gl;
      R[start + i] += src[i] * env * level * gr;
    }
    t += 1.4 + rnd() * 2.2;
  }
  addChirps([L, R], seconds, rnd, { density: 0.5, level: 0.35, distance: 0.8 });
  fade([L, R], 0.5, 0.5);
  return [L, R];
}

function ambWind(seconds) {
  const rnd = mulberry32(22);
  const n = Math.ceil(seconds * SR);
  const make = (seed) => {
    const r = mulberry32(seed);
    const src = pinkNoise(n, r);
    const swept = bandpass(src, (t) => 380 + 220 * Math.sin(TAU * 0.07 * t + seed) + 120 * Math.sin(TAU * 0.19 * t), 0.7);
    const out = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      const t = i / SR;
      const gust = 0.55 + 0.3 * Math.sin(TAU * 0.11 * t + seed) + 0.15 * Math.sin(TAU * 0.31 * t + 2 * seed);
      out[i] = swept[i] * gust;
    }
    return lowpass(out, 2200);
  };
  const L = make(1);
  const R = make(2);
  const leaves = highpass(whiteNoise(n, rnd), 2500);
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    const rustle = Math.max(0, Math.sin(TAU * 0.11 * t + 1) - 0.4) * 0.05;
    L[i] += leaves[i] * rustle;
    R[i] += leaves[(i + 400) % n] * rustle;
  }
  addChirps([L, R], seconds, rnd, { density: 0.35, level: 0.25, distance: 0.9 });
  fade([L, R], 0.8, 0.8);
  return [L, R];
}

function ambRoom(seconds) {
  const rnd = mulberry32(33);
  const n = Math.ceil(seconds * SR);
  const tone = lowpass(lowpass(brownNoise(n, rnd), 180), 180);
  const air = bandpass(pinkNoise(n, rnd), 1800, 0.5);
  const L = new Float32Array(n);
  for (let i = 0; i < n; i++) L[i] = tone[i] * 0.8 + air[i] * 0.04;
  const out = toStereo(L, 0.011);
  addChirps(out, seconds, rnd, { density: 0.25, level: 0.12, distance: 0.95 });
  fade(out, 0.5, 0.5);
  return out;
}

function ambBirds(seconds) {
  const rnd = mulberry32(44);
  const n = Math.ceil(seconds * SR);
  const bed = lowpass(pinkNoise(n, rnd), 500);
  const L = new Float32Array(n);
  const R = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    L[i] = bed[i] * 0.05;
    R[i] = bed[(i + 600) % n] * 0.05;
  }
  addChirps([L, R], seconds, rnd, { density: 1.3, level: 1, distance: 0.3 });
  const out = reverb([L, R], { wet: 0.35, room: 0.8, damp: 0.4 });
  fade(out, 0.6, 0.6);
  return out;
}

/* ------------------------------------------------------------------ */
/* One-shot SFX                                                        */
/* ------------------------------------------------------------------ */

function bell([L, R], t0, midi, level, decay = 2.6, partials = [1, 2.0, 3.01, 4.2]) {
  const f = mtof(midi);
  const start = Math.floor(t0 * SR);
  const len = Math.floor(3 * SR);
  const amps = [1, 0.35, 0.12, 0.05];
  for (let i = 0; i < len && start + i < L.length; i++) {
    const t = i / SR;
    let s = 0;
    partials.forEach((p, k) => {
      s += amps[k] * Math.sin(TAU * f * p * t) * Math.exp(-t * decay * (1 + k * 0.9));
    });
    const v = s * level * Math.min(1, t / 0.004);
    L[start + i] += v;
    R[start + i] += v;
  }
}

function newsChime() {
  const out = stereo(2.6);
  bell(out, 0.0, 79, 0.5);
  bell(out, 0.16, 84, 0.45);
  bell(out, 0.32, 88, 0.4);
  bell(out, 0.62, 72, 0.25, 1.6);
  bell(out, 0.62, 79, 0.2, 1.6);
  const r = reverb(out, { wet: 0.4 });
  fade(r, 0, 0.3);
  return r;
}

function notification() {
  const out = stereo(1.0);
  bell(out, 0, 81, 0.6, 8, [1, 4.0, 2.0, 6.0]);
  bell(out, 0.11, 88, 0.55, 8, [1, 4.0, 2.0, 6.0]);
  const r = reverb(out, { wet: 0.25 });
  fade(r, 0, 0.2);
  return r;
}

function burst([L, R], t0, seconds, rnd, { lp = 6000, hp = 200, level = 1, decay = 60, pan = 0.5 } = {}) {
  const n = Math.floor(seconds * SR);
  let src = whiteNoise(n, rnd);
  if (hp) src = highpass(src, hp);
  if (lp) src = lowpass(src, lp);
  const start = Math.floor(t0 * SR);
  const [gl, gr] = panGains(pan);
  for (let i = 0; i < n && start + i < L.length; i++) {
    const t = i / SR;
    const v = src[i] * Math.exp(-t * decay) * Math.min(1, t / 0.001) * level;
    L[start + i] += v * gl;
    R[start + i] += v * gr;
  }
}

function tone([L, R], t0, freq, seconds, level, decay) {
  const n = Math.floor(seconds * SR);
  const start = Math.floor(t0 * SR);
  for (let i = 0; i < n && start + i < L.length; i++) {
    const t = i / SR;
    const v = Math.sin(TAU * freq * t) * Math.exp(-t * decay) * Math.min(1, t / 0.002) * level;
    L[start + i] += v;
    R[start + i] += v;
  }
}

function keyboard(seconds) {
  const rnd = mulberry32(55);
  const out = stereo(seconds);
  let t = 0.08;
  let count = 0;
  while (t < seconds - 0.15) {
    const space = count % 6 === 5;
    burst(out, t, 0.03, rnd, { hp: space ? 600 : 1800, lp: space ? 3000 : 6500, level: 0.5 + rnd() * 0.3, decay: space ? 140 : 260, pan: 0.42 + rnd() * 0.16 });
    tone(out, t, space ? 130 : 210 + rnd() * 40, 0.05, space ? 0.25 : 0.12, 70);
    count++;
    t += 0.085 + rnd() * 0.11 + (rnd() < 0.08 ? 0.35 : 0);
  }
  const r = reverb(out, { wet: 0.12 });
  fade(r, 0.02, 0.2);
  return r;
}

function clockTick(seconds) {
  const rnd = mulberry32(66);
  const out = stereo(seconds);
  for (let k = 0; k * 0.5 < seconds - 0.1; k++) {
    const t = 0.05 + k * 0.5;
    const tock = k % 2 === 1;
    burst(out, t, 0.01, rnd, { hp: 1500, lp: 5000, level: 0.35, decay: 500 });
    tone(out, t, tock ? 1900 : 2400, 0.04, 0.22, 140);
  }
  const r = reverb(out, { wet: 0.2 });
  fade(r, 0.05, 0.3);
  return r;
}

function pageFlip() {
  const rnd = mulberry32(77);
  const seconds = 0.6;
  const n = Math.ceil(seconds * SR);
  const src = bandpass(pinkNoise(n, rnd), (t) => 900 + (t / seconds) * 2800, 0.9);
  const L = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    const env = Math.min(1, t / 0.03) * Math.exp(-t * 7);
    const flutter = 0.7 + 0.3 * Math.sin(TAU * 34 * t) * Math.exp(-t * 5);
    L[i] = src[i] * env * flutter;
  }
  const out = toStereo(L, 0.004);
  return reverb(out, { wet: 0.15 });
}

function footsteps(seconds) {
  const rnd = mulberry32(88);
  const out = stereo(seconds);
  for (let k = 0; 0.1 + k * 0.42 < seconds - 0.2; k++) {
    const t = 0.1 + k * 0.42 + (rnd() - 0.5) * 0.02;
    const pan = k % 2 ? 0.44 : 0.56;
    burst(out, t, 0.08, rnd, { hp: 60, lp: 420, level: 0.9, decay: 45, pan });
    tone(out, t, 70 + rnd() * 10, 0.06, 0.35, 60);
    burst(out, t + 0.035, 0.05, rnd, { hp: 1800, lp: 5000, level: 0.12, decay: 80, pan });
  }
  const r = reverb(out, { wet: 0.12 });
  fade(r, 0.05, 0.3);
  return r;
}

function door() {
  const rnd = mulberry32(99);
  const out = stereo(1.6);
  burst(out, 0.04, 0.03, rnd, { hp: 1500, lp: 5000, level: 0.35, decay: 200 });
  // soft air movement as the door swings
  const swing = lowpass(pinkNoise(Math.floor(0.6 * SR), rnd), 400);
  const s0 = Math.floor(0.1 * SR);
  for (let i = 0; i < swing.length; i++) {
    const u = i / swing.length;
    const v = swing[i] * Math.sin(Math.PI * u) * 0.5;
    out[0][s0 + i] += v;
    out[1][s0 + i] += v;
  }
  burst(out, 0.72, 0.15, rnd, { hp: 40, lp: 300, level: 1, decay: 25 });
  tone(out, 0.72, 62, 0.15, 0.5, 30);
  burst(out, 0.78, 0.03, rnd, { hp: 1800, lp: 6000, level: 0.3, decay: 220 });
  const r = reverb(out, { wet: 0.25 });
  fade(r, 0.01, 0.3);
  return r;
}

function whooshSoft() {
  const rnd = mulberry32(111);
  const seconds = 1.4;
  const n = Math.ceil(seconds * SR);
  const src = bandpass(pinkNoise(n, rnd), (t) => 300 + 900 * Math.sin((Math.PI * t) / seconds), 1.1);
  const L = new Float32Array(n);
  const R = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const u = i / n;
    const env = Math.pow(Math.sin(Math.PI * u), 2);
    const [gl, gr] = panGains(0.3 + u * 0.4);
    L[i] = src[i] * env * gl;
    R[i] = src[i] * env * gr;
  }
  return reverb([L, R], { wet: 0.3 });
}

function leaves(seconds) {
  const rnd = mulberry32(122);
  const n = Math.ceil(seconds * SR);
  const src = lowpass(highpass(whiteNoise(n, rnd), 1500), 6500);
  const L = new Float32Array(n);
  const R = new Float32Array(n);
  let grain = 0;
  let gl = 0.5;
  let gr = 0.5;
  for (let i = 0; i < n; i++) {
    if (i % 900 === 0) {
      grain = rnd() < 0.55 ? rnd() : 0;
      [gl, gr] = panGains(0.2 + rnd() * 0.6);
    }
    const u = i / n;
    const env = Math.sin(Math.PI * u);
    L[i] = src[i] * grain * env * gl;
    R[i] = src[i] * grain * env * gr;
  }
  const out = [lowpass(L, 5000), lowpass(R, 5000)];
  return reverb(out, { wet: 0.25 });
}

/* ------------------------------------------------------------------ */
/* Durations come from timing.ts so every cue is long enough            */
/* ------------------------------------------------------------------ */

function requiredSeconds(file, fallback) {
  let frames = 0;
  T.SCENES.forEach((scene) => {
    scene.ambience.filter((a) => a.file === file).forEach((a) => (frames = Math.max(frames, a.to - a.from)));
    scene.sfx.filter((s) => s.file === file && s.duration).forEach((s) => (frames = Math.max(frames, s.duration)));
  });
  return Math.max(fallback, frames / T.FPS + 0.5);
}

const JOBS = [
  ["audio/background.wav", () => composeMusic(), 0.8],
  ["audio/sfx/amb-city.wav", () => ambCity(requiredSeconds("audio/sfx/amb-city.wav", 6)), 0.6],
  ["audio/sfx/amb-wind.wav", () => ambWind(requiredSeconds("audio/sfx/amb-wind.wav", 6)), 0.6],
  ["audio/sfx/amb-room.wav", () => ambRoom(requiredSeconds("audio/sfx/amb-room.wav", 6)), 0.45],
  ["audio/sfx/amb-birds.wav", () => ambBirds(requiredSeconds("audio/sfx/amb-birds.wav", 6)), 0.6],
  ["audio/sfx/news-chime.wav", () => newsChime(), 0.7],
  ["audio/sfx/notification.wav", () => notification(), 0.7],
  ["audio/sfx/keyboard.wav", () => keyboard(3.2), 0.6],
  ["audio/sfx/clock-tick.wav", () => clockTick(requiredSeconds("audio/sfx/clock-tick.wav", 4)), 0.6],
  ["audio/sfx/page-flip.wav", () => pageFlip(), 0.65],
  ["audio/sfx/footsteps.wav", () => footsteps(3.4), 0.6],
  ["audio/sfx/door.wav", () => door(), 0.65],
  ["audio/sfx/whoosh-soft.wav", () => whooshSoft(), 0.6],
  ["audio/sfx/leaves.wav", () => leaves(4), 0.55],
];

// Fail early if timing.ts references a file this script does not generate.
const generated = new Set(JOBS.map(([f]) => f));
const referenced = new Set([T.MUSIC.file]);
T.SCENES.forEach((s) => {
  s.ambience.forEach((a) => referenced.add(a.file));
  s.sfx.forEach((x) => referenced.add(x.file));
});
const missing = [...referenced].filter((f) => !generated.has(f));
if (missing.length) {
  console.error(`timing.ts references audio this script does not generate:\n  ${missing.join("\n  ")}`);
  process.exit(1);
}

const t0 = Date.now();
for (const [file, make, peak] of JOBS) {
  const channels = make();
  const info = writeWav(path.join(OUT, file), channels, peak);
  console.log(`  ${file.padEnd(32)} ${info.seconds.toFixed(2).padStart(6)} s`);
}
console.log(`Audio generated in ${((Date.now() - t0) / 1000).toFixed(1)} s -> public/audio/`);
