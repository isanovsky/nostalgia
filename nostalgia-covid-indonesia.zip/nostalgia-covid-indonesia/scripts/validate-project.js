#!/usr/bin/env node
/**
 * Static project validation - no rendering, no preview frames.
 * Run through `npm run validate`, which runs `tsc --noEmit` first.
 */
const fs = require("fs");
const path = require("path");
const ts = require("typescript");
const { loadTiming } = require("./lib/load-timing");

const ROOT = path.join(__dirname, "..");
const SRC = path.join(ROOT, "src");
const PUBLIC = path.join(ROOT, "public");

const errors = [];
const passes = [];
const check = (label, ok, detail) => {
  if (ok) passes.push(label);
  else errors.push(`${label}${detail ? `: ${detail}` : ""}`);
};

/* ---------- load timing.ts and theme.ts ---------- */

const T = loadTiming();

const loadTheme = () => {
  const source = fs.readFileSync(path.join(SRC, "theme.ts"), "utf8");
  const { outputText } = ts.transpileModule(source, {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 },
  });
  const mod = { exports: {} };
  const shim = (name) => {
    if (name === "remotion") return { interpolateColors: () => "#000000" };
    throw new Error(`theme.ts imports unexpected module ${name}`);
  };
  new Function("module", "exports", "require", outputText)(mod, mod.exports, shim);
  return mod.exports;
};
const THEME = loadTheme();

/* ---------- WAV inspection ---------- */

const wavInfo = (rel) => {
  const file = path.join(PUBLIC, rel);
  if (!fs.existsSync(file)) return null;
  const b = fs.readFileSync(file);
  if (b.toString("ascii", 0, 4) !== "RIFF" || b.toString("ascii", 8, 12) !== "WAVE") return { error: "not a RIFF/WAVE file" };
  const format = b.readUInt16LE(20);
  const channels = b.readUInt16LE(22);
  const sampleRate = b.readUInt32LE(24);
  const bits = b.readUInt16LE(34);
  const dataLen = b.readUInt32LE(40);
  const frames = dataLen / (channels * (bits / 8));
  let peak = 0;
  let sumSq = 0;
  for (let o = 44; o + 1 < b.length; o += 2) {
    const v = Math.abs(b.readInt16LE(o)) / 32768;
    peak = Math.max(peak, v);
    sumSq += v * v;
  }
  const rms = Math.sqrt(sumSq / ((b.length - 44) / 2));
  return { format, channels, sampleRate, bits, seconds: frames / sampleRate, peak, rms };
};

/* ---------- 1. composition spec ---------- */

check("FPS is 30", T.FPS === 30, `got ${T.FPS}`);
check("Resolution is 1080x1920", T.WIDTH === 1080 && T.HEIGHT === 1920, `got ${T.WIDTH}x${T.HEIGHT}`);
const totalSec = T.TOTAL_FRAMES / T.FPS;
check("Total duration is about 60 s (55-65 s)", totalSec >= 55 && totalSec <= 65, `got ${totalSec.toFixed(2)} s`);

/* ---------- 2. scene timeline ---------- */

const scenes = T.SCENES;
check("Five scenes defined", scenes.length === 5, `got ${scenes.length}`);
check("First scene starts at frame 0", scenes[0].from === 0, `starts at ${scenes[0].from}`);
check("Last scene ends at TOTAL_FRAMES", scenes[scenes.length - 1].to === T.TOTAL_FRAMES);
check("Scene ids are unique", new Set(scenes.map((s) => s.id)).size === scenes.length);

const SAFE = T.SAFE_AREA;
const SAFE_W = SAFE.right - SAFE.left;

/** Greedy word-wrap estimate of a text block's size. */
const textBlock = (cue) => {
  const style = THEME.TYPE[cue.variant];
  if (!style) return { error: `unknown variant ${cue.variant}` };
  const factor = style.weight >= 800 ? 0.64 : style.weight >= 600 ? 0.58 : 0.54;
  const padX = cue.variant === "banner" ? 30 * 2 + 12 : 0;
  const padY = cue.variant === "banner" ? 22 * 2 : 0;
  const maxW = SAFE_W - padX;
  const width = (s) => s.length * style.size * factor + Math.max(0, s.length - 1) * style.letterSpacing;
  const words = cue.text.split(/\s+/);
  let lines = 1;
  let line = "";
  let widest = 0;
  for (const w of words) {
    if (width(w) > maxW) return { error: `word "${w}" is wider than the safe area` };
    const candidate = line ? `${line} ${w}` : w;
    if (width(candidate) > maxW) {
      lines++;
      widest = Math.max(widest, width(line));
      line = w;
    } else line = candidate;
  }
  widest = Math.max(widest, width(line));
  return { lines, width: widest + padX, height: lines * style.size * 1.15 + padY };
};

scenes.forEach((scene, i) => {
  const dur = scene.to - scene.from;
  const tag = `[${scene.id}]`;
  const isLast = i === scenes.length - 1;
  const tail = isLast ? 0 : T.TRANSITION_FRAMES;
  check(`${tag} start < end`, scene.from < scene.to, `${scene.from} >= ${scene.to}`);
  if (!isLast) {
    check(`${tag} is contiguous with ${scenes[i + 1].id} (no gap / overlap)`, scene.to === scenes[i + 1].from, `${scene.to} vs ${scenes[i + 1].from}`);
  }
  check(`${tag} has description, mood and title`, Boolean(scene.description && scene.mood && scene.title));
  check(`${tag} longer than its transition`, dur > T.TRANSITION_FRAMES * 2);

  // shots
  const shots = scene.shots;
  check(`${tag} has shots`, shots.length > 0);
  check(`${tag} shot ids unique`, new Set(shots.map((s) => s.id)).size === shots.length);
  check(`${tag} first shot starts at 0`, shots[0].from === 0, `starts at ${shots[0].from}`);
  check(`${tag} last shot ends at scene end`, shots[shots.length - 1].to === dur, `ends at ${shots[shots.length - 1].to}, scene is ${dur}`);
  shots.forEach((shot, k) => {
    check(`${tag} shot ${shot.id} start < end`, shot.from < shot.to);
    if (k < shots.length - 1) check(`${tag} shot ${shot.id} contiguous`, shot.to === shots[k + 1].from, `${shot.to} vs ${shots[k + 1].from}`);
  });

  // beats
  Object.entries(scene.beats).forEach(([name, f]) => {
    check(`${tag} beat ${name} within scene`, Number.isFinite(f) && f >= 0 && f <= dur, `${f} not in [0, ${dur}]`);
  });

  // texts
  const blocks = [];
  scene.texts.forEach((cue) => {
    const label = `${tag} text "${cue.id}"`;
    check(`${label} start < end`, cue.from < cue.to);
    check(`${label} inside scene`, cue.from >= 0 && cue.to <= dur, `${cue.from}-${cue.to} vs ${dur}`);
    check(`${label} readable for >= 1.5 s`, cue.to - cue.from >= 45, `${cue.to - cue.from} frames`);
    const b = textBlock(cue);
    if (b.error) {
      check(`${label} fits safe area`, false, b.error);
      return;
    }
    check(`${label} top inside safe area`, cue.y >= SAFE.top, `y=${cue.y} < ${SAFE.top}`);
    check(`${label} bottom inside safe area`, cue.y + b.height <= SAFE.bottom, `bottom~${Math.round(cue.y + b.height)} > ${SAFE.bottom}`);
    check(`${label} at most 3 lines`, b.lines <= 3, `${b.lines} lines`);
    blocks.push({ cue, top: cue.y, bottom: cue.y + b.height });
  });
  for (let a = 0; a < blocks.length; a++) {
    for (let c = a + 1; c < blocks.length; c++) {
      const A = blocks[a];
      const B = blocks[c];
      const timeOverlap = A.cue.from < B.cue.to && B.cue.from < A.cue.to;
      const spaceOverlap = A.top < B.bottom && B.top < A.bottom;
      check(`${tag} texts "${A.cue.id}" and "${B.cue.id}" do not collide`, !(timeOverlap && spaceOverlap));
    }
  }

  // audio cues
  scene.sfx.forEach((cue) => {
    const label = `${tag} sfx "${cue.id}"`;
    check(`${label} within scene`, cue.at >= 0 && cue.at < dur + tail, `at ${cue.at}`);
    check(`${label} volume in (0, 1]`, cue.volume > 0 && cue.volume <= 1);
    const info = wavInfo(cue.file);
    check(`${label} file exists (${cue.file})`, Boolean(info));
    if (info && cue.duration) {
      check(`${label} file long enough`, info.seconds >= cue.duration / T.FPS, `${info.seconds.toFixed(2)} s < ${(cue.duration / T.FPS).toFixed(2)} s`);
    }
  });
  scene.ambience.forEach((cue) => {
    const label = `${tag} ambience "${cue.id}"`;
    const len = cue.to - cue.from;
    check(`${label} start < end`, cue.from < cue.to);
    check(`${label} within scene (+transition)`, cue.from >= 0 && cue.to <= dur + tail, `${cue.from}-${cue.to}`);
    check(`${label} fades fit`, cue.fadeIn > 0 && cue.fadeOut > 0 && cue.fadeIn + cue.fadeOut < len);
    check(`${label} volume in (0, 1]`, cue.volume > 0 && cue.volume <= 1);
    const info = wavInfo(cue.file);
    check(`${label} file exists (${cue.file})`, Boolean(info));
    if (info) check(`${label} file long enough`, info.seconds >= len / T.FPS, `${info.seconds.toFixed(2)} s < ${(len / T.FPS).toFixed(2)} s`);
  });
});

/* ---------- 3. audio files ---------- */

const music = wavInfo(T.MUSIC.file);
check(`Music file exists (${T.MUSIC.file})`, Boolean(music));
if (music) check("Music covers the whole composition", music.seconds >= totalSec - 0.05, `${music.seconds.toFixed(2)} s`);

const audioDir = path.join(PUBLIC, "audio");
const walk = (dir) =>
  fs.existsSync(dir)
    ? fs.readdirSync(dir, { withFileTypes: true }).flatMap((d) => (d.isDirectory() ? walk(path.join(dir, d.name)) : [path.join(dir, d.name)]))
    : [];
const wavs = walk(audioDir).filter((f) => f.endsWith(".wav"));
check("Audio folder contains WAV files (run npm run generate:audio)", wavs.length > 0);
const referencedAudio = new Set([T.MUSIC.file, ...scenes.flatMap((s) => [...s.sfx.map((x) => x.file), ...s.ambience.map((x) => x.file)])]);
wavs.forEach((abs) => {
  const rel = path.relative(PUBLIC, abs).split(path.sep).join("/");
  const info = wavInfo(rel);
  check(`${rel} is 16-bit PCM 44.1 kHz`, info && !info.error && info.format === 1 && info.bits === 16 && info.sampleRate === 44100, info && info.error);
  if (info && !info.error) {
    check(`${rel} does not clip (peak < 0.99)`, info.peak < 0.99, `peak ${info.peak.toFixed(3)}`);
    check(`${rel} is not silent`, info.rms > 0.001, `rms ${info.rms}`);
  }
  check(`${rel} is referenced by timing.ts`, referencedAudio.has(rel));
});

/* ---------- 4. source files: imports, assets, placeholders ---------- */

const srcFiles = walk(SRC).filter((f) => /\.(ts|tsx)$/.test(f));
const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, "package.json"), "utf8"));
const deps = Object.keys(pkg.dependencies || {});
const devDeps = Object.keys(pkg.devDependencies || {});
const usedPackages = new Set();

const resolveRelative = (from, spec) => {
  const base = path.resolve(path.dirname(from), spec);
  return [base, `${base}.ts`, `${base}.tsx`, path.join(base, "index.ts"), path.join(base, "index.tsx")].find(
    (p) => fs.existsSync(p) && fs.statSync(p).isFile(),
  );
};
const pkgName = (spec) => (spec.startsWith("@") ? spec.split("/").slice(0, 2).join("/") : spec.split("/")[0]);

const PLACEHOLDER = /\b(TODO|FIXME|XXX|not implemented|lorem ipsum)\b/i;

srcFiles.forEach((file) => {
  const rel = path.relative(ROOT, file);
  const code = fs.readFileSync(file, "utf8");
  const imports = [...code.matchAll(/(?:import|export)\s[^'"]*?from\s+["']([^"']+)["']|import\s+["']([^"']+)["']/g)].map((m) => m[1] || m[2]);
  imports.forEach((spec) => {
    if (spec.startsWith(".")) {
      check(`${rel} import "${spec}" resolves`, Boolean(resolveRelative(file, spec)));
    } else {
      const name = pkgName(spec);
      usedPackages.add(name);
      check(`${rel} import "${spec}" is a declared dependency`, deps.includes(name) || devDeps.includes(name));
    }
  });
  [...code.matchAll(/staticFile\(\s*["'`]([^"'`$]+)["'`]\s*\)/g)].forEach((m) => {
    check(`${rel} staticFile("${m[1]}") exists`, fs.existsSync(path.join(PUBLIC, m[1])));
  });
  check(`${rel} has no placeholders`, !PLACEHOLDER.test(code));
});

THEME.FONT_FILES.forEach((font) => check(`Font file ${font.file} exists`, fs.existsSync(path.join(PUBLIC, font.file))));

scripts: {
  const scriptFiles = walk(path.join(ROOT, "scripts")).filter((f) => f.endsWith(".js"));
  scriptFiles.forEach((file) => {
    const code = fs.readFileSync(file, "utf8");
    [...code.matchAll(/require\(\s*["']([^"']+)["']\s*\)/g)].forEach((m) => {
      if (!m[1].startsWith(".") && !["fs", "path"].includes(m[1])) usedPackages.add(pkgName(m[1]));
      if (m[1].startsWith(".")) {
        check(`${path.relative(ROOT, file)} require "${m[1]}" resolves`, fs.existsSync(path.resolve(path.dirname(file), `${m[1]}.js`)) || fs.existsSync(path.resolve(path.dirname(file), m[1])));
      }
    });
    check(`${path.relative(ROOT, file)} has no placeholders`, !PLACEHOLDER.test(code.replace(/PLACEHOLDER = .*\n/, "")));
  });
}

/* ---------- 5. dependencies ---------- */

const configCode = fs.existsSync(path.join(ROOT, "remotion.config.ts")) ? fs.readFileSync(path.join(ROOT, "remotion.config.ts"), "utf8") : "";
if (configCode.includes("@remotion/cli")) usedPackages.add("@remotion/cli");
const scriptsText = Object.values(pkg.scripts || {}).join(" ");
deps.forEach((d) => {
  const viaCli = d === "@remotion/cli" && /\bremotion\s/.test(scriptsText);
  check(`Dependency ${d} is used`, usedPackages.has(d) || viaCli || d === "react-dom");
});
check("typescript is available for validation", devDeps.includes("typescript"));

/* ---------- 6. wiring ---------- */

["generate:audio", "validate", "render"].forEach((s) => check(`package.json has "${s}" script`, Boolean(pkg.scripts && pkg.scripts[s])));
check("render script targets the composition id", (pkg.scripts.render || "").includes(T.COMPOSITION_ID));

const rootCode = fs.readFileSync(path.join(SRC, "Root.tsx"), "utf8");
["fps={FPS}", "width={WIDTH}", "height={HEIGHT}", "durationInFrames={TOTAL_FRAMES}", "id={COMPOSITION_ID}"].forEach((needle) =>
  check(`Root.tsx uses ${needle}`, rootCode.includes(needle)),
);
const videoCode = fs.readFileSync(path.join(SRC, "Video.tsx"), "utf8");
scenes.forEach((scene) => {
  const n = scene.id.replace("s", "");
  const comp = `Scene${n}`;
  check(`Scene component ${comp}.tsx exists`, fs.existsSync(path.join(SRC, "scenes", `${comp}.tsx`)));
  check(`${comp} is registered in Video.tsx`, new RegExp(`${scene.id}:\\s*${comp}`).test(videoCode));
  const sceneCode = fs.existsSync(path.join(SRC, "scenes", `${comp}.tsx`)) ? fs.readFileSync(path.join(SRC, "scenes", `${comp}.tsx`), "utf8") : "";
  check(`${comp} reads its timeline from timing.ts`, sceneCode.includes(`getScene("${scene.id}")`));
});

/* ---------- 7. timeline lookups used by components resolve ---------- */

const sceneById = Object.fromEntries(scenes.map((s) => [s.id, s]));
const lookupTable = (scene, kind) =>
  kind === "Beat" ? Object.keys(scene.beats) : kind === "Ui" ? Object.keys(scene.ui) : scene.shots.map((s) => s.id);
srcFiles.forEach((file) => {
  const rel = path.relative(ROOT, file);
  const code = fs.readFileSync(file, "utf8");
  const vars = Object.fromEntries([...code.matchAll(/const\s+(\w+)\s*=\s*getScene\("(s\d\d)"\)/g)].map((m) => [m[1], m[2]]));
  const resolveScene = (expr) => {
    const direct = /getScene\("(s\d\d)"\)/.exec(expr);
    return direct ? direct[1] : vars[expr];
  };
  const verify = (kind, sceneExpr, key) => {
    const id = resolveScene(sceneExpr);
    if (!id) return;
    const scene = sceneById[id];
    check(`${rel} get${kind}(${id}, "${key}") exists in timing.ts`, Boolean(scene) && lookupTable(scene, kind).includes(key));
  };
  [...code.matchAll(/get(Beat|Ui|Shot)\(\s*(getScene\("s\d\d"\)|\w+)\s*,\s*"([^"]+)"\s*\)/g)].forEach((m) => verify(m[1], m[2], m[3]));
  [...code.matchAll(/\[([^\]]+)\]\.map\(\((\w+)\)\s*=>\s*get(Beat|Ui|Shot)\((\w+),\s*\2\)\)/g)].forEach((m) => {
    [...m[1].matchAll(/"([^"]+)"/g)].forEach((k) => verify(m[3], m[4], k[1]));
  });
  if (/getShot\(scene,\s*shotId\)/.test(code)) {
    [...code.matchAll(/shotId="([^"]+)"/g)].forEach((m) => verify("Shot", "scene", m[1]));
  }
});

/* ---------- report ---------- */

console.log(`\nValidation: ${passes.length} checks passed, ${errors.length} failed.`);
if (errors.length) {
  console.error("\nFailures:");
  errors.forEach((e) => console.error(`  x ${e}`));
  process.exit(1);
}
console.log("All checks passed.");
