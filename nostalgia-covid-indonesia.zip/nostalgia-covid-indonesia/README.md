# Dari 2 Minggu Menjadi 2 Tahun

**AI Animated Nostalgia #01: Kisah nostalgia COVID-19 di Indonesia (2020–2022)**

Nama proyek dan ID komposisi tetap `TwoWeeksToTwoYears` agar perintah render tidak berubah.

Video pendek vertikal tanpa voice-over, dibangun dengan Remotion (React + TypeScript + SVG). Cerita disampaikan lewat visual, teks di layar, notifikasi, perubahan lingkungan, musik, dan efek suara.

| Spesifikasi | Nilai |
|---|---|
| Resolusi | 1080 × 1920 (9:16) |
| Frame rate | 30 fps |
| Durasi | 1800 frame = 60,00 detik |
| Composition ID | `TwoWeeksToTwoYears` |
| Gaya visual | Stylized 3D / isometric low-poly, dibuat dengan SVG (tanpa WebGL) |
| Audio | Musik + ambience + SFX, semuanya disintesis oleh `scripts/generate-audio.js` |

---

## 1. Ringkasan cerita

| Scene | Waktu | Isi | Mood |
|---|---|---|---|
| 01 Pengumuman Pertama | 0–10 s | Kota ramai dari udara (permukiman membentang dari tepi kiri ke kanan, dua jembatan di atas sungai), lalu kamera turun ke rumah beratap pink. Raka bersantai di sofa, kemudian TV menampilkan "BERITA TERKINI: 2 KASUS PERTAMA COVID-19" (2 Maret 2020). | Normal, sedikit cemas |
| 02 Hanya Dua Minggu? | 10–23 s | Raka (bermasker) membawa laptop pulang, Dinda membawa buku. Di ponsel muncul notifikasi Grup Kantor, Grup Kelas, dan YouTube ("Cara mengubah kuota edukasi menjadi kuota utama"). Kelas mulai kosong. Raka bekerja dari rumah, kalender 16–29 Maret dilingkari, dan TV memberitakan "KASUS COVID-19 MENINGKAT LAGI". "14 HARI SAJA?" | Santai, optimis |
| 03 Kota yang Sepi | 23–35 s | Kota yang sama dengan sudut kamera Scene 01 berubah dari ramai menjadi sepi (match cut). "KURANGI AKTIVITAS DI LUAR RUMAH", "PAKAI MASKER", "PSBB · 10 April 2020 · Jakarta". | Tenang, melankolis |
| 04 Dua Minggu Menjadi Dua Tahun | 35–49 s | Time-lapse di ruangan yang sama: kalender MARET 2020 → APRIL → JUNI → DESEMBER 2020 → 2021 → 2022. "2 MINGGU..." → "+ 2 MINGGU LAGI..." → "2 TAHUN." | Waktu berlalu, reflektif |
| 05 Apakah Kehidupan Berhenti? | 49–60 s | Kota hidup kembali dalam cahaya hangat. Penutup: "APAKAH KEHIDUPAN BERHENTI DI TAHUN 2020?", "DARI 2 MINGGU MENJADI 2 TAHUN", dan "Terima kasih para nakes, pahlawan sejati di garda terdepan pandemi." | Penuh harapan, nostalgia |

Seluruh teks di layar dan teks diegetik (TV, ponsel, kalender, papan nama) berbahasa Indonesia.

### Catatan akurasi sejarah

- Tanggal yang ditampilkan (2 Maret 2020, 15 Maret 2020, 10 April 2020 untuk PSBB di Jakarta) berasal dari brief proyek. Tanggal-tanggal ini **tidak diverifikasi ulang** terhadap sumber primer. Periksa sumber resmi sebelum publikasi.
- **Kemungkinan anakronisme (perlu dicek):** program bantuan kuota data internet untuk pendidikan ("kuota edukasi") setahu saya baru berjalan sekitar paruh kedua 2020, bukan Maret 2020. Notifikasi YouTube itu muncul di ponsel bertanggal "Minggu, 15 Maret". Jika ingin akurat, ubah `phoneDate` atau pindahkan notifikasi tersebut. Semua teksnya ada di `ui` Scene 02 dalam `timing.ts`.
- **Masker pada Scene 02** (15 Maret) mengikuti permintaan kreatif. Anjuran memakai masker untuk semua orang di Indonesia, setahu saya, baru meluas sekitar awal April 2020. Ini belum saya verifikasi.
- PSBB tidak digambarkan sebagai lockdown nasional ("Lalu diterapkan bertahap di sejumlah daerah.").
- "14 hari" adalah ekspektasi masyarakat, bukan kebijakan resmi ("Begitu perkiraan banyak orang saat itu."). "+ 2 MINGGU LAGI..." menggambarkan pengalaman perpanjangan pembatasan, bukan tanggal kebijakan tertentu.
- Tidak ada kutipan Presiden. Pesan di ponsel diberi label "Ilustrasi pesan (rekonstruksi)". Tampilan TV dan ponsel adalah rekonstruksi.

### Skala

- **Kota isometrik:** 1 satuan grid ≈ lebar jalan dua lajur (±7 m), ±8,8 px per meter tinggi. Pejalan kaki ±17 px (1,7 m), mobil 0,64 × 0,26 satuan (4,5 × 1,8 m), bus 1,7 satuan (12 m). Lihat `PED_SCALE` di `Character.tsx` dan `DIMS` di `Vehicle.tsx`.
- **Jalan tampak samping (Scene 02):** `STREET_PX_PER_METRE = 125`. Orang dewasa 1,72 m, anak 1,25 m, mobil ±4,75 m, rumah ±3,2 m sampai atap, sekolah dua lantai. Ukuran karakter dihitung dengan `streetScale(tinggiMeter)`.

## 2. Instalasi

Membutuhkan Node.js 18 atau lebih baru (diuji dengan Node 22).

```bash
npm install
```

Remotion mengunduh Chrome Headless Shell secara otomatis saat render pertama, jika belum ada.

---

## 3. Struktur proyek

```
nostalgia-covid-indonesia/
├── public/
│   ├── audio/
│   │   ├── background.wav          # musik 60 s (hasil generate)
│   │   └── sfx/                    # ambience + efek suara (hasil generate)
│   └── fonts/                      # Plus Jakarta Sans (SIL OFL) + lisensi
├── src/
│   ├── components/
│   │   ├── Camera.tsx              # kamera: fokus (x, y) + zoom, drift halus
│   │   ├── Character.tsx           # karakter besar (8 ekspresi, pose) + pejalan kaki kecil
│   │   ├── Environment.tsx         # langit, awan, burung, atmosfer, layout KOTA + furnitur jalan
│   │   ├── Building.tsx            # kotak isometrik, gedung, atap, jendela, papan nama
│   │   ├── Road.tsx                # jalan, trotoar, zebra cross, rel kereta
│   │   ├── Tree.tsx                # pohon low-poly bergoyang
│   │   ├── Vehicle.tsx             # mobil, angkot, motor, bus, kereta, mobil tampak samping
│   │   ├── Room.tsx                # ruang keluarga / ruang kerja (dipakai Scene 01, 02, 04)
│   │   ├── Calendar.tsx            # kalender dinding dengan layout hari asli + animasi sobek
│   │   ├── Classroom.tsx           # ruang kelas yang perlahan kosong
│   │   ├── Phone.tsx               # ponsel + notifikasi
│   │   ├── Street.tsx              # jalan tampak samping (Scene 02)
│   │   ├── CityShot.tsx            # langit + kota + kamera (Scene 01, 03, 05)
│   │   ├── OnScreenText.tsx        # semua teks di layar, dibaca dari timing.ts
│   │   ├── Transitions.tsx         # cut / dissolve / dip antar-shot dan antar-scene
│   │   └── AudioLayer.tsx          # musik, ambience, SFX dari timing.ts
│   ├── lib/                        # proyeksi isometrik, easing, utilitas warna
│   ├── scenes/Scene01.tsx … Scene05.tsx
│   ├── theme.ts                    # SEMUA warna dan tipografi
│   ├── timing.ts                   # SEMUA waktu: scene, shot, beat, teks, audio, string UI
│   ├── fonts.ts                    # memuat font lokal sebelum frame pertama
│   ├── Video.tsx                   # menyusun scene + audio
│   ├── Root.tsx                    # registrasi Composition
│   └── index.ts
├── scripts/
│   ├── generate-audio.js           # sintesis musik + SFX → public/audio
│   ├── validate-project.js         # validasi statis (tanpa render)
│   └── lib/                        # DSP kecil + loader timing.ts
├── remotion.config.ts
├── package.json
└── tsconfig.json
```

**Kota yang sama dipakai di semua scene kota.** Layout kota (`CITY_BUILDINGS`, pohon, jalur kendaraan, rute pejalan kaki) didefinisikan satu kali di `Environment.tsx`. Scene 01, 03, dan 05 hanya mengubah kamera, `density` (0 = kosong, 1 = ramai), palet, dan proporsi pejalan kaki bermasker. Hal yang sama berlaku untuk ruangan (`Room.tsx`) di Scene 01, 02, dan 04.

---

## 4. Mengubah warna (`src/theme.ts`)

Komponen tidak memakai warna literal. Semua warna dibaca dari objek `Palette`.

- `PALETTES.day`: palet default seri (biru langit, hijau lembut, teal, pink pastel, beige, abu-abu, biru keabuan)
- `PALETTES.muted`: versi desaturasi untuk Scene 03 dan momen melankolis
- `PALETTES.night`: dipakai time-lapse siang/malam di Scene 04
- `PALETTES.warm`: palet hangat untuk Scene 05 (resolusi)

Contoh: ubah warna atap rumah tokoh utama dengan mengganti `pink` di palet, atau ubah warna aksen teks lewat `accent`. Scene mencampur palet dengan `mixPalette(a, b, t)`, misalnya `mixPalette(PALETTES.muted, PALETTES.warm, 0.5)`.

Tipografi (ukuran, ketebalan, letter-spacing per varian teks) ada di `TYPE`.

---

## 5. Mengubah timeline (`src/timing.ts`)

Semua timestamp hanya ada di file ini.

- `SCENES[i].from` / `.to`: frame **absolut**. Scene harus bersambung (`to` scene ini = `from` scene berikutnya).
- `shots`, `beats`, `texts`, `sfx`, `ambience`: frame **lokal** (0 = awal scene).
- `beats`: momen penting yang dibaca komponen, misalnya `newsAlert` (TV berubah ke berita), `flip1…flip5` (kalender berganti), `darkenStart`.
- `texts`: setiap teks di layar, dengan `y` (posisi atas dalam piksel), `variant`, dan `accent`.
- `ui`: string diegetik (judul TV, isi notifikasi, label kalender, papan nama gedung).
- `SAFE_AREA`: area aman teks (atas 220 px, bawah 1580 px, kiri/kanan 90 px).
- `TRANSITION_FRAMES`: panjang dissolve antar-shot dan antar-scene (15 frame).

Contoh memperpanjang Scene 03 sebanyak 1 detik: tambah 30 frame ke `to` Scene 03, geser `from`/`to` Scene 04 dan 05 sebanyak +30, perpanjang shot terakhir Scene 03, lalu jalankan `npm run generate:audio` (musik mengikuti batas scene) dan `npm run validate`.

`timing.ts` sengaja tidak memiliki import, supaya script Node dapat membacanya langsung lewat compiler TypeScript.

---

## 6. Mengubah visual dan objek

- **Gedung**: edit `CITY_BUILDINGS` di `Environment.tsx` (posisi grid `x, y`, ukuran `w, d`, tinggi `h`, warna sebagai kunci palet, `roof`, `windows`, `sign`).
- **Pohon / lampu / bangku**: array `TREES`, `LIGHTS`, dan daftar bangku di `Environment.tsx`.
- **Kendaraan**: `CITY_VEHICLES` (jenis `car | angkot | motor | bus`, kecepatan, `threshold` kapan muncul berdasarkan `density`).
- **Pejalan kaki**: rute di `CITY_PEDESTRIANS` (`line`, `loop`, `idle`).
- **Kamera**: setiap shot memiliki `keys` `{ t, x, y, zoom }`. Titik fokus siap pakai tersedia di `CITY_FOCUS` dan `ROOM_ANCHORS`.
- **Karakter**: `<Character expression="worried" pose="sit" holding="typing" ... />`. Ekspresi: neutral, happy, confused, surprised, worried, sad, tired, relieved. Pakaian tokoh ada di `castOutfits()`.
- **Ruangan**: furnitur di `Room.tsx` (proyeksi `ROOM_ISO`, grid 5 × 5).

---

## 7. Menghasilkan audio

```bash
npm run generate:audio
```

Script ini menulis 14 file WAV (44,1 kHz, 16-bit, stereo) ke `public/audio/`, sekitar 25 MB. Semuanya disintesis, tanpa unduhan.

- **Musik** (`background.wav`): piano lembut (sintesis aditif) di atas pad hangat, dengan reverb, dalam C mayor / A minor. Setiap scene punya progresi akor, pola iringan, dan melodi sendiri: pembuka yang jarang, melodi hangat, bagian minimal yang melankolis, arpeggio time-lapse yang sedikit membangun, lalu resolusi Fmaj9, G, Cadd9 dengan fade-out. Batas bagian dibaca dari `timing.ts`.
- **Ambience**: kota (dengung jauh dan kendaraan lewat), angin dan dedaunan, room tone, burung.
- **SFX**: chime berita yang lembut (bukan suspense), notifikasi, ketikan keyboard, detak jam, kalender disobek, langkah kaki, pintu, whoosh halus, gemerisik daun.

Semua file dinormalisasi ke peak 0,45–0,8 agar tidak clipping. Volume akhir diatur di `timing.ts` (`volume`, `fadeIn`, `fadeOut`, dan `MUSIC.volume`). Hasilnya deterministik (seed tetap).

---

## 8. Validasi

```bash
npm run validate
```

Menjalankan `tsc --noEmit`, lalu `scripts/validate-project.js`, yang memeriksa:

1. FPS 30, resolusi 1080 × 1920, durasi total 55–65 detik
2. Setiap scene/shot: start < end, bersambung tanpa celah atau tumpang-tindih, dan mencakup seluruh durasi
3. Beat berada di dalam scene
4. Teks berada di dalam safe area (estimasi word-wrap), maksimal 3 baris, tampil minimal 1,5 detik, dan tidak bertabrakan dengan teks lain pada waktu yang sama
5. Setiap file audio yang dirujuk ada dan cukup panjang, WAV PCM 16-bit 44,1 kHz, tidak clipping, tidak senyap, dan setiap WAV di folder memang dipakai
6. Setiap `staticFile()` dan file font ada
7. Semua import relatif dapat di-resolve dan setiap package yang di-import terdaftar di `package.json`
8. Tidak ada dependency yang tidak terpakai, dan tidak ada placeholder (TODO/FIXME/not implemented)
9. `Root.tsx` memakai konstanta dari `timing.ts`, setiap scene terdaftar di `Video.tsx`, dan script `render` menargetkan composition yang benar
10. Setiap `getBeat` / `getUi` / `getShot` di komponen merujuk kunci yang ada di `timing.ts`

Validasi ini statis: tidak me-render frame, gambar, atau video.

---

## 9. Render

```bash
npm run render
```

Hasilnya ada di `out/two-weeks-to-two-years.mp4` (H.264 + AAC). Untuk pratinjau interaktif sebelum render:

```bash
npm run studio
```

Opsi tambahan, misalnya `--concurrency`, `--crf`, atau render sebagian dengan `--frames=0-299`, dapat ditambahkan ke perintah `remotion render`. Lihat dokumentasi Remotion.

Urutan yang disarankan pada instalasi baru:

```bash
npm install
```

```bash
npm run generate:audio
```

```bash
npm run validate
```

```bash
npm run render
```

---

## Troubleshooting: `npm audit` dan "Version mismatch"

- Semua paket Remotion **harus** memakai versi yang persis sama. Proyek ini mengunci `remotion`, `@remotion/cli`, dan `@remotion/media` pada `4.0.542`. Versi ini memakai `zod@4.6.7`, di luar rentang advisory GHSA-mrhx-c7xc-m3w5 (`zod <4.6.6`). Hasil `npm audit` saat proyek ini dibuat: 0 vulnerabilities.
- **Jangan menjalankan `npm audit fix --force`** pada proyek Remotion. Perintah itu hanya menaikkan sebagian paket (misalnya `@remotion/cli` saja), sehingga muncul peringatan *Version mismatch*.
- Untuk upgrade, ubah ketiga versi Remotion di `package.json` ke angka yang sama, hapus `node_modules` dan `package-lock.json`, lalu jalankan `npm install`. Cek dengan:

```bash
npx remotion versions
```

## Lisensi aset

- Font **Plus Jakarta Sans** © The Plus Jakarta Sans Project Authors (Tokotype), SIL Open Font License 1.1. Lisensi lengkap ada di `public/fonts/OFL-LICENSE.txt`.
- Semua audio dan visual dibuat secara prosedural oleh kode di repositori ini.
