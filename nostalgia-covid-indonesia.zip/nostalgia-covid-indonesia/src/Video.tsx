import React from "react";
import { AbsoluteFill } from "remotion";
import { AudioLayer } from "./components/AudioLayer";
import { LayeredTimeline } from "./components/Transitions";
import { Scene01 } from "./scenes/Scene01";
import { Scene02 } from "./scenes/Scene02";
import { Scene03 } from "./scenes/Scene03";
import { Scene04 } from "./scenes/Scene04";
import { Scene05 } from "./scenes/Scene05";
import { SceneId, SCENES } from "./timing";

const SCENE_COMPONENTS: Record<SceneId, React.FC> = {
  s01: Scene01,
  s02: Scene02,
  s03: Scene03,
  s04: Scene04,
  s05: Scene05,
};

/** Full film: scenes in timeline order with their transitions, plus the audio mix. */
export const TwoWeeksToTwoYears: React.FC = () => (
  <AbsoluteFill style={{ backgroundColor: "#1c2430" }}>
    <LayeredTimeline
      items={SCENES.map((scene) => {
        const Component = SCENE_COMPONENTS[scene.id];
        return { key: scene.id, from: scene.from, to: scene.to, transition: scene.transitionIn, node: <Component /> };
      })}
    />
    <AudioLayer />
  </AbsoluteFill>
);
