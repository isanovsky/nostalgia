import { Easing, interpolate, random } from "remotion";

export const clamp = (v: number, min = 0, max = 1) => Math.min(max, Math.max(min, v));

export const EASE = Easing.bezier(0.45, 0, 0.55, 1);
export const EASE_OUT = Easing.bezier(0.16, 1, 0.3, 1);
export const EASE_IN = Easing.bezier(0.5, 0, 0.75, 0);

export const CLAMP = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

/** 0 -> 1 between `from` and `to`, eased and clamped. */
export const progress = (frame: number, from: number, to: number, easing = EASE) =>
  interpolate(frame, [from, to], [0, 1], { ...CLAMP, easing });

/** 0 -> 1 -> 0 envelope with `fade`-frame ramps. */
export const window01 = (frame: number, from: number, to: number, fade: number) => {
  const f = Math.max(1, Math.min(fade, (to - from) / 2));
  return interpolate(frame, [from, from + f, to - f, to], [0, 1, 1, 0], CLAMP);
};

export const smoothstep = (a: number, b: number, v: number) => {
  const t = clamp((v - a) / (b - a));
  return t * t * (3 - 2 * t);
};

export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

/** Deterministic pseudo random in [0,1). */
export const rand = (seed: string | number) => random(seed);

/** Smooth idle sway, deterministic per seed. */
export const sway = (frame: number, speed: number, seed: number) =>
  Math.sin(frame * speed + seed * 12.9898) * 0.6 + Math.sin(frame * speed * 0.53 + seed * 4.1) * 0.4;

export type CamKey = { t: number; x: number; y: number; zoom: number };

/** Interpolate camera keys. `t` values must be ascending; output eased per segment. */
export const cameraAt = (keys: CamKey[], t: number): { x: number; y: number; zoom: number } => {
  if (t <= keys[0].t) return keys[0];
  const last = keys[keys.length - 1];
  if (t >= last.t) return last;
  for (let i = 0; i < keys.length - 1; i++) {
    const a = keys[i];
    const b = keys[i + 1];
    if (t >= a.t && t <= b.t) {
      const k = EASE((t - a.t) / (b.t - a.t));
      // Zoom interpolates geometrically so push-ins feel linear to the eye.
      const zoom = Math.exp(lerp(Math.log(a.zoom), Math.log(b.zoom), k));
      return { x: lerp(a.x, b.x, k), y: lerp(a.y, b.y, k), zoom };
    }
  }
  return last;
};

/**
 * Largest font size (<= base) at which `text` fits in `maxWidth`.
 * `factor` is the average glyph width in em for the bold sans used here.
 */
export const fitFontSize = (text: string, maxWidth: number, base: number, factor = 0.66, letterSpacing = 0) => {
  const spacing = Math.max(0, text.length - 1) * letterSpacing;
  return Math.max(1, Math.min(base, (maxWidth - spacing) / (Math.max(1, text.length) * factor)));
};
