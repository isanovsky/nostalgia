/**
 * Minimal isometric (2:1 dimetric) projection.
 * World grid: x runs toward screen lower-right, y toward screen lower-left,
 * z is height in screen pixels.
 */
export type Pt = readonly [number, number];

export type IsoProjector = {
  tw: number;
  th: number;
  p: (x: number, y: number, z?: number) => Pt;
  pts: (...points: Pt[]) => string;
  /** SVG matrix that maps a flat 2D drawing onto a wall facing +y (runs along x). */
  faceX: (x: number, y: number, z: number) => string;
  /** SVG matrix that maps a flat 2D drawing onto a wall facing +x (runs along y). */
  faceY: (x: number, y: number, z: number) => string;
  /** Pixel length of one grid unit along a wall. */
  unit: number;
};

export const makeIso = (tw: number, th: number, ox: number, oy: number): IsoProjector => {
  const p = (x: number, y: number, z = 0): Pt => [ox + ((x - y) * tw) / 2, oy + ((x + y) * th) / 2 - z];
  const unit = Math.hypot(tw / 2, th / 2);
  const cx = tw / 2 / unit;
  const cy = th / 2 / unit;
  return {
    tw,
    th,
    p,
    pts: (...points) => points.map(([a, b]) => `${a.toFixed(1)},${b.toFixed(1)}`).join(" "),
    faceX: (x, y, z) => {
      const [sx, sy] = p(x, y, z);
      return `matrix(${cx} ${cy} 0 1 ${sx} ${sy})`;
    },
    faceY: (x, y, z) => {
      const [sx, sy] = p(x, y, z);
      return `matrix(${cx} ${-cy} 0 1 ${sx} ${sy})`;
    },
    unit,
  };
};

/** Box corners as projected polygons (top, front-left face, front-right face). */
export const boxFaces = (
  iso: IsoProjector,
  x: number,
  y: number,
  w: number,
  d: number,
  h: number,
  z0 = 0,
) => {
  const { p, pts } = iso;
  const z1 = z0 + h;
  return {
    top: pts(p(x, y, z1), p(x + w, y, z1), p(x + w, y + d, z1), p(x, y + d, z1)),
    left: pts(p(x, y + d, z0), p(x + w, y + d, z0), p(x + w, y + d, z1), p(x, y + d, z1)),
    right: pts(p(x + w, y, z0), p(x + w, y + d, z0), p(x + w, y + d, z1), p(x + w, y, z1)),
    footprint: pts(p(x, y, z0), p(x + w, y, z0), p(x + w, y + d, z0), p(x, y + d, z0)),
  };
};
