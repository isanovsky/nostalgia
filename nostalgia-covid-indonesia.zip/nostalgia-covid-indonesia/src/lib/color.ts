import { interpolateColors } from "remotion";

const DARK = "#26323e";
const LIGHT = "#ffffff";

/** Darken a colour toward a cool blue-gray (painterly shadow, never pure black). */
export const shade = (color: string, amount: number) =>
  interpolateColors(amount, [0, 1], [color, DARK]);

/** Lighten a colour toward white. */
export const tint = (color: string, amount: number) =>
  interpolateColors(amount, [0, 1], [color, LIGHT]);

export const mix = (a: string, b: string, t: number) => interpolateColors(t, [0, 1], [a, b]);
