/**
 * TIMELINE - single source of truth for every timestamp in the film.
 *
 * Conventions
 *  - Scene `from` / `to` are ABSOLUTE frames of the composition.
 *  - Everything inside a scene (shots, beats, texts, sfx, ambience) uses
 *    LOCAL frames, i.e. 0 = first frame of that scene.
 *  - Scenes are contiguous. The incoming scene / shot is layered on top of the
 *    outgoing one for TRANSITION_FRAMES, so outgoing content keeps rendering
 *    for that many extra frames.
 *
 * This file must stay free of imports: scripts/generate-audio.js and
 * scripts/validate-project.js transpile and read it directly.
 */

export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;
export const TRANSITION_FRAMES = 15;
export const COMPOSITION_ID = "TwoWeeksToTwoYears";

/** Platform-safe area for text (TikTok / Reels / Shorts UI overlays). */
export const SAFE_AREA = { top: 220, bottom: 1580, left: 90, right: 990 } as const;

export const sec = (seconds: number): number => Math.round(seconds * FPS);

export type Transition = "cut" | "dissolve" | "dip";
export type SceneId = "s01" | "s02" | "s03" | "s04" | "s05";
export type Mood = string;

export type TextCue = {
  id: string;
  text: string;
  from: number;
  to: number;
  /** Top edge of the text block, in px from the top of the frame. */
  y: number;
  variant: "headline" | "subhead" | "closing" | "date" | "caption" | "tag" | "note" | "banner" | "credit";
  accent?: boolean;
};

export type Shot = {
  id: string;
  from: number;
  to: number;
  transition: Transition;
  description: string;
};

export type SfxCue = {
  id: string;
  /** Path relative to public/ */
  file: string;
  at: number;
  volume: number;
  /** Frames to play. Defaults to the full file. */
  duration?: number;
};

export type AmbienceCue = {
  id: string;
  file: string;
  from: number;
  to: number;
  volume: number;
  fadeIn: number;
  fadeOut: number;
};

export type SceneDef = {
  id: SceneId;
  title: string;
  from: number;
  to: number;
  transitionIn: Transition;
  description: string;
  mood: Mood;
  shots: Shot[];
  beats: Record<string, number>;
  texts: TextCue[];
  sfx: SfxCue[];
  ambience: AmbienceCue[];
  /** Diegetic strings: TV, phone, calendar, signs. */
  ui: Record<string, string>;
};

export const SCENES: SceneDef[] = [
  {
    id: "s01",
    title: "Pengumuman Pertama",
    from: 0,
    to: sec(10),
    transitionIn: "cut",
    description:
      "Elevated aerial of a busy Indonesian city in early 2020; camera pushes in to one house. Inside, a young man relaxes on the sofa until the TV shows breaking news.",
    mood: "Normal, unexpected, slightly concerning",
    shots: [
      { id: "aerial", from: 0, to: 150, transition: "cut", description: "Busy city, slow push-in from aerial to the pink-roof house" },
      { id: "living-room", from: 150, to: 300, transition: "dissolve", description: "Living room, TV breaking news, character turns to watch" },
    ],
    beats: { newsAlert: 200, headTurn: 208, worry: 236 },
    texts: [
      { id: "s01-year", text: "AWAL 2020", from: 6, to: 132, y: 300, variant: "headline" },
      { id: "s01-normal", text: "Kota masih ramai seperti biasa.", from: 18, to: 132, y: 432, variant: "caption" },
      { id: "s01-date", text: "2 MARET 2020", from: 204, to: 300, y: 300, variant: "date", accent: true },
      { id: "s01-headline", text: "2 KASUS PERTAMA COVID-19 DI INDONESIA", from: 212, to: 300, y: 1290, variant: "banner" },
    ],
    sfx: [
      { id: "s01-whoosh", file: "audio/sfx/whoosh-soft.wav", at: 140, volume: 0.22 },
      { id: "s01-news", file: "audio/sfx/news-chime.wav", at: 200, volume: 0.45 },
    ],
    ambience: [
      { id: "s01-city", file: "audio/sfx/amb-city.wav", from: 0, to: 165, volume: 0.32, fadeIn: 20, fadeOut: 18 },
      { id: "s01-room", file: "audio/sfx/amb-room.wav", from: 150, to: 315, volume: 0.25, fadeIn: 15, fadeOut: 15 },
    ],
    ui: {
      tvLabel: "BERITA TERKINI",
      tvHeadline: "2 KASUS PERTAMA COVID-19",
      calendarMonth: "MARET 2020",
      school: "SEKOLAH",
      mall: "MAL",
      station: "STASIUN",
    },
  },
  {
    id: "s02",
    title: "Hanya Dua Minggu?",
    from: sec(10),
    to: sec(23),
    transitionIn: "dissolve",
    description:
      "He walks home (masked) carrying his office laptop, his little sister carries her school books. Group-chat and video notifications arrive, a classroom empties, and he settles in to work from home under a calendar with 14 days marked while the TV reports rising cases.",
    mood: "Casual, uncertain, slightly optimistic",
    shots: [
      { id: "commute", from: 0, to: 100, transition: "cut", description: "Sidewalk: laptop bag and school bag going home, masks on" },
      { id: "phone", from: 100, to: 215, transition: "dissolve", description: "Phone close-up: office, class and video notifications" },
      { id: "classroom", from: 215, to: 290, transition: "dissolve", description: "Classroom slowly empties" },
      { id: "wfh", from: 290, to: 390, transition: "dissolve", description: "Work from home, calendar with two weeks circled, TV news" },
    ],
    beats: {
      notification: 112,
      notification2: 138,
      notification3: 164,
      classEmptyStart: 222,
      classEmptyEnd: 282,
      doorClose: 291,
      tvNews: 296,
      typingStart: 305,
      calendarMark: 318,
    },
    texts: [
      { id: "s02-date", text: "15 MARET 2020", from: 6, to: 98, y: 300, variant: "date", accent: true },
      { id: "s02-home", text: "Kerja, belajar, dan beribadah dari rumah.", from: 14, to: 98, y: 400, variant: "caption" },
      { id: "s02-recon", text: "Ilustrasi pesan (rekonstruksi)", from: 126, to: 213, y: 1536, variant: "note" },
      { id: "s02-14days", text: "14 HARI SAJA?", from: 312, to: 390, y: 300, variant: "headline", accent: true },
      { id: "s02-expect", text: "Begitu perkiraan banyak orang saat itu.", from: 326, to: 390, y: 432, variant: "caption" },
      { id: "s02-news", text: "KASUS COVID-19 MENINGKAT LAGI", from: 318, to: 390, y: 1290, variant: "banner" },
    ],
    sfx: [
      { id: "s02-steps", file: "audio/sfx/footsteps.wav", at: 0, volume: 0.32 },
      { id: "s02-notif-1", file: "audio/sfx/notification.wav", at: 112, volume: 0.5 },
      { id: "s02-notif-2", file: "audio/sfx/notification.wav", at: 138, volume: 0.42 },
      { id: "s02-notif-3", file: "audio/sfx/notification.wav", at: 164, volume: 0.36 },
      { id: "s02-door", file: "audio/sfx/door.wav", at: 291, volume: 0.28 },
      { id: "s02-news", file: "audio/sfx/news-chime.wav", at: 296, volume: 0.25 },
      { id: "s02-typing", file: "audio/sfx/keyboard.wav", at: 305, volume: 0.34 },
    ],
    ambience: [
      { id: "s02-city", file: "audio/sfx/amb-city.wav", from: 0, to: 112, volume: 0.28, fadeIn: 10, fadeOut: 14 },
      { id: "s02-room", file: "audio/sfx/amb-room.wav", from: 100, to: 405, volume: 0.22, fadeIn: 14, fadeOut: 15 },
    ],
    ui: {
      notif1App: "Grup Kantor",
      notif1Text: "Mulai besok, kegiatan dilakukan dari rumah.",
      notif2App: "Grup Kelas 4B",
      notif2Text: "Belajar dari rumah dulu ya, anak-anak.",
      notif3App: "YouTube",
      notif3Text: "Cara mengubah kuota edukasi menjadi kuota utama",
      phoneTime: "19.42",
      phoneDate: "Minggu, 15 Maret",
      board: "BELAJAR DARI RUMAH",
      calendarMonth: "MARET 2020",
      tvLabel: "BERITA TERKINI",
      tvHeadline: "KASUS COVID-19 MENINGKAT LAGI",
      school: "SEKOLAH",
    },
  },
  {
    id: "s03",
    title: "Kota yang Sepi",
    from: sec(23),
    to: sec(35),
    transitionIn: "dissolve",
    description:
      "The same city and camera angles as Scene 01, now muted. Match cuts turn the busy street, school, mall and station quiet. Wind, leaves and distant birds - calm, not eerie.",
    mood: "Quiet, isolated, melancholic",
    shots: [
      { id: "street", from: 0, to: 90, transition: "cut", description: "Scene 01 aerial angle: busy street fades to empty" },
      { id: "school", from: 90, to: 180, transition: "dissolve", description: "School yard: children fade out" },
      { id: "mall", from: 180, to: 270, transition: "dissolve", description: "Mall plaza: shoppers fade out" },
      { id: "station", from: 270, to: 360, transition: "dissolve", description: "Station: platform empties, camera rises" },
    ],
    beats: { emptyDelay: 8, emptyLength: 40, leafFall: 40 },
    texts: [
      { id: "s03-reduce", text: "KURANGI AKTIVITAS DI LUAR RUMAH", from: 18, to: 90, y: 300, variant: "subhead" },
      { id: "s03-mask", text: "PAKAI MASKER", from: 30, to: 90, y: 470, variant: "headline", accent: true },
      { id: "s03-school", text: "SEKOLAH", from: 106, to: 178, y: 1440, variant: "tag" },
      { id: "s03-psbb", text: "PSBB", from: 190, to: 270, y: 300, variant: "headline", accent: true },
      { id: "s03-psbb-date", text: "10 APRIL 2020 · JAKARTA", from: 198, to: 270, y: 440, variant: "date" },
      { id: "s03-mall", text: "PUSAT PERBELANJAAN", from: 196, to: 268, y: 1440, variant: "tag" },
      { id: "s03-gradual", text: "Lalu diterapkan bertahap di sejumlah daerah.", from: 286, to: 358, y: 300, variant: "caption" },
      { id: "s03-station", text: "STASIUN", from: 286, to: 358, y: 1440, variant: "tag" },
    ],
    sfx: [
      { id: "s03-leaves", file: "audio/sfx/leaves.wav", at: 40, volume: 0.22 },
      { id: "s03-whoosh-1", file: "audio/sfx/whoosh-soft.wav", at: 88, volume: 0.16 },
      { id: "s03-whoosh-2", file: "audio/sfx/whoosh-soft.wav", at: 178, volume: 0.16 },
      { id: "s03-whoosh-3", file: "audio/sfx/whoosh-soft.wav", at: 268, volume: 0.16 },
    ],
    ambience: [
      { id: "s03-wind", file: "audio/sfx/amb-wind.wav", from: 0, to: 375, volume: 0.38, fadeIn: 25, fadeOut: 15 },
      { id: "s03-birds", file: "audio/sfx/amb-birds.wav", from: 0, to: 360, volume: 0.1, fadeIn: 30, fadeOut: 30 },
      { id: "s03-traffic", file: "audio/sfx/amb-city.wav", from: 0, to: 110, volume: 0.22, fadeIn: 1, fadeOut: 70 },
    ],
    ui: {
      school: "SEKOLAH",
      mall: "MAL",
      station: "STASIUN",
    },
  },
  {
    id: "s04",
    title: "Dua Minggu Menjadi Dua Tahun",
    from: sec(35),
    to: sec(49),
    transitionIn: "dip",
    description:
      "The same room, now a home office. Time-lapse: calendar pages flip from March 2020 to 2022, day and night alternate through the window, books pile up, the clock spins. He goes from relaxed to bored to tired, then settles into the new routine.",
    mood: "Time passing, reflective, emotional",
    shots: [
      { id: "timelapse", from: 0, to: 420, transition: "cut", description: "Continuous time-lapse with camera moving between room and calendar" },
    ],
    beats: {
      flip1: 70,
      flip2: 125,
      flip3: 180,
      flip4: 235,
      flip5: 290,
      pushToCalendar: 40,
      pullBack: 300,
      bored: 110,
      tired: 200,
      settled: 305,
    },
    texts: [
      { id: "s04-weeks", text: "2 MINGGU...", from: 10, to: 112, y: 300, variant: "headline" },
      { id: "s04-more", text: "+ 2 MINGGU LAGI...", from: 112, to: 292, y: 300, variant: "headline" },
      { id: "s04-years", text: "2 TAHUN.", from: 300, to: 420, y: 300, variant: "headline", accent: true },
      { id: "s04-routine", text: "Rutinitas baru pun menjadi biasa.", from: 330, to: 420, y: 432, variant: "caption" },
    ],
    sfx: [
      { id: "s04-clock", file: "audio/sfx/clock-tick.wav", at: 0, volume: 0.22, duration: 420 },
      { id: "s04-flip-1", file: "audio/sfx/page-flip.wav", at: 70, volume: 0.38 },
      { id: "s04-flip-2", file: "audio/sfx/page-flip.wav", at: 125, volume: 0.38 },
      { id: "s04-flip-3", file: "audio/sfx/page-flip.wav", at: 180, volume: 0.38 },
      { id: "s04-flip-4", file: "audio/sfx/page-flip.wav", at: 235, volume: 0.38 },
      { id: "s04-flip-5", file: "audio/sfx/page-flip.wav", at: 290, volume: 0.38 },
      { id: "s04-typing", file: "audio/sfx/keyboard.wav", at: 140, volume: 0.2 },
    ],
    ambience: [
      { id: "s04-room", file: "audio/sfx/amb-room.wav", from: 0, to: 435, volume: 0.2, fadeIn: 15, fadeOut: 15 },
    ],
    ui: {
      page0: "MARET 2020",
      page1: "APRIL 2020",
      page2: "JUNI 2020",
      page3: "DESEMBER 2020",
      page4: "2021",
      page5: "2022",
    },
  },
  {
    id: "s05",
    title: "Apakah Kehidupan Berhenti di Tahun 2020?",
    from: sec(49),
    to: sec(60),
    transitionIn: "dissolve",
    description:
      "Back to the same city in warm sunlight. Cars, pedestrians, schoolchildren and shops return as the camera pulls out to the whole city. The screen darkens to the closing question and a thank-you to health workers.",
    mood: "Hopeful, nostalgic, reflective",
    shots: [
      { id: "city-return", from: 0, to: 330, transition: "cut", description: "City comes back to life, pull-out, darken, closing text" },
    ],
    beats: { lifeReturnEnd: 120, pullOutEnd: 190, darkenStart: 165, darkenEnd: 205, fadeOutStart: 312 },
    texts: [
      { id: "s05-year", text: "2022", from: 12, to: 150, y: 300, variant: "date", accent: true },
      { id: "s05-return", text: "Kota perlahan hidup kembali.", from: 20, to: 150, y: 400, variant: "caption" },
      { id: "s05-question", text: "APAKAH KEHIDUPAN BERHENTI DI TAHUN 2020?", from: 200, to: 330, y: 660, variant: "closing" },
      { id: "s05-title", text: "DARI 2 MINGGU MENJADI 2 TAHUN", from: 226, to: 330, y: 1060, variant: "tag" },
      { id: "s05-thanks", text: "Terima kasih para nakes, pahlawan sejati di garda terdepan pandemi.", from: 246, to: 330, y: 1440, variant: "credit" },
    ],
    sfx: [],
    ambience: [
      { id: "s05-city", file: "audio/sfx/amb-city.wav", from: 0, to: 330, volume: 0.3, fadeIn: 100, fadeOut: 60 },
      { id: "s05-birds", file: "audio/sfx/amb-birds.wav", from: 0, to: 330, volume: 0.28, fadeIn: 30, fadeOut: 60 },
    ],
    ui: {
      school: "SEKOLAH",
      mall: "MAL",
      station: "STASIUN",
    },
  },
];

export const TOTAL_FRAMES = SCENES[SCENES.length - 1].to;

export const MUSIC = {
  file: "audio/background.wav",
  volume: 0.6,
  fadeIn: 24,
  fadeOut: 75,
} as const;

/* ---------- lookups used by scene components ---------- */

export const getScene = (id: SceneId): SceneDef => {
  const scene = SCENES.find((s) => s.id === id);
  if (!scene) throw new Error(`Unknown scene "${id}" in timing.ts`);
  return scene;
};

export const sceneDuration = (scene: SceneDef): number => scene.to - scene.from;

export const getShot = (scene: SceneDef, shotId: string): Shot => {
  const shot = scene.shots.find((s) => s.id === shotId);
  if (!shot) throw new Error(`Unknown shot "${shotId}" in scene ${scene.id}`);
  return shot;
};

export const getBeat = (scene: SceneDef, name: string): number => {
  const value = scene.beats[name];
  if (value === undefined) throw new Error(`Unknown beat "${name}" in scene ${scene.id}`);
  return value;
};

export const getUi = (scene: SceneDef, key: string): string => {
  const value = scene.ui[key];
  if (value === undefined) throw new Error(`Unknown ui string "${key}" in scene ${scene.id}`);
  return value;
};
