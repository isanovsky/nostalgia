import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { CityShot } from "../components/CityShot";
import { castOutfits, Character, Expression } from "../components/Character";
import { Camera } from "../components/Camera";
import { Atmosphere, CITY_FOCUS } from "../components/Environment";
import { SceneTexts } from "../components/OnScreenText";
import { Room, ROOM_ANCHORS } from "../components/Room";
import { LayeredTimeline } from "../components/Transitions";
import { CLAMP, EASE } from "../lib/anim";
import { PALETTES } from "../theme";
import { getBeat, getScene, getShot, getUi } from "../timing";

const scene = getScene("s01");
const palette = PALETTES.day;
const SIGNS = { school: getUi(scene, "school"), mall: getUi(scene, "mall"), station: getUi(scene, "station") };

const AerialShot: React.FC = () => {
  const f = useCurrentFrame();
  const shot = getShot(scene, "aerial");
  const len = shot.to - shot.from;
  return (
    <CityShot
      palette={palette}
      animFrame={scene.from + shot.from + f}
      density={1}
      signs={SIGNS}
      t={f / len}
      keys={[
        { t: 0, x: CITY_FOCUS.overview.x, y: CITY_FOCUS.overview.y - 50, zoom: 0.6 },
        { t: 0.2, x: CITY_FOCUS.overview.x - 10, y: CITY_FOCUS.overview.y - 20, zoom: 0.68 },
        { t: 1, x: CITY_FOCUS.house.x, y: CITY_FOCUS.house.y - 10, zoom: 2.1 },
      ]}
    />
  );
};

const LivingRoomShot: React.FC = () => {
  const f = useCurrentFrame();
  const shot = getShot(scene, "living-room");
  const len = shot.to - shot.from;
  const sf = f + shot.from; // scene-local frame
  const news = getBeat(scene, "newsAlert");
  const turn = getBeat(scene, "headTurn");
  const worry = getBeat(scene, "worry");
  const cast = castOutfits(palette);

  const expression: Expression = sf < turn ? "happy" : sf < worry ? "surprised" : "worried";
  const headTurn = interpolate(sf, [turn, turn + 12], [-0.25, 0.85], { ...CLAMP, easing: EASE });
  const clock = (scene.from + sf) / 900;

  return (
    <Camera
      t={f / len}
      driftFrame={sf}
      keys={[
        { t: 0, x: ROOM_ANCHORS.center.x, y: ROOM_ANCHORS.center.y + 20, zoom: 1.0 },
        { t: 0.33, x: 480, y: 580, zoom: 1.3 },
        { t: 1, x: 420, y: 560, zoom: 1.75 },
      ]}
    >
      <Room
        palette={palette}
        frame={sf}
        daylight={1}
        tv={sf < news ? "program" : "news"}
        tvLabel={getUi(scene, "tvLabel")}
        tvHeadline={getUi(scene, "tvHeadline")}
        laptop={false}
        books={2}
        calendarPages={[getUi(scene, "calendarMonth")]}
        calendarPage={0}
        hourAngle={clock * Math.PI * 2 + 1.2}
        minuteAngle={clock * Math.PI * 24}
        onSofa={
          <Character
            x={ROOM_ANCHORS.sofaSeat.x}
            y={ROOM_ANCHORS.sofaSeat.y}
            scale={1.05}
            outfit={cast.raka}
            pose="sit"
            expression={expression}
            headTurn={headTurn}
            headTilt={sf > worry ? -3 : 0}
            holding={sf < turn ? "mug" : "phone"}
            glowColor={palette.screenGlow}
            frame={sf}
            seed={3}
          />
        }
      />
    </Camera>
  );
};

export const Scene01: React.FC = () => (
  <AbsoluteFill>
    <LayeredTimeline
      items={[
        { key: "aerial", ...getShot(scene, "aerial"), node: <AerialShot /> },
        { key: "living-room", ...getShot(scene, "living-room"), node: <LivingRoomShot /> },
      ]}
    />
    <Atmosphere palette={palette} />
    <SceneTexts scene={scene} palette={palette} />
  </AbsoluteFill>
);
