import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { CityShot } from "../components/CityShot";
import { Atmosphere, CITY_FOCUS, FallingLeaves } from "../components/Environment";
import { SceneTexts } from "../components/OnScreenText";
import { LayeredTimeline } from "../components/Transitions";
import { CamKey, progress } from "../lib/anim";
import { mixPalette, PALETTES } from "../theme";
import { getBeat, getScene, getShot, getUi } from "../timing";

const scene = getScene("s03");
const SIGNS = { school: getUi(scene, "school"), mall: getUi(scene, "mall"), station: getUi(scene, "station") };

/**
 * Every shot starts as the busy city (a match cut with Scene 01's framing)
 * and drains to empty while the grade cools to the muted palette.
 */
const EmptyingShot: React.FC<{ shotId: string; keys: CamKey[]; warmStart: number }> = ({ shotId, keys, warmStart }) => {
  const f = useCurrentFrame();
  const shot = getShot(scene, shotId);
  const len = shot.to - shot.from;
  const delay = getBeat(scene, "emptyDelay");
  const length = getBeat(scene, "emptyLength");
  const drain = progress(f, delay, delay + length);
  const palette = mixPalette(mixPalette(PALETTES.muted, PALETTES.day, warmStart), PALETTES.muted, drain);
  return (
    <CityShot
      palette={palette}
      animFrame={scene.from + shot.from + f}
      density={1 - drain}
      masks={1}
      signs={SIGNS}
      t={f / len}
      keys={keys}
      sun={0.55}
    />
  );
};

const LeavesAndGrade: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <>
      <FallingLeaves frame={f} start={getBeat(scene, "leafFall")} palette={PALETTES.muted} count={7} />
      <FallingLeaves frame={f} start={getBeat(scene, "leafFall") + 200} palette={PALETTES.muted} count={4} />
    </>
  );
};

const { overview, school, mall, station } = CITY_FOCUS;

export const Scene03: React.FC = () => (
  <AbsoluteFill>
    <LayeredTimeline
      items={[
        {
          key: "street",
          ...getShot(scene, "street"),
          node: (
            <EmptyingShot
              shotId="street"
              warmStart={1}
              keys={[
                { t: 0, x: overview.x, y: overview.y - 50, zoom: 0.6 },
                { t: 1, x: overview.x, y: overview.y, zoom: 0.78 },
              ]}
            />
          ),
        },
        {
          key: "school",
          ...getShot(scene, "school"),
          node: (
            <EmptyingShot
              shotId="school"
              warmStart={0.6}
              keys={[
                { t: 0, x: school.x + 40, y: school.y, zoom: 1.7 },
                { t: 1, x: school.x, y: school.y + 10, zoom: 1.95 },
              ]}
            />
          ),
        },
        {
          key: "mall",
          ...getShot(scene, "mall"),
          node: (
            <EmptyingShot
              shotId="mall"
              warmStart={0.6}
              keys={[
                { t: 0, x: mall.x - 40, y: mall.y, zoom: 1.7 },
                { t: 1, x: mall.x, y: mall.y + 10, zoom: 1.95 },
              ]}
            />
          ),
        },
        {
          key: "station",
          ...getShot(scene, "station"),
          node: (
            <EmptyingShot
              shotId="station"
              warmStart={0.6}
              keys={[
                { t: 0, x: station.x, y: station.y, zoom: 1.9 },
                { t: 0.45, x: station.x, y: station.y - 20, zoom: 1.6 },
                { t: 1, x: overview.x, y: overview.y + 40, zoom: 0.82 },
              ]}
            />
          ),
        },
      ]}
    />
    <LeavesAndGrade />
    <Atmosphere palette={PALETTES.muted} sunLeak={0.25} />
    <SceneTexts scene={scene} palette={PALETTES.muted} />
  </AbsoluteFill>
);
