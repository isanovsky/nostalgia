import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { Camera } from "../components/Camera";
import { castOutfits, Character } from "../components/Character";
import { Classroom } from "../components/Classroom";
import { Atmosphere, Sky } from "../components/Environment";
import { SceneTexts } from "../components/OnScreenText";
import { Phone } from "../components/Phone";
import { Room, ROOM_ANCHORS } from "../components/Room";
import { Street, STREET_SIDEWALK_Y, streetScale } from "../components/Street";
import { LayeredTimeline } from "../components/Transitions";
import { CLAMP, progress } from "../lib/anim";
import { mixPalette, PALETTES } from "../theme";
import { getBeat, getScene, getShot, getUi } from "../timing";

const scene = getScene("s02");
// late afternoon: a touch warmer than Scene 01
const palette = mixPalette(PALETTES.day, PALETTES.warm, 0.35);

/** Masks were on by mid-March in this retelling (see README). */
const CommuteShot: React.FC = () => {
  const f = useCurrentFrame();
  const cast = castOutfits(palette);
  const walk = 4.2; // ~1 m/s at STREET_PX_PER_METRE
  const camX = 620 + f * walk;
  return (
    <AbsoluteFill>
      <Sky palette={palette} frame={scene.from + f} camX={camX * 0.4} />
      <Street palette={palette} frame={scene.from + f} camX={camX} schoolSign={getUi(scene, "school")}>
        <Character
          x={480 + f * walk}
          y={STREET_SIDEWALK_Y}
          scale={streetScale(1.72)}
          outfit={cast.raka}
          pose="walk"
          headTurn={0.35}
          expression="happy"
          holding="laptopBag"
          mask
          frame={f}
          seed={3}
        />
        <Character
          x={700 + f * walk}
          y={STREET_SIDEWALK_Y + 14}
          scale={streetScale(1.25, true)}
          outfit={cast.dinda}
          pose="walk"
          headTurn={-0.45}
          expression="happy"
          holding="books"
          child
          mask
          walkSpeed={0.42}
          frame={f}
          seed={5}
        />
        <Character
          x={1450 - f * 3}
          y={STREET_SIDEWALK_Y + 30}
          scale={streetScale(1.65)}
          outfit={{ ...cast.raka, shirt: palette.pink, shirtShade: palette.roofRed, pants: palette.blueGray }}
          pose="walk"
          facing={-1}
          headTurn={0.3}
          expression="neutral"
          mask
          frame={f}
          seed={11}
        />
      </Street>
    </AbsoluteFill>
  );
};

const PhoneShot: React.FC = () => {
  const f = useCurrentFrame();
  const shot = getShot(scene, "phone");
  return (
    <Phone
      palette={palette}
      frame={f}
      duration={shot.to - shot.from}
      time={getUi(scene, "phoneTime")}
      date={getUi(scene, "phoneDate")}
      notifications={[
        { app: getUi(scene, "notif1App"), text: getUi(scene, "notif1Text"), at: getBeat(scene, "notification") - shot.from },
        { app: getUi(scene, "notif2App"), text: getUi(scene, "notif2Text"), at: getBeat(scene, "notification2") - shot.from },
        { app: getUi(scene, "notif3App"), text: getUi(scene, "notif3Text"), at: getBeat(scene, "notification3") - shot.from, icon: "video" },
      ]}
    />
  );
};

const ClassroomShot: React.FC = () => {
  const f = useCurrentFrame();
  const shot = getShot(scene, "classroom");
  const len = shot.to - shot.from;
  return (
    <Camera
      t={f / len}
      driftFrame={f}
      keys={[
        { t: 0, x: 540, y: 700, zoom: 1.0 },
        { t: 1, x: 560, y: 690, zoom: 1.12 },
      ]}
    >
      <Classroom
        palette={palette}
        frame={f}
        board={getUi(scene, "board")}
        emptyFrom={getBeat(scene, "classEmptyStart") - shot.from}
        emptyTo={getBeat(scene, "classEmptyEnd") - shot.from}
      />
    </Camera>
  );
};

const WfhShot: React.FC = () => {
  const f = useCurrentFrame();
  const shot = getShot(scene, "wfh");
  const len = shot.to - shot.from;
  const sf = f + shot.from;
  const cast = castOutfits(palette);
  const typing = sf >= getBeat(scene, "typingStart");
  const mark = getBeat(scene, "calendarMark");
  const clock = (scene.from + sf) / 900;
  return (
    <Camera
      t={f / len}
      driftFrame={sf}
      keys={[
        { t: 0, x: 560, y: 610, zoom: 1.0 },
        { t: 1, x: 500, y: 500, zoom: 1.45 },
      ]}
    >
      <Room
        palette={palette}
        frame={sf}
        daylight={0.85}
        tv={sf >= getBeat(scene, "tvNews") ? "news" : "off"}
        tvLabel={getUi(scene, "tvLabel")}
        tvHeadline={getUi(scene, "tvHeadline")}
        laptop
        laptopGlow={0.7}
        books={2}
        calendarPages={[getUi(scene, "calendarMonth")]}
        calendarPage={0}
        calendarCircle={[16, 29]}
        calendarCircleProgress={interpolate(sf, [mark, mark + 36], [0, 1], CLAMP)}
        hourAngle={clock * Math.PI * 2 + 1.2}
        minuteAngle={clock * Math.PI * 24}
        onSofa={
          <Character
            x={ROOM_ANCHORS.sofaSeat.x}
            y={ROOM_ANCHORS.sofaSeat.y}
            scale={0.78}
            outfit={cast.dinda}
            pose="sit"
            expression="neutral"
            headTurn={0.2}
            holding="phone"
            glowColor={palette.screenGlow}
            child
            frame={sf}
            seed={5}
          />
        }
        atDesk={
          <Character
            x={ROOM_ANCHORS.deskSeat.x}
            y={ROOM_ANCHORS.deskSeat.y}
            scale={1.15}
            outfit={cast.raka}
            pose="sit"
            expression={progress(sf, mark, mark + 20) > 0.5 ? "happy" : "relieved"}
            headTurn={sf >= getBeat(scene, "tvNews") && sf < mark ? -0.8 : -0.2}
            holding={typing ? "typing" : "mug"}
            screenGlow={0.6}
            glowColor={palette.screenGlow}
            frame={sf}
            seed={3}
          />
        }
      />
    </Camera>
  );
};

export const Scene02: React.FC = () => (
  <AbsoluteFill>
    <LayeredTimeline
      items={[
        { key: "commute", ...getShot(scene, "commute"), node: <CommuteShot /> },
        { key: "phone", ...getShot(scene, "phone"), node: <PhoneShot /> },
        { key: "classroom", ...getShot(scene, "classroom"), node: <ClassroomShot /> },
        { key: "wfh", ...getShot(scene, "wfh"), node: <WfhShot /> },
      ]}
    />
    <Atmosphere palette={palette} sunLeak={0.8} />
    <SceneTexts scene={scene} palette={palette} />
  </AbsoluteFill>
);
