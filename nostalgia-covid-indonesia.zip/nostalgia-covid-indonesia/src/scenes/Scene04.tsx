import React from "react";
import { AbsoluteFill, Easing, interpolate, useCurrentFrame } from "remotion";
import { Camera } from "../components/Camera";
import { castOutfits, Character, Expression, Holding } from "../components/Character";
import { Atmosphere } from "../components/Environment";
import { SceneTexts } from "../components/OnScreenText";
import { Room, ROOM_ANCHORS } from "../components/Room";
import { CLAMP, clamp, progress } from "../lib/anim";
import { mixPalette, PALETTES } from "../theme";
import { getBeat, getScene, getUi, sceneDuration } from "../timing";

const scene = getScene("s04");
const PAGES = ["page0", "page1", "page2", "page3", "page4", "page5"].map((k) => getUi(scene, k));
const FLIPS = ["flip1", "flip2", "flip3", "flip4", "flip5"].map((k) => getBeat(scene, k));
const FLIP_LEN = 12;
const DURATION = sceneDuration(scene);
/** Number of day/night cycles shown by the time-lapse. */
const CYCLES = 7;

const BASE = mixPalette(PALETTES.day, PALETTES.muted, 0.5);

export const Scene04: React.FC = () => {
  const f = useCurrentFrame();
  const cast = castOutfits(BASE);

  // time-lapse clock: accelerates, then eases as he settles into the routine
  const cycles = interpolate(f, [0, DURATION], [0, CYCLES], { ...CLAMP, easing: Easing.bezier(0.4, 0, 0.6, 1) });
  const daylight = 0.5 + 0.5 * Math.cos(cycles * Math.PI * 2);
  const settled = getBeat(scene, "settled");
  const palette = mixPalette(mixPalette(BASE, PALETTES.night, 1 - daylight), PALETTES.warm, progress(f, settled, DURATION) * 0.45);

  // calendar
  const page = FLIPS.filter((b) => f >= b + FLIP_LEN).length;
  const flipping = FLIPS.find((b) => f >= b && f < b + FLIP_LEN);
  const flip = flipping === undefined ? 0 : (f - flipping) / FLIP_LEN;
  const starts = [0, ...FLIPS];
  const crossed = (i: number) => {
    if (i < page) return 1;
    if (i > page) return 0;
    const end = starts[i + 1] ?? DURATION;
    return clamp((f - starts[i]) / (end - starts[i]));
  };

  // character arc: relaxed -> bored -> tired -> used to it
  const bored = getBeat(scene, "bored");
  const tired = getBeat(scene, "tired");
  let expression: Expression = "happy";
  let holding: Holding = "typing";
  let slump = 0;
  if (f >= bored && f < tired) {
    expression = "neutral";
    holding = "chinRest";
    slump = 0.3;
  } else if (f >= tired && f < settled) {
    expression = "tired";
    holding = "typing";
    slump = interpolate(f, [tired, tired + 30], [0.3, 0.9], CLAMP);
  } else if (f >= settled) {
    expression = f < settled + 45 ? "relieved" : "happy";
    holding = f < settled + 45 ? "mug" : "typing";
    slump = interpolate(f, [settled, settled + 30], [0.9, 0], CLAMP);
  }

  const push = getBeat(scene, "pushToCalendar");
  const pull = getBeat(scene, "pullBack");
  const cal = ROOM_ANCHORS.calendar;

  return (
    <AbsoluteFill>
      <Camera
        t={f}
        driftFrame={f}
        keys={[
          { t: 0, x: ROOM_ANCHORS.center.x, y: ROOM_ANCHORS.center.y, zoom: 1.0 },
          { t: push, x: ROOM_ANCHORS.center.x - 20, y: ROOM_ANCHORS.center.y - 20, zoom: 1.08 },
          { t: push + 45, x: cal.x + 10, y: cal.y + 10, zoom: 2.3 },
          { t: FLIPS[1] - 20, x: cal.x + 20, y: cal.y + 20, zoom: 2.2 },
          { t: FLIPS[1] + 30, x: 540, y: 470, zoom: 1.55 },
          { t: FLIPS[4] - 10, x: 540, y: 460, zoom: 1.75 },
          { t: pull + 20, x: cal.x + 60, y: cal.y + 60, zoom: 2.0 },
          { t: DURATION, x: ROOM_ANCHORS.center.x, y: ROOM_ANCHORS.center.y - 30, zoom: 1.05 },
        ]}
      >
        <Room
          palette={palette}
          frame={f}
          daylight={daylight}
          tv="off"
          laptop
          laptopGlow={0.5 + (1 - daylight) * 0.5}
          books={1 + interpolate(f, [0, DURATION - 40], [0, 6], CLAMP)}
          calendarPages={PAGES}
          calendarPage={page}
          calendarFlip={flip}
          calendarCircle={[16, 29]}
          calendarCircleProgress={1}
          calendarCrossed={crossed}
          hourAngle={cycles * Math.PI * 4}
          minuteAngle={cycles * Math.PI * 48}
          plantGrowth={progress(f, 0, DURATION)}
          onSofa={
            daylight > 0.45 ? (
              <Character
                x={ROOM_ANCHORS.sofaSeat.x}
                y={ROOM_ANCHORS.sofaSeat.y}
                scale={0.78 + progress(f, 0, DURATION) * 0.08}
                outfit={cast.dinda}
                pose="sit"
                expression={f > settled ? "happy" : "neutral"}
                headTurn={0.1}
                holding="books"
                child
                frame={f}
                seed={5}
              />
            ) : null
          }
          atDesk={
            <Character
              x={ROOM_ANCHORS.deskSeat.x}
              y={ROOM_ANCHORS.deskSeat.y}
              scale={1.15}
              outfit={{ ...cast.raka, skin: palette.skin, skinShade: palette.skinShade, shirt: palette.shirt, shirtShade: palette.shirtShade }}
              pose="sit"
              expression={expression}
              headTurn={-0.15}
              holding={holding}
              slump={slump}
              hairGrowth={progress(f, 0, settled)}
              screenGlow={0.4 + (1 - daylight) * 0.6}
              glowColor={palette.screenGlow}
              frame={f}
              seed={3}
            />
          }
        />
      </Camera>
      <Atmosphere palette={palette} sunLeak={daylight * 0.6} />
      <SceneTexts scene={scene} palette={palette} />
    </AbsoluteFill>
  );
};
