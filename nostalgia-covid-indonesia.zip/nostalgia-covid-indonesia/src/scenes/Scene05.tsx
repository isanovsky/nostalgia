import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { CityShot } from "../components/CityShot";
import { Atmosphere, CITY_FOCUS } from "../components/Environment";
import { SceneTexts } from "../components/OnScreenText";
import { progress } from "../lib/anim";
import { mixPalette, PALETTES } from "../theme";
import { getBeat, getScene, getUi, sceneDuration } from "../timing";

const scene = getScene("s05");
const SIGNS = { school: getUi(scene, "school"), mall: getUi(scene, "mall"), station: getUi(scene, "station") };
const DURATION = sceneDuration(scene);

export const Scene05: React.FC = () => {
  const f = useCurrentFrame();
  const palette = mixPalette(PALETTES.muted, PALETTES.warm, progress(f, 0, 90));
  const life = progress(f, 0, getBeat(scene, "lifeReturnEnd"));
  const darken =
    progress(f, getBeat(scene, "darkenStart"), getBeat(scene, "darkenEnd")) * 0.8 +
    progress(f, getBeat(scene, "fadeOutStart"), DURATION) * 0.2;
  const { street, overview } = CITY_FOCUS;
  return (
    <AbsoluteFill>
      <CityShot
        palette={palette}
        animFrame={scene.from + f}
        density={life}
        masks={0.6}
        signs={SIGNS}
        t={f}
        sun={1}
        keys={[
          { t: 0, x: street.x, y: street.y, zoom: 1.7 },
          { t: getBeat(scene, "pullOutEnd"), x: overview.x, y: overview.y - 30, zoom: 0.58 },
          { t: DURATION, x: overview.x, y: overview.y - 40, zoom: 0.55 },
        ]}
      />
      <Atmosphere palette={palette} sunLeak={1} darken={darken} />
      <SceneTexts scene={scene} palette={palette} />
    </AbsoluteFill>
  );
};
