import React from "react";
import { AbsoluteFill } from "remotion";
import { cameraAt, CamKey } from "../lib/anim";
import { Camera } from "./Camera";
import { City, CityProps, Sky } from "./Environment";

type CityShotProps = Omit<CityProps, "frame"> & {
  /** Frame that drives the city's own animation (traffic, trees). Use a global frame for continuity across shots. */
  animFrame: number;
  /** Camera keys and the current key position. */
  keys: CamKey[];
  t: number;
  sun?: number;
};

/** Sky + city framed by a camera. Shared by Scenes 01, 03 and 05 so the location never changes. */
export const CityShot: React.FC<CityShotProps> = ({ animFrame, keys, t, sun = 1, palette, ...city }) => {
  const cam = cameraAt(keys, t);
  return (
    <AbsoluteFill>
      <Sky palette={palette} frame={animFrame} camX={cam.x - 1200} camY={cam.y - 700} sun={sun} />
      <Camera keys={keys} t={t} driftFrame={animFrame}>
        <City palette={palette} frame={animFrame} {...city} />
      </Camera>
    </AbsoluteFill>
  );
};
