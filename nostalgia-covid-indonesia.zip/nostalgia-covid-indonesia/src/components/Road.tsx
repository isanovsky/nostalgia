import React from "react";
import { IsoProjector } from "../lib/iso";
import { Palette } from "../theme";

type RoadProps = {
  iso: IsoProjector;
  palette: Palette;
  /** Rectangle on the grid. The long side decides the lane-marking direction. */
  x0: number;
  y0: number;
  x1: number;
  y1: number;
  sidewalk?: number;
};

const rect = (iso: IsoProjector, x0: number, y0: number, x1: number, y1: number) =>
  iso.pts(iso.p(x0, y0), iso.p(x1, y0), iso.p(x1, y1), iso.p(x0, y1));

/** Asphalt road with sidewalks and dashed centre line. */
export const Road: React.FC<RoadProps> = ({ iso, palette, x0, y0, x1, y1, sidewalk = 0.24 }) => {
  const alongX = x1 - x0 > y1 - y0;
  const dashes: React.ReactNode[] = [];
  if (alongX) {
    const cy = (y0 + y1) / 2;
    for (let x = x0 + 0.2; x < x1 - 0.3; x += 0.7) {
      dashes.push(<polygon key={x} points={rect(iso, x, cy - 0.025, x + 0.32, cy + 0.025)} fill={palette.roadLine} opacity={0.85} />);
    }
  } else {
    const cx = (x0 + x1) / 2;
    for (let y = y0 + 0.2; y < y1 - 0.3; y += 0.7) {
      dashes.push(<polygon key={y} points={rect(iso, cx - 0.025, y, cx + 0.025, y + 0.32)} fill={palette.roadLine} opacity={0.85} />);
    }
  }
  return (
    <g>
      {alongX ? (
        <>
          <polygon points={rect(iso, x0, y0 - sidewalk, x1, y0)} fill={palette.sidewalk} />
          <polygon points={rect(iso, x0, y1, x1, y1 + sidewalk)} fill={palette.sidewalk} />
        </>
      ) : (
        <>
          <polygon points={rect(iso, x0 - sidewalk, y0, x0, y1)} fill={palette.sidewalk} />
          <polygon points={rect(iso, x1, y0, x1 + sidewalk, y1)} fill={palette.sidewalk} />
        </>
      )}
      <polygon points={rect(iso, x0, y0, x1, y1)} fill={palette.road} />
      {dashes}
    </g>
  );
};

/** Zebra crossing across a road segment. */
export const Crosswalk: React.FC<{ iso: IsoProjector; palette: Palette; x0: number; y0: number; x1: number; y1: number; alongX: boolean }> = ({
  iso,
  palette,
  x0,
  y0,
  x1,
  y1,
  alongX,
}) => {
  const stripes: React.ReactNode[] = [];
  const n = 6;
  for (let i = 0; i < n; i++) {
    const t0 = i / n + 0.03;
    const t1 = t0 + 0.5 / n;
    stripes.push(
      <polygon
        key={i}
        points={
          alongX
            ? rect(iso, x0 + (x1 - x0) * t0, y0, x0 + (x1 - x0) * t1, y1)
            : rect(iso, x0, y0 + (y1 - y0) * t0, x1, y0 + (y1 - y0) * t1)
        }
        fill={palette.roadLine}
        opacity={0.9}
      />,
    );
  }
  return <g>{stripes}</g>;
};

/** Railway along the x axis. */
export const Rail: React.FC<{ iso: IsoProjector; palette: Palette; x0: number; x1: number; y: number }> = ({ iso, palette, x0, x1, y }) => {
  const sleepers: React.ReactNode[] = [];
  for (let x = x0; x < x1; x += 0.22) {
    sleepers.push(<polygon key={x} points={rect(iso, x, y - 0.02, x + 0.07, y + 0.42)} fill={palette.woodDark} opacity={0.7} />);
  }
  const [a1, b1] = iso.p(x0, y + 0.08);
  const [a2, b2] = iso.p(x1, y + 0.08);
  const [c1, d1] = iso.p(x0, y + 0.32);
  const [c2, d2] = iso.p(x1, y + 0.32);
  return (
    <g>
      <polygon points={rect(iso, x0, y - 0.1, x1, y + 0.52)} fill={palette.rail} opacity={0.55} />
      {sleepers}
      <line x1={a1} y1={b1} x2={a2} y2={b2} stroke={palette.blueGray} strokeWidth={2.2} />
      <line x1={c1} y1={d1} x2={c2} y2={d2} stroke={palette.blueGray} strokeWidth={2.2} />
    </g>
  );
};

/** Flat ground rectangle on the grid (fields, plazas, platforms). */
export const GroundRect: React.FC<{ iso: IsoProjector; x0: number; y0: number; x1: number; y1: number; fill: string; opacity?: number }> = ({
  iso,
  x0,
  y0,
  x1,
  y1,
  fill,
  opacity = 1,
}) => <polygon points={rect(iso, x0, y0, x1, y1)} fill={fill} opacity={opacity} />;
