import React from "react";
import { AbsoluteFill, interpolate, Sequence, useCurrentFrame } from "remotion";
import { CLAMP, EASE } from "../lib/anim";
import { Transition, TRANSITION_FRAMES } from "../timing";

const TransitionIn: React.FC<{ type: Transition; children: React.ReactNode }> = ({ type, children }) => {
  const frame = useCurrentFrame();
  const T = TRANSITION_FRAMES;
  if (type === "cut") return <AbsoluteFill>{children}</AbsoluteFill>;
  if (type === "dissolve") {
    return (
      <AbsoluteFill style={{ opacity: interpolate(frame, [0, T], [0, 1], { ...CLAMP, easing: EASE }) }}>
        {children}
      </AbsoluteFill>
    );
  }
  // "dip": darken the outgoing image, then reveal the incoming one from dark.
  return (
    <AbsoluteFill
      style={{
        opacity: interpolate(frame, [0, T / 2], [0, 1], CLAMP),
        backgroundColor: "#1c2430",
      }}
    >
      <AbsoluteFill style={{ opacity: interpolate(frame, [T / 2, T], [0, 1], { ...CLAMP, easing: EASE }) }}>
        {children}
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

export type LayerItem = {
  key: string;
  from: number;
  to: number;
  transition: Transition;
  node: React.ReactNode;
};

/**
 * Plays contiguous items in order. Each incoming item is layered above the
 * outgoing one for TRANSITION_FRAMES, which keeps rendering underneath.
 */
export const LayeredTimeline: React.FC<{ items: LayerItem[] }> = ({ items }) => (
  <>
    {items.map((item, i) => {
      const isLast = i === items.length - 1;
      return (
        <Sequence
          key={item.key}
          name={item.key}
          from={item.from}
          durationInFrames={item.to - item.from + (isLast ? 0 : TRANSITION_FRAMES)}
        >
          <TransitionIn type={i === 0 && item.transition !== "dip" ? "cut" : item.transition}>{item.node}</TransitionIn>
        </Sequence>
      );
    })}
  </>
);
