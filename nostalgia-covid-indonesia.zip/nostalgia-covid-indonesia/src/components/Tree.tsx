import React from "react";
import { sway } from "../lib/anim";
import { tint } from "../lib/color";
import { Palette } from "../theme";

type TreeProps = {
  /** Screen position of the trunk base. */
  bx: number;
  by: number;
  size?: number;
  palette: Palette;
  frame: number;
  seed: number;
  kind?: "round" | "cone";
  /** Wind strength multiplier. */
  wind?: number;
};

const poly = (cx: number, cy: number, r: number, sides: number, seed: number, rot = 0) => {
  const out: string[] = [];
  for (let i = 0; i < sides; i++) {
    const a = rot + (i / sides) * Math.PI * 2;
    const jitter = 1 + Math.sin(seed * 3.7 + i * 1.9) * 0.07;
    out.push(`${(cx + Math.cos(a) * r * jitter).toFixed(1)},${(cy + Math.sin(a) * r * jitter * 0.92).toFixed(1)}`);
  }
  return out.join(" ");
};

/** Low-poly tree with faceted foliage and a gentle wind sway. */
export const Tree: React.FC<TreeProps> = ({ bx, by, size = 1, palette, frame, seed, kind = "round", wind = 1 }) => {
  const s = size;
  const angle = sway(frame, 0.045, seed) * 1.8 * wind;
  const trunkH = 16 * s;
  const fy = by - trunkH - 18 * s;
  const r = 21 * s;
  return (
    <g>
      <ellipse cx={bx - 6 * s} cy={by + 2 * s} rx={22 * s} ry={8 * s} fill={palette.shadow} />
      <g transform={`rotate(${angle.toFixed(2)} ${bx} ${by})`}>
        <rect x={bx - 3 * s} y={by - trunkH - 4 * s} width={6 * s} height={trunkH + 4 * s} rx={2 * s} fill={palette.trunk} />
        {kind === "round" ? (
          <g>
            <polygon points={poly(bx, fy, r, 7, seed, 0.3)} fill={palette.treeDark} />
            <polygon
              points={`${bx - r * 0.95},${fy - r * 0.05} ${bx - r * 0.55},${fy - r * 0.8} ${bx + r * 0.25},${fy - r * 0.92} ${bx + r * 0.1},${fy - r * 0.1} ${bx - r * 0.45},${fy + r * 0.35}`}
              fill={palette.treeLight}
            />
            <polygon points={poly(bx + r * 0.25, fy - r * 0.55, r * 0.55, 6, seed + 1, 0.2)} fill={palette.treeLight} />
            <polygon
              points={`${bx - r * 0.1},${fy - r * 0.95} ${bx + r * 0.45},${fy - r * 1.02} ${bx + r * 0.2},${fy - r * 0.6}`}
              fill={tint(palette.treeLight, 0.3)}
              opacity={0.8}
            />
          </g>
        ) : (
          <g>
            <polygon points={`${bx},${fy - r * 1.9} ${bx + r * 0.95},${fy + r * 0.6} ${bx - r * 0.95},${fy + r * 0.6}`} fill={palette.treeDark} />
            <polygon points={`${bx},${fy - r * 1.9} ${bx - r * 0.95},${fy + r * 0.6} ${bx - r * 0.05},${fy + r * 0.45}`} fill={palette.treeLight} />
            <polygon
              points={`${bx},${fy - r * 1.9} ${bx - r * 0.35},${fy - r * 0.6} ${bx - r * 0.05},${fy - r * 0.7}`}
              fill={tint(palette.treeLight, 0.3)}
              opacity={0.7}
            />
          </g>
        )}
      </g>
    </g>
  );
};
