import React from "react";
import { useVideoConfig } from "remotion";
import { fitFontSize } from "../lib/anim";
import { shade, tint } from "../lib/color";
import { FONT_STACK, Palette } from "../theme";
import { Tree } from "./Tree";
import { SideCar } from "./Vehicle";

/**
 * Elevation-view street, drawn at one consistent real-world scale:
 * STREET_PX_PER_METRE pixels per metre. Characters, cars and buildings all
 * derive their size from it, so a person (1.7 m) is shorter than a car's
 * length, about as tall as a car's roof plus a head, and well below the eaves.
 */
export const STREET_PX_PER_METRE = 125;
const M = STREET_PX_PER_METRE;

const SIDEWALK_Y = 1300;
const ROAD_TOP = 1440;
const ROAD_BOTTOM = 1800;
/** Feet line for people walking on the sidewalk. */
export const STREET_SIDEWALK_Y = SIDEWALK_Y + 72;

/** Character scale for a person of the given height (a standing Character is ~225 units tall at scale 1, a child ~230). */
export const streetScale = (heightMetres: number, child = false) => (heightMetres * M) / (child ? 230 : 225);

type Facade = { x: number; w: number; h: number; wall: keyof Palette; roof?: keyof Palette; kind: "office" | "house" | "shop" | "school" };

// widths / heights in metres
const FACADES: Facade[] = [
  { x: -3.5, w: 6.0, h: 14, wall: "teal", kind: "office" },
  { x: 2.8, w: 4.6, h: 3.6, wall: "beige", roof: "teal", kind: "shop" },
  { x: 7.8, w: 10.5, h: 7.0, wall: "cream", roof: "roofRed", kind: "school" },
  { x: 18.8, w: 5.2, h: 3.2, wall: "pink", roof: "roofRed", kind: "house" },
  { x: 24.4, w: 5.0, h: 3.2, wall: "teal", roof: "roofTeal", kind: "house" },
  { x: 29.8, w: 6.0, h: 12, wall: "beige", kind: "office" },
  { x: 36.2, w: 5.0, h: 3.2, wall: "cream", roof: "pink", kind: "house" },
];

const DEPTH_X = 0.7 * M;
const DEPTH_Y = -0.4 * M;

const FacadeView: React.FC<{ f: Facade; palette: Palette; schoolSign: string }> = ({ f, palette, schoolSign }) => {
  const wall = palette[f.wall];
  const x = f.x * M;
  const w = f.w * M;
  const h = f.h * M;
  const top = SIDEWALK_Y - h;
  const windows: React.ReactNode[] = [];
  const winW = 1.1 * M;
  const winH = 1.4 * M;
  if (f.kind === "office" || f.kind === "school") {
    const floorH = 3.5 * M;
    const cols = Math.max(1, Math.floor(f.w / 1.9));
    const floors = Math.floor(f.h / 3.5);
    const gap = (w - cols * winW) / (cols + 1);
    for (let r = 0; r < floors; r++) {
      for (let c = 0; c < cols; c++) {
        if (f.kind === "school" && r === 0 && c === Math.floor(cols / 2)) continue; // entrance
        windows.push(
          <rect
            key={`${r}-${c}`}
            x={x + gap + c * (winW + gap)}
            y={SIDEWALK_Y - (r + 1) * floorH + 0.9 * M}
            width={winW}
            height={winH}
            rx={6}
            fill={(r + c) % 4 === 0 ? tint(palette.glass, 0.3) : palette.glass}
          />,
        );
      }
    }
    if (f.kind === "school") {
      windows.push(<rect key="door" x={x + w / 2 - 0.9 * M} y={SIDEWALK_Y - 2.4 * M} width={1.8 * M} height={2.4 * M} rx={6} fill={palette.woodDark} />);
    }
  } else {
    windows.push(<rect key="w1" x={x + 0.5 * M} y={top + 0.8 * M} width={winW} height={winH * 0.85} rx={6} fill={palette.glass} />);
    windows.push(<rect key="w2" x={x + w - 0.5 * M - winW} y={top + 0.8 * M} width={winW} height={winH * 0.85} rx={6} fill={palette.glass} />);
    windows.push(<rect key="d" x={x + w / 2 - 0.45 * M} y={SIDEWALK_Y - 2.1 * M} width={0.9 * M} height={2.1 * M} rx={6} fill={palette.woodDark} />);
  }
  const signW = 4.2 * M;
  return (
    <g>
      {/* side and top faces give the facade depth */}
      <polygon points={`${x + w},${top} ${x + w + DEPTH_X},${top + DEPTH_Y} ${x + w + DEPTH_X},${SIDEWALK_Y + DEPTH_Y} ${x + w},${SIDEWALK_Y}`} fill={shade(wall, 0.22)} />
      <rect x={x} y={top} width={w} height={h} fill={wall} />
      <rect x={x} y={top} width={w} height={0.18 * M} fill={tint(wall, 0.35)} opacity={0.6} />
      <rect x={x} y={SIDEWALK_Y - 0.3 * M} width={w} height={0.3 * M} fill={shade(wall, 0.3)} opacity={0.35} />
      {f.roof ? (
        <polygon
          points={`${x - 0.3 * M},${top} ${x + w + 0.3 * M},${top} ${x + w + DEPTH_X},${top + DEPTH_Y - 1.2 * M} ${x + DEPTH_X - 0.3 * M},${top + DEPTH_Y - 1.2 * M}`}
          fill={palette[f.roof]}
        />
      ) : (
        <polygon points={`${x},${top} ${x + w},${top} ${x + w + DEPTH_X},${top + DEPTH_Y} ${x + DEPTH_X},${top + DEPTH_Y}`} fill={tint(wall, 0.3)} />
      )}
      {windows}
      {f.kind === "shop" ? (
        <g>
          <rect x={x - 0.1 * M} y={SIDEWALK_Y - 2.7 * M} width={w + 0.2 * M} height={0.45 * M} fill={palette.teal} />
          {Array.from({ length: 8 }).map((_, i) => (
            <rect key={i} x={x - 0.1 * M + i * ((w + 0.2 * M) / 8)} y={SIDEWALK_Y - 2.7 * M} width={(w + 0.2 * M) / 16} height={0.45 * M} fill={palette.cream} opacity={0.9} />
          ))}
        </g>
      ) : null}
      {f.kind === "school" ? (
        <g>
          <rect x={x + w / 2 - signW / 2} y={SIDEWALK_Y - 3.4 * M} width={signW} height={0.7 * M} rx={10} fill={palette.uiDark} />
          <text
            x={x + w / 2}
            y={SIDEWALK_Y - 3.4 * M + 0.48 * M}
            textAnchor="middle"
            fontFamily={FONT_STACK}
            fontWeight={800}
            fontSize={fitFontSize(schoolSign, signW - 40, 46, 0.7, 6)}
            letterSpacing={6}
            fill={palette.cream}
          >
            {schoolSign}
          </text>
        </g>
      ) : null}
    </g>
  );
};

type StreetProps = {
  palette: Palette;
  frame: number;
  /** World-x of the camera centre. */
  camX: number;
  schoolSign: string;
  /** People on the sidewalk, already positioned in world coordinates. */
  children?: React.ReactNode;
};

const CAR_SCALE = 1.95; // SideCar path is ~244 units long -> ~4.75 m
const ANGKOT_SCALE = 2.0; // ~262 units -> ~4.2 m van

export const Street: React.FC<StreetProps> = ({ palette, frame, camX, schoolSign, children }) => {
  const { width, height } = useVideoConfig();
  const shift = (factor: number) => `translate(${(width / 2 - camX * factor).toFixed(1)} 0)`;
  const nearLane = ROAD_BOTTOM - 40;
  const farLane = ROAD_TOP + 150;
  const cars = [
    { x0: 3200, v: -9, color: palette.car1, lane: farLane, kind: "car" as const, scale: CAR_SCALE },
    { x0: -900, v: 8, color: palette.teal, lane: nearLane, kind: "angkot" as const, scale: ANGKOT_SCALE },
    { x0: 4600, v: -8.5, color: palette.car3, lane: farLane, kind: "car" as const, scale: CAR_SCALE },
  ];
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} style={{ position: "absolute", inset: 0 }}>
      {/* distant skyline */}
      <g transform={shift(0.3)}>
        {Array.from({ length: 14 }).map((_, i) => (
          <rect key={i} x={-900 + i * 260} y={SIDEWALK_Y - 1100 - ((i * 97) % 300)} width={220} height={1500} fill={palette.hillFar} opacity={0.7} />
        ))}
      </g>
      <g transform={shift(1)}>
        {FACADES.map((f) => (
          <FacadeView key={f.x} f={f} palette={palette} schoolSign={schoolSign} />
        ))}
        {/* sidewalk */}
        <rect x={-1500} y={SIDEWALK_Y} width={7000} height={ROAD_TOP - SIDEWALK_Y - 18} fill={palette.sidewalk} />
        {Array.from({ length: 70 }).map((_, i) => (
          <line key={i} x1={-1500 + i * 100} y1={SIDEWALK_Y} x2={-1550 + i * 100} y2={ROAD_TOP - 18} stroke={shade(palette.sidewalk, 0.1)} strokeWidth={2} opacity={0.5} />
        ))}
        <rect x={-1500} y={ROAD_TOP - 18} width={7000} height={18} fill={shade(palette.sidewalk, 0.25)} />
        {/* road */}
        <rect x={-1500} y={ROAD_TOP} width={7000} height={ROAD_BOTTOM - ROAD_TOP} fill={palette.road} />
        {Array.from({ length: 40 }).map((_, i) => (
          <rect key={i} x={-1500 + i * 2 * M} y={(ROAD_TOP + ROAD_BOTTOM) / 2 - 5} width={M} height={10} fill={palette.roadLine} opacity={0.8} />
        ))}
        {[1.2, 17.8, 33.5].map((mx, i) => {
          const x = mx * M;
          return (
            <g key={mx}>
              <Tree bx={x + 2.6 * M} by={SIDEWALK_Y + 30} size={8} palette={palette} frame={frame} seed={20 + i} />
              <line x1={x} y1={ROAD_TOP - 18} x2={x} y2={ROAD_TOP - 6 * M} stroke={palette.blueGray} strokeWidth={10} />
              <line x1={x} y1={ROAD_TOP - 6 * M} x2={x + 0.6 * M} y2={ROAD_TOP - 6.2 * M} stroke={palette.blueGray} strokeWidth={10} />
              <circle cx={x + 0.65 * M} cy={ROAD_TOP - 6.15 * M} r={16} fill={palette.cream} />
            </g>
          );
        })}
        {children}
        {cars.map((c, i) => (
          <SideCar key={i} x={c.x0 + frame * c.v} y={c.lane} color={c.color} palette={palette} scale={c.scale} kind={c.kind} />
        ))}
        {/* far-side verge */}
        <rect x={-1500} y={ROAD_BOTTOM} width={7000} height={height - ROAD_BOTTOM + 600} fill={palette.ground} />
        <rect x={-1500} y={ROAD_BOTTOM} width={7000} height={16} fill={shade(palette.sidewalk, 0.15)} />
      </g>
    </svg>
  );
};
