import React from "react";
import { tint } from "../lib/color";
import { Palette } from "../theme";

export type Expression = "neutral" | "happy" | "confused" | "surprised" | "worried" | "sad" | "tired" | "relieved";
export type Pose = "stand" | "sit" | "walk";
export type Holding = "none" | "laptopBag" | "phone" | "books" | "mug" | "typing" | "chinRest";

export type Outfit = {
  skin: string;
  skinShade: string;
  hair: string;
  shirt: string;
  shirtShade: string;
  pants: string;
  hairStyle: "short" | "bob";
  skirt?: boolean;
  backpack?: string;
};

/** Consistent cast. Colours come from the palette so the grade affects them too. */
export const castOutfits = (palette: Palette) => ({
  raka: {
    skin: palette.skin,
    skinShade: palette.skinShade,
    hair: palette.hair,
    shirt: palette.shirt,
    shirtShade: palette.shirtShade,
    pants: palette.pants,
    hairStyle: "short",
  } as Outfit,
  dinda: {
    skin: palette.skin,
    skinShade: palette.skinShade,
    hair: palette.hair,
    shirt: palette.uniformWhite,
    shirtShade: palette.gray,
    pants: palette.uniformRed,
    hairStyle: "bob",
    skirt: true,
    backpack: palette.car3,
  } as Outfit,
  student: (i: number): Outfit => ({
    skin: i % 3 === 0 ? palette.skinShade : palette.skin,
    skinShade: palette.skinShade,
    hair: palette.hair,
    shirt: palette.uniformWhite,
    shirtShade: palette.gray,
    pants: palette.uniformRed,
    hairStyle: i % 2 === 0 ? "short" : "bob",
    skirt: i % 2 === 1,
  }),
});

type CharacterProps = {
  x: number;
  y: number;
  scale?: number;
  outfit: Outfit;
  pose: Pose;
  facing?: 1 | -1;
  /** -1 (looks screen-left) .. 1 (looks screen-right). */
  headTurn?: number;
  /** Extra head tilt in degrees. */
  headTilt?: number;
  expression: Expression;
  holding?: Holding;
  frame: number;
  seed?: number;
  /** 0..1 tiredness posture. */
  slump?: number;
  /** 0..1 how much the hair has grown out. */
  hairGrowth?: number;
  child?: boolean;
  /** Walk cycle phase multiplier (frames to radians). */
  walkSpeed?: number;
  /** Colour for the laptop / phone glow on the face, 0..1 */
  screenGlow?: number;
  glowColor?: string;
  /** Surgical face mask (2020 era). */
  mask?: boolean;
};

const INK = "#2b2422";

const Eyes: React.FC<{ ex: number; ey: number; expression: Expression; blink: boolean }> = ({ ex, ey, expression, blink }) => {
  const sides = [-1, 1];
  if (blink || expression === "relieved") {
    return (
      <g stroke={INK} strokeWidth={2.6} strokeLinecap="round" fill="none">
        {sides.map((s) => (
          <path key={s} d={`M ${ex + s * 11 - 4.5} ${ey + 1} Q ${ex + s * 11} ${ey + (expression === "relieved" ? 4.5 : 2.5)} ${ex + s * 11 + 4.5} ${ey + 1}`} />
        ))}
      </g>
    );
  }
  const ry = expression === "surprised" ? 6.2 : expression === "tired" ? 3 : expression === "sad" || expression === "worried" ? 4.6 : 5;
  const rx = expression === "surprised" ? 4.4 : 3.7;
  return (
    <g>
      {sides.map((s) => (
        <g key={s}>
          <ellipse cx={ex + s * 11} cy={ey} rx={rx} ry={ry} fill={INK} />
          <circle cx={ex + s * 11 + 1.3} cy={ey - ry * 0.4} r={1.3} fill="#ffffff" opacity={0.9} />
          {expression === "tired" ? (
            <path d={`M ${ex + s * 11 - 5} ${ey - 2.5} L ${ex + s * 11 + 5} ${ey - 2.5}`} stroke={INK} strokeWidth={2} strokeLinecap="round" />
          ) : null}
        </g>
      ))}
    </g>
  );
};

const BROWS: Record<Expression, [number, number, number, number]> = {
  // [outerY, innerY] for the left brow (mirrored for the right), plus right overrides for asymmetry
  neutral: [-9, -9, -9, -9],
  happy: [-10, -11, -11, -10],
  surprised: [-14, -15, -15, -14],
  worried: [-8, -12.5, -12.5, -8],
  sad: [-7.5, -12, -12, -7.5],
  confused: [-11, -12.5, -9, -9.5],
  tired: [-6.5, -7.5, -7.5, -6.5],
  relieved: [-10, -10.5, -10.5, -10],
};

const Brows: React.FC<{ ex: number; ey: number; expression: Expression; hair: string }> = ({ ex, ey, expression, hair }) => {
  const [lo, li, ri, ro] = BROWS[expression];
  return (
    <g stroke={hair} strokeWidth={3} strokeLinecap="round">
      <line x1={ex - 16} y1={ey + lo} x2={ex - 6} y2={ey + li} />
      <line x1={ex + 6} y1={ey + ri} x2={ex + 16} y2={ey + ro} />
    </g>
  );
};

const Mouth: React.FC<{ mx: number; my: number; expression: Expression }> = ({ mx, my, expression }) => {
  const stroke = { stroke: "#8a4a44", strokeWidth: 2.8, strokeLinecap: "round" as const, fill: "none" };
  switch (expression) {
    case "happy":
      return <path d={`M ${mx - 9} ${my - 2} Q ${mx} ${my + 9} ${mx + 9} ${my - 2} Z`} fill="#9b4d47" stroke="#8a4a44" strokeWidth={1.5} />;
    case "relieved":
      return <path d={`M ${mx - 7} ${my - 1} Q ${mx} ${my + 5} ${mx + 7} ${my - 1}`} {...stroke} />;
    case "surprised":
      return <ellipse cx={mx} cy={my + 1} rx={4.5} ry={6} fill="#7d3f3a" />;
    case "worried":
      return <path d={`M ${mx - 7} ${my + 2} Q ${mx - 3.5} ${my - 1.5} ${mx} ${my + 1} Q ${mx + 3.5} ${my + 3.5} ${mx + 7} ${my}`} {...stroke} />;
    case "sad":
      return <path d={`M ${mx - 7} ${my + 3} Q ${mx} ${my - 3.5} ${mx + 7} ${my + 3}`} {...stroke} />;
    case "tired":
      return <path d={`M ${mx - 5} ${my + 1} L ${mx + 5} ${my + 1.5}`} {...stroke} />;
    case "confused":
      return <path d={`M ${mx - 6} ${my + 2} Q ${mx} ${my - 1} ${mx + 7} ${my - 2}`} {...stroke} />;
    default:
      return <path d={`M ${mx - 6} ${my} Q ${mx} ${my + 2} ${mx + 6} ${my}`} {...stroke} />;
  }
};

const Limb: React.FC<{ a: [number, number]; b: [number, number]; c: [number, number]; upper: string; lower: string; width: number; end?: string; endR?: number }> = ({
  a,
  b,
  c,
  upper,
  lower,
  width,
  end,
  endR = 6.5,
}) => (
  <g strokeLinecap="round" fill="none">
    <line x1={a[0]} y1={a[1]} x2={b[0]} y2={b[1]} stroke={upper} strokeWidth={width} />
    <line x1={b[0]} y1={b[1]} x2={c[0]} y2={c[1]} stroke={lower} strokeWidth={width * 0.85} />
    {end ? <circle cx={c[0]} cy={c[1]} r={endR} fill={end} /> : null}
  </g>
);

/**
 * Stylised cartoon human, drawn front / three-quarter. Origin = point between the feet.
 * Standing adult is ~250 units tall.
 */
export const Character: React.FC<CharacterProps> = ({
  x,
  y,
  scale = 1,
  outfit,
  pose,
  facing = 1,
  headTurn = 0,
  headTilt = 0,
  expression,
  holding = "none",
  frame,
  seed = 1,
  slump = 0,
  hairGrowth = 0,
  child = false,
  walkSpeed = 0.32,
  screenGlow = 0,
  glowColor = "#bfe7ff",
  mask = false,
}) => {
  const turn = headTurn * facing;
  const breathe = Math.sin(frame * 0.08 + seed) * 1.2;
  const walking = pose === "walk";
  const phase = frame * walkSpeed + seed;
  const stepBob = walking ? Math.abs(Math.sin(phase)) * -5 : 0;
  const blink = (frame + seed * 37) % 97 < 4;

  const hipY = pose === "sit" ? -66 : -94;
  const torsoTop = hipY - 64 + slump * 6;
  const shoulderY = torsoTop + 10 + slump * 3;
  const headR = child ? 35 : 31;
  const hc = torsoTop - headR + 2 + slump * 6 + breathe * 0.3;
  const headSway = Math.sin(frame * 0.05 + seed * 2) * 1.6 + headTilt + slump * 5 + (holding === "chinRest" ? 8 : 0);

  // legs
  const legSwing = walking ? Math.sin(phase) * 24 : 0;
  const leg = (side: number, swing: number) => {
    const hx = side * 11;
    if (pose === "sit") {
      return { hip: [hx, hipY] as [number, number], knee: [hx * 1.45, hipY + 18] as [number, number], foot: [hx * 1.45, -4] as [number, number] };
    }
    const rad = (swing * Math.PI) / 180;
    const knee: [number, number] = [hx + Math.sin(rad) * 44, hipY + Math.cos(rad) * 44];
    const rad2 = rad + (walking ? Math.max(0, -Math.sin(phase + (side > 0 ? 0 : Math.PI))) * 0.5 : 0);
    const foot: [number, number] = [knee[0] + Math.sin(rad2) * 46, knee[1] + Math.cos(rad2) * 46];
    return { hip: [hx, hipY] as [number, number], knee, foot };
  };
  const legBack = leg(-1, walking ? -legSwing : 0);
  const legFront = leg(1, walking ? legSwing : 0);

  // arms
  const sx = 27;
  type Arm = { elbow: [number, number]; hand: [number, number] };
  const armSwing = walking ? Math.sin(phase) * 16 : Math.sin(frame * 0.06 + seed) * 1.5;
  const typingTap = Math.sin(frame * 1.4 + seed) * 2.5;
  const arms = ((): { l: Arm; r: Arm } => {
    switch (holding) {
      case "mug":
        return {
          l: { elbow: [-36, shoulderY + 38], hand: [-24, hipY - 6] },
          r: { elbow: [36, shoulderY + 40], hand: [16, shoulderY + 26] },
        };
      case "phone":
        return {
          l: { elbow: [-34, shoulderY + 42], hand: [-6, shoulderY + 34] },
          r: { elbow: [34, shoulderY + 42], hand: [6, shoulderY + 34] },
        };
      case "books":
        return {
          l: { elbow: [-36, shoulderY + 34], hand: [-24, shoulderY + 34] },
          r: { elbow: [36, shoulderY + 34], hand: [24, shoulderY + 34] },
        };
      case "typing":
        return {
          l: { elbow: [-38, shoulderY + 50], hand: [-16, shoulderY + 76 + typingTap] },
          r: { elbow: [38, shoulderY + 50], hand: [16, shoulderY + 76 - typingTap] },
        };
      case "chinRest":
        return {
          l: { elbow: [-36, shoulderY + 44], hand: [-16, shoulderY + 58] },
          r: { elbow: [26, shoulderY + 58], hand: [10, hc + headR * 0.95] },
        };
      case "laptopBag":
        return {
          l: { elbow: [-34 - armSwing * 0.3, shoulderY + 40], hand: [-32 - armSwing, shoulderY + 74] },
          r: { elbow: [34, shoulderY + 40], hand: [40, shoulderY + 64] },
        };
      default:
        return {
          l: { elbow: [-34 - armSwing * 0.3, shoulderY + 40], hand: [-32 - armSwing, shoulderY + 74] },
          r: { elbow: [34 + armSwing * 0.3, shoulderY + 40], hand: [32 + armSwing, shoulderY + 74] },
        };
    }
  })();

  const torsoPath = `M ${-28} ${torsoTop + 14} Q ${-30} ${torsoTop} ${-14} ${torsoTop} L 14 ${torsoTop} Q 30 ${torsoTop} 28 ${torsoTop + 14} L 25 ${hipY + 4} L -25 ${hipY + 4} Z`;
  const torsoShade = `M 10 ${torsoTop} L 14 ${torsoTop} Q 30 ${torsoTop} 28 ${torsoTop + 14} L 25 ${hipY + 4} L 8 ${hipY + 4} Z`;

  const ex = turn * 9;
  const ey = hc + 2;
  const growth = hairGrowth * 12;
  const r = headR;

  const hairPath =
    outfit.hairStyle === "short"
      ? `M ${-r - 1} ${hc + 4 + growth * 0.6} Q ${-r - 3} ${hc - r * 1.2 - growth * 0.4} ${turn * 4} ${hc - r * 1.12 - growth * 0.5} Q ${r + 3} ${hc - r * 1.2 - growth * 0.4} ${r + 1} ${hc + 4 + growth * 0.6} Q ${r * 0.75} ${hc - r * 0.5} ${turn * 10 + r * 0.25} ${hc - r * 0.62 + growth * 0.25} Q ${turn * 10 - r * 0.4} ${hc - r * 0.42 + growth * 0.3} ${-r * 0.8} ${hc - r * 0.4} Q ${-r * 0.95} ${hc - r * 0.1} ${-r - 1} ${hc + 4 + growth * 0.6} Z`
      : `M ${-r - 4} ${hc + 20} Q ${-r - 6} ${hc - r * 1.25} ${turn * 4} ${hc - r * 1.15} Q ${r + 6} ${hc - r * 1.25} ${r + 4} ${hc + 20} L ${r - 4} ${hc + 20} Q ${r * 0.7} ${hc - r * 0.35} ${turn * 10} ${hc - r * 0.5} Q ${-r * 0.7} ${hc - r * 0.35} ${-r + 4} ${hc + 20} Z`;

  const armColor = outfit.shirt;
  const drawArm = (arm: Arm, side: number) => (
    <Limb a={[side * sx, shoulderY]} b={arm.elbow} c={arm.hand} upper={armColor} lower={outfit.skin} width={13} end={outfit.skin} />
  );

  return (
    <g transform={`translate(${x} ${y + stepBob}) scale(${scale * facing} ${scale})`}>
      <ellipse cx={0} cy={0} rx={46} ry={10} fill="rgba(40,55,70,0.22)" />
      {/* backpack behind body */}
      {outfit.backpack ? <rect x={-40} y={torsoTop + 6} width={80} height={58} rx={16} fill={outfit.backpack} /> : null}

      {/* legs */}
      <Limb a={legBack.hip} b={legBack.knee} c={legBack.foot} upper={outfit.pants} lower={outfit.pants} width={child ? 15 : 19} />
      <ellipse cx={legBack.foot[0] + 6} cy={legBack.foot[1] + 2} rx={12} ry={6} fill={INK} />
      <Limb a={legFront.hip} b={legFront.knee} c={legFront.foot} upper={outfit.pants} lower={outfit.pants} width={child ? 15 : 19} />
      <ellipse cx={legFront.foot[0] + 6} cy={legFront.foot[1] + 2} rx={12} ry={6} fill={INK} />

      {holding !== "chinRest" ? drawArm(arms.l, -1) : null}

      <g transform={`rotate(${(slump * 3).toFixed(2)} 0 ${hipY})`}>
        {/* torso */}
        <path d={torsoPath} fill={outfit.shirt} />
        <path d={torsoShade} fill={outfit.shirtShade} opacity={0.75} />
        <path d={`M -9 ${torsoTop} L 0 ${torsoTop + 12} L 9 ${torsoTop} Z`} fill={outfit.skinShade} />
        {outfit.skirt ? (
          <path d={`M -26 ${hipY - 2} L 26 ${hipY - 2} L 34 ${hipY + (pose === "sit" ? 18 : 30)} L -34 ${hipY + (pose === "sit" ? 18 : 30)} Z`} fill={outfit.pants} />
        ) : (
          <rect x={-26} y={hipY - 6} width={52} height={10} rx={4} fill={outfit.pants} />
        )}
        {outfit.backpack ? (
          <g stroke={outfit.backpack} strokeWidth={6} strokeLinecap="round">
            <line x1={-16} y1={torsoTop + 2} x2={-18} y2={hipY - 8} />
            <line x1={16} y1={torsoTop + 2} x2={18} y2={hipY - 8} />
          </g>
        ) : null}
        {holding === "laptopBag" ? (
          <g>
            <line x1={-20} y1={torsoTop + 2} x2={30} y2={hipY - 22} stroke={INK} strokeWidth={5} opacity={0.75} />
            <rect x={22} y={hipY - 30} width={52} height={38} rx={6} fill="#4d5866" />
            <rect x={27} y={hipY - 36} width={42} height={8} rx={2} fill="#c9d1d8" />
            <rect x={22} y={hipY - 30} width={52} height={8} rx={4} fill="#5c6878" />
          </g>
        ) : null}

        {/* neck + head */}
        <rect x={-7} y={torsoTop - 12} width={14} height={16} fill={outfit.skinShade} />
        <g transform={`rotate(${headSway.toFixed(2)} 0 ${torsoTop})`}>
          {outfit.hairStyle === "bob" ? (
            <path d={`M ${-r - 4} ${hc - 6} Q ${-r - 8} ${hc + 30} ${-r + 6} ${hc + 26} L ${r - 6} ${hc + 26} Q ${r + 8} ${hc + 30} ${r + 4} ${hc - 6} Z`} fill={outfit.hair} />
          ) : null}
          <ellipse cx={-r + 1 - turn * 5} cy={hc + 4} rx={6} ry={8} fill={outfit.skinShade} />
          <ellipse cx={r - 1 - turn * 5} cy={hc + 4} rx={6} ry={8} fill={outfit.skinShade} />
          <circle cx={0} cy={hc} r={r} fill={outfit.skinShade} />
          <circle cx={-r * 0.08 + turn * 2} cy={hc - r * 0.05} r={r * 0.93} fill={outfit.skin} />
          {screenGlow > 0 ? <circle cx={0} cy={hc + 4} r={r * 0.9} fill={glowColor} opacity={screenGlow * 0.25} /> : null}
          <path d={hairPath} fill={outfit.hair} />
          {expression === "happy" || expression === "relieved" ? (
            <g fill="#f2a0a0" opacity={0.45}>
              <ellipse cx={ex - 17} cy={ey + 11} rx={6} ry={3.5} />
              <ellipse cx={ex + 17} cy={ey + 11} rx={6} ry={3.5} />
            </g>
          ) : null}
          <Brows ex={ex} ey={ey} expression={expression} hair={outfit.hair} />
          <Eyes ex={ex} ey={ey} expression={expression} blink={blink} />
          <path d={`M ${ex * 1.3 - 2} ${hc + 9} Q ${ex * 1.3 + 2} ${hc + 13} ${ex * 1.3 - 1} ${hc + 14}`} stroke={outfit.skinShade} strokeWidth={2.4} fill="none" strokeLinecap="round" />
          {mask ? (
            <g>
              <line x1={ex - 20} y1={hc + 8} x2={-r + 2 - turn * 5} y2={hc + 2} stroke="#cfe3ee" strokeWidth={2} />
              <line x1={ex + 20} y1={hc + 8} x2={r - 2 - turn * 5} y2={hc + 2} stroke="#cfe3ee" strokeWidth={2} />
              <path
                d={`M ${ex - 21} ${hc + 6} Q ${ex} ${hc + 2} ${ex + 21} ${hc + 6} L ${ex + 18} ${hc + 24} Q ${ex} ${hc + 32} ${ex - 18} ${hc + 24} Z`}
                fill="#e3f1f8"
                stroke="#bcd6e3"
                strokeWidth={1.2}
              />
              <path d={`M ${ex - 17} ${hc + 13} L ${ex + 17} ${hc + 13} M ${ex - 16} ${hc + 19} L ${ex + 16} ${hc + 19}`} stroke="#bcd6e3" strokeWidth={1.4} />
            </g>
          ) : (
            <Mouth mx={ex * 1.1} my={hc + 20} expression={expression} />
          )}
        </g>

        {/* front arm(s) and held objects */}
        {holding === "chinRest" ? drawArm(arms.l, -1) : null}
        {holding === "books" ? (
          <g>
            <rect x={-30} y={shoulderY + 18} width={60} height={11} rx={2} fill={tint(outfit.pants, 0.1)} />
            <rect x={-27} y={shoulderY + 29} width={56} height={10} rx={2} fill="#78a9d6" />
            <rect x={-29} y={shoulderY + 39} width={58} height={11} rx={2} fill="#f2c46d" />
          </g>
        ) : null}
        {holding === "phone" ? (
          <g>
            <rect x={-11} y={shoulderY + 14} width={22} height={36} rx={4} fill={INK} />
            <rect x={-9} y={shoulderY + 17} width={18} height={30} rx={2} fill={glowColor} opacity={0.9} />
          </g>
        ) : null}
        {holding === "mug" ? (
          <g>
            <rect x={8} y={shoulderY + 10} width={18} height={22} rx={3} fill="#f6efe2" />
            <path d={`M 26 ${shoulderY + 15} q 8 2 0 11`} stroke="#f6efe2" strokeWidth={3} fill="none" />
            <path
              d={`M 14 ${shoulderY + 4} q -3 -6 1 -11 M 20 ${shoulderY + 4} q 3 -6 -1 -11`}
              stroke="#ffffff"
              strokeWidth={2}
              fill="none"
              opacity={0.35 + Math.sin(frame * 0.15) * 0.15}
              strokeLinecap="round"
            />
          </g>
        ) : null}
        {drawArm(arms.r, 1)}
      </g>
    </g>
  );
};

type PedestrianProps = {
  sx: number;
  sy: number;
  frame: number;
  seed: number;
  shirt: string;
  pants: string;
  skin: string;
  hair: string;
  kid?: boolean;
  moving?: boolean;
  carry?: "none" | "bag" | "umbrella";
  umbrella?: string;
  opacity?: number;
  mask?: boolean;
};

/** Pedestrian size on the city grid: ~17 px for a 1.7 m adult (~8.8 px per metre, same as the vehicles). */
const PED_SCALE = 0.52;

/** Tiny figure for city-scale shots (~28 px tall). */
export const Pedestrian: React.FC<PedestrianProps> = ({
  sx,
  sy,
  frame,
  seed,
  shirt,
  pants,
  skin,
  hair,
  kid = false,
  moving = true,
  carry = "none",
  umbrella,
  opacity = 1,
  mask = false,
}) => {
  if (opacity <= 0.01) return null;
  const k = (kid ? 0.74 : 1) * PED_SCALE;
  const ph = frame * 0.38 + seed * 2.1;
  const swing = moving ? Math.sin(ph) * 2.6 : 0;
  const bob = moving ? -Math.abs(Math.sin(ph)) * 1.1 : Math.sin(frame * 0.07 + seed) * 0.3;
  return (
    <g opacity={opacity} transform={`translate(${sx.toFixed(1)} ${(sy + bob).toFixed(1)}) scale(${k})`}>
      <ellipse cx={-2} cy={1} rx={7} ry={2.6} fill="rgba(40,55,70,0.22)" />
      <line x1={-2} y1={-10} x2={-2 - swing} y2={0} stroke={pants} strokeWidth={3.2} strokeLinecap="round" />
      <line x1={2} y1={-10} x2={2 + swing} y2={0} stroke={pants} strokeWidth={3.2} strokeLinecap="round" />
      <rect x={-5.5} y={-23} width={11} height={14} rx={4} fill={shirt} />
      <circle cx={0} cy={-27.5} r={4.6} fill={skin} />
      <path d="M -4.8 -27.5 A 4.8 4.8 0 0 1 4.8 -27.5 Q 0 -30 -4.8 -27.5 Z" fill={hair} />
      {mask ? <rect x={-3.3} y={-27.2} width={6.6} height={3.4} rx={1.3} fill="#eef6fb" /> : null}
      {carry === "bag" ? <rect x={4} y={-17} width={5} height={7} rx={1} fill="#4d5866" /> : null}
      {carry === "umbrella" ? (
        <g>
          <line x1={3} y1={-18} x2={3} y2={-36} stroke="#4d5866" strokeWidth={1.2} />
          <path d="M -9 -35 Q 3 -47 15 -35 Z" fill={umbrella ?? shirt} />
        </g>
      ) : null}
    </g>
  );
};
