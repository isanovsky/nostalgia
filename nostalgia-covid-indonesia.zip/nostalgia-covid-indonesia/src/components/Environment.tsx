import React from "react";
import { AbsoluteFill, useVideoConfig } from "remotion";
import { rand, smoothstep, sway } from "../lib/anim";
import { shade, tint } from "../lib/color";
import { IsoProjector, makeIso } from "../lib/iso";
import { Palette } from "../theme";
import { Building, BuildingShadow, IsoBox } from "./Building";
import { Pedestrian } from "./Character";
import { Crosswalk, GroundRect, Rail, Road } from "./Road";
import { Tree } from "./Tree";
import { IsoTrain, IsoVehicle, VehicleKind } from "./Vehicle";

/* ------------------------------------------------------------------ */
/* Sky (screen space, with slow parallax)                              */
/* ------------------------------------------------------------------ */

type SkyProps = {
  palette: Palette;
  frame: number;
  /** Camera offset used for parallax, in world px. */
  camX?: number;
  camY?: number;
  sun?: number;
  birds?: boolean;
  stars?: number;
};

const Cloud: React.FC<{ x: number; y: number; s: number; color: string }> = ({ x, y, s, color }) => (
  <g transform={`translate(${x.toFixed(1)} ${y.toFixed(1)}) scale(${s})`}>
    <ellipse cx={0} cy={0} rx={120} ry={34} fill={color} opacity={0.9} />
    <ellipse cx={-40} cy={-22} rx={56} ry={40} fill={color} opacity={0.95} />
    <ellipse cx={30} cy={-30} rx={66} ry={50} fill={color} />
    <ellipse cx={86} cy={-8} rx={42} ry={28} fill={color} opacity={0.9} />
    <ellipse cx={10} cy={10} rx={118} ry={14} fill={shade(color, 0.08)} opacity={0.5} />
  </g>
);

export const Sky: React.FC<SkyProps> = ({ palette, frame, camX = 0, camY = 0, sun = 1, birds = true, stars = 0 }) => {
  const { width, height } = useVideoConfig();
  const px = -camX * 0.06;
  const py = -camY * 0.04;
  const clouds = [
    { x: 120, y: 300, s: 1.1, v: 0.22 },
    { x: 760, y: 200, s: 0.8, v: 0.16 },
    { x: 980, y: 470, s: 1.25, v: 0.26 },
    { x: 420, y: 560, s: 0.7, v: 0.12 },
    { x: -200, y: 680, s: 0.9, v: 0.18 },
  ];
  return (
    <AbsoluteFill>
      <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`}>
        <defs>
          <linearGradient id="sky-grad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={palette.skyTop} />
            <stop offset="0.75" stopColor={palette.skyBottom} />
          </linearGradient>
          <radialGradient id="sun-glow">
            <stop offset="0" stopColor={palette.sun} stopOpacity={0.95} />
            <stop offset="0.25" stopColor={palette.sun} stopOpacity={0.5} />
            <stop offset="1" stopColor={palette.sun} stopOpacity={0} />
          </radialGradient>
        </defs>
        <rect width={width} height={height} fill="url(#sky-grad)" />
        {stars > 0
          ? Array.from({ length: 40 }).map((_, i) => (
              <circle
                key={i}
                cx={rand(`star-x-${i}`) * width}
                cy={rand(`star-y-${i}`) * height * 0.45}
                r={1 + rand(`star-r-${i}`) * 1.6}
                fill="#ffffff"
                opacity={stars * (0.4 + 0.4 * Math.sin(frame * 0.1 + i))}
              />
            ))
          : null}
        <circle cx={860 + px * 0.5} cy={330 + py * 0.5} r={300} fill="url(#sun-glow)" opacity={sun} />
        <circle cx={860 + px * 0.5} cy={330 + py * 0.5} r={46} fill={palette.sun} opacity={sun * 0.9} />
        {clouds.map((c, i) => {
          const span = width + 600;
          const cx = ((((c.x + frame * c.v + px * (1 + i * 0.2)) % span) + span) % span) - 300;
          return <Cloud key={i} x={cx} y={c.y + py} s={c.s} color={palette.cloud} />;
        })}
        {birds ? <Birds frame={frame} color={shade(palette.skyTop, 0.55)} /> : null}
      </svg>
    </AbsoluteFill>
  );
};

/** A small flock crossing the sky, wings flapping. */
export const Birds: React.FC<{ frame: number; color: string; count?: number; originX?: number; originY?: number }> = ({
  frame,
  color,
  count = 4,
  originX = -80,
  originY = 520,
}) => (
  <g>
    {Array.from({ length: count }).map((_, i) => {
      const t = frame * 1.6 + i * 34;
      const x = originX + (t % 1500);
      const y = originY - (t % 1500) * 0.12 + Math.sin(frame * 0.05 + i) * 8 + i * 16;
      const flap = Math.sin(frame * 0.5 + i * 1.7) * 5;
      return (
        <path
          key={i}
          d={`M ${x - 10} ${y - flap} Q ${x - 4} ${y - 3} ${x} ${y} Q ${x + 4} ${y - 3} ${x + 10} ${y - flap}`}
          stroke={color}
          strokeWidth={2.4}
          fill="none"
          strokeLinecap="round"
          opacity={0.75}
        />
      );
    })}
  </g>
);

/** Full-frame atmosphere: haze at the horizon, colour grade, vignette, soft sun leak. */
export const Atmosphere: React.FC<{ palette: Palette; sunLeak?: number; darken?: number }> = ({ palette, sunLeak = 0.6, darken = 0 }) => {
  const { width, height } = useVideoConfig();
  return (
    <AbsoluteFill style={{ pointerEvents: "none" }}>
      <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`}>
        <defs>
          <radialGradient id="atm-vignette" cx="0.5" cy="0.5" r="0.75">
            <stop offset="0.55" stopColor={palette.vignette} stopOpacity={0} />
            <stop offset="1" stopColor={palette.vignette} stopOpacity={1} />
          </radialGradient>
          <radialGradient id="atm-leak" cx="0.9" cy="0.08" r="0.7">
            <stop offset="0" stopColor={palette.sun} stopOpacity={0.45} />
            <stop offset="1" stopColor={palette.sun} stopOpacity={0} />
          </radialGradient>
        </defs>
        <rect width={width} height={height} fill={palette.grade} />
        <rect width={width} height={height} fill="url(#atm-leak)" opacity={sunLeak} />
        <rect width={width} height={height} fill="url(#atm-vignette)" />
        {darken > 0 ? <rect width={width} height={height} fill="#141b26" opacity={darken} /> : null}
      </svg>
    </AbsoluteFill>
  );
};

/* ------------------------------------------------------------------ */
/* Street furniture                                                    */
/* ------------------------------------------------------------------ */

export const Streetlight: React.FC<{ iso: IsoProjector; x: number; y: number; palette: Palette; lit: number }> = ({ iso, x, y, palette, lit }) => {
  const [bx, by] = iso.p(x, y);
  return (
    <g>
      {lit > 0 ? <ellipse cx={bx} cy={by} rx={30} ry={12} fill={palette.windowLit} opacity={lit * 0.35} /> : null}
      <line x1={bx} y1={by} x2={bx} y2={by - 50} stroke={palette.blueGray} strokeWidth={2.6} />
      <line x1={bx} y1={by - 50} x2={bx + 9} y2={by - 54} stroke={palette.blueGray} strokeWidth={2.6} />
      <circle cx={bx + 10} cy={by - 52} r={3.4} fill={lit > 0.2 ? palette.windowLit : palette.cream} />
      {lit > 0 ? <circle cx={bx + 10} cy={by - 52} r={14} fill={palette.windowLit} opacity={lit * 0.35} /> : null}
    </g>
  );
};

export const Bench: React.FC<{ iso: IsoProjector; x: number; y: number; palette: Palette }> = ({ iso, x, y, palette }) => (
  <g>
    <IsoBox iso={iso} x={x} y={y} w={0.42} d={0.12} h={3} z0={7} color={palette.wood} />
    <IsoBox iso={iso} x={x} y={y} w={0.42} d={0.03} h={9} z0={10} color={palette.woodDark} />
  </g>
);

/** Street vendor cart (gerobak) with a parasol. */
export const VendorCart: React.FC<{ iso: IsoProjector; x: number; y: number; palette: Palette; open: number; frame: number }> = ({
  iso,
  x,
  y,
  palette,
  open,
  frame,
}) => {
  const [bx, by] = iso.p(x + 0.2, y + 0.12);
  const wob = sway(frame, 0.05, 3) * 0.8;
  return (
    <g>
      <IsoBox iso={iso} x={x} y={y} w={0.42} d={0.24} h={14} z0={4} color={palette.teal} />
      <IsoBox iso={iso} x={x + 0.04} y={y + 0.04} w={0.34} d={0.16} h={6} z0={18} color={palette.glass} />
      <line x1={bx} y1={by - 20} x2={bx} y2={by - 46} stroke={palette.blueGray} strokeWidth={1.6} />
      <g opacity={open} transform={`rotate(${wob} ${bx} ${by - 46})`}>
        <path d={`M ${bx - 26} ${by - 40} Q ${bx} ${by - 62} ${bx + 26} ${by - 40} Z`} fill={palette.uniformRed} />
        <path d={`M ${bx - 9} ${by - 52} Q ${bx} ${by - 62} ${bx + 9} ${by - 52} L ${bx + 9} ${by - 41} L ${bx - 9} ${by - 41} Z`} fill={palette.cream} opacity={0.9} />
      </g>
    </g>
  );
};

/** Red-and-white flag on a pole, waving. */
export const Flag: React.FC<{ iso: IsoProjector; x: number; y: number; palette: Palette; frame: number }> = ({ iso, x, y, palette, frame }) => {
  const [bx, by] = iso.p(x, y);
  const top = by - 80;
  const wave = (k: number) => Math.sin(frame * 0.18 - k * 1.4) * 3;
  const pts = (y0: number, y1: number) =>
    `M ${bx} ${y0} L ${bx + 12} ${y0 + wave(0.5)} L ${bx + 24} ${y0 + wave(1)} L ${bx + 34} ${y0 + wave(1.5)} L ${bx + 34} ${y1 + wave(1.5)} L ${bx + 24} ${y1 + wave(1)} L ${bx + 12} ${y1 + wave(0.5)} L ${bx} ${y1} Z`;
  return (
    <g>
      <line x1={bx} y1={by} x2={bx} y2={top - 2} stroke={palette.gray} strokeWidth={2.2} />
      <path d={pts(top, top + 9)} fill="#d9534f" />
      <path d={pts(top + 9, top + 18)} fill="#fbf7f0" />
    </g>
  );
};

/* ------------------------------------------------------------------ */
/* The city: one fixed layout reused by Scenes 01, 03 and 05           */
/* ------------------------------------------------------------------ */

export const CITY_ISO = makeIso(110, 55, 1200, 380);
export const CITY_WORLD = { width: 2400, height: 2600 } as const;

type ColorKey = keyof Palette;

type BuildingDef = {
  id: string;
  x: number;
  y: number;
  w: number;
  d: number;
  h: number;
  wall: ColorKey;
  roof?: "flat" | "gable";
  roofColor?: ColorKey;
  windows?: { rows: number; cols: number; colsSide?: number };
  sign?: "school" | "mall" | "station";
  door?: boolean;
  awning?: ColorKey;
  dome?: ColorKey;
};

export const CITY_BUILDINGS: BuildingDef[] = [
  { id: "office-a", x: 0.6, y: 0.8, w: 1.6, d: 1.6, h: 300, wall: "teal", windows: { rows: 9, cols: 4 } },
  { id: "office-b", x: 2.8, y: 0.6, w: 1.8, d: 1.4, h: 220, wall: "gray", windows: { rows: 7, cols: 5 } },
  { id: "office-c", x: 2.8, y: 3.2, w: 2.0, d: 1.9, h: 150, wall: "beige", windows: { rows: 5, cols: 5 } },
  { id: "mosque", x: 0.6, y: 3.6, w: 1.4, d: 1.4, h: 54, wall: "cream", dome: "roofTeal", door: true, windows: { rows: 1, cols: 3 } },
  { id: "minaret", x: 2.1, y: 3.5, w: 0.28, d: 0.28, h: 150, wall: "cream" },
  { id: "house-n1", x: 7.4, y: 0.6, w: 1.2, d: 1.2, h: 58, wall: "beige", roof: "gable", roofColor: "roofRed", door: true, windows: { rows: 1, cols: 2 } },
  { id: "house-n2", x: 9.2, y: 0.6, w: 1.2, d: 1.2, h: 58, wall: "teal", roof: "gable", roofColor: "roofRed", door: true, windows: { rows: 1, cols: 2 } },
  { id: "house-n3", x: 11.0, y: 0.8, w: 1.2, d: 1.2, h: 62, wall: "cream", roof: "gable", roofColor: "roofTeal", door: true, windows: { rows: 1, cols: 2 } },
  { id: "mall", x: 7.3, y: 3.0, w: 4.0, d: 2.5, h: 118, wall: "pink", windows: { rows: 3, cols: 8 }, sign: "mall", door: true },
  { id: "school", x: 0.6, y: 7.8, w: 4.2, d: 1.2, h: 84, wall: "cream", roof: "gable", roofColor: "roofRed", windows: { rows: 2, cols: 8 }, sign: "school", door: true },
  { id: "house-home", x: 7.2, y: 7.8, w: 1.4, d: 1.2, h: 64, wall: "cream", roof: "gable", roofColor: "pink", door: true, windows: { rows: 1, cols: 2 } },
  { id: "house-s2", x: 9.4, y: 7.8, w: 1.2, d: 1.2, h: 60, wall: "teal", roof: "gable", roofColor: "roofRed", door: true, windows: { rows: 1, cols: 2 } },
  { id: "house-s3", x: 11.3, y: 7.8, w: 1.2, d: 1.2, h: 60, wall: "beige", roof: "gable", roofColor: "roofTeal", door: true, windows: { rows: 1, cols: 2 } },
  { id: "warung", x: 7.2, y: 9.9, w: 1.2, d: 0.8, h: 46, wall: "beige", awning: "teal", door: true },
  { id: "station", x: 9.0, y: 11.1, w: 3.6, d: 1.3, h: 66, wall: "blueGray", windows: { rows: 1, cols: 6 }, sign: "station", door: true },
];

const TREES: { x: number; y: number; s: number; kind?: "round" | "cone" }[] = [
  { x: 4.9, y: 1.0, s: 1 }, { x: 4.9, y: 2.6, s: 0.9 }, { x: 4.9, y: 5.4, s: 1 },
  { x: 7.0, y: 1.5, s: 0.9 }, { x: 8.9, y: 2.3, s: 1, kind: "cone" }, { x: 10.7, y: 2.4, s: 0.9 }, { x: 12.5, y: 2.5, s: 1.1 },
  { x: 12.6, y: 4.8, s: 1 }, { x: 0.5, y: 5.8, s: 0.9 }, { x: 2.4, y: 5.7, s: 1, kind: "cone" },
  { x: 0.5, y: 10.0, s: 1.1 }, { x: 0.6, y: 12.0, s: 1 }, { x: 5.0, y: 10.4, s: 0.9 }, { x: 5.0, y: 12.3, s: 1 },
  { x: 8.8, y: 9.4, s: 1 }, { x: 11.0, y: 9.5, s: 0.9, kind: "cone" }, { x: 12.7, y: 9.7, s: 1 }, { x: 12.7, y: 10.9, s: 0.9 },
  { x: 7.2, y: 12.2, s: 1 },
  // across the river - foreground framing (kept clear of the two bridge roads)
  { x: -6.5, y: 16.6, s: 1.5 }, { x: -1.0, y: 16.4, s: 1.6 }, { x: 1.5, y: 16.8, s: 1.4, kind: "cone" }, { x: 4.0, y: 16.3, s: 1.5 },
  { x: 8.4, y: 17.2, s: 1.7 }, { x: 10.5, y: 16.5, s: 1.4 }, { x: 13.0, y: 16.9, s: 1.6, kind: "cone" }, { x: 19.5, y: 16.6, s: 1.5 },
  { x: 22.5, y: 17.0, s: 1.4, kind: "cone" },
];

const LIGHTS: [number, number][] = [
  [1.6, 6.0], [3.8, 6.0], [8.4, 6.0], [10.8, 6.0], [1.6, 7.4], [3.8, 7.4], [8.4, 7.4], [10.8, 7.4],
  [5.42, 2.0], [5.42, 10.0], [6.78, 3.8], [6.78, 11.0],
  [-2.0, 6.0], [-6.5, 7.4], [14.8, 6.0], [19.5, 7.4], [-4.82, 2.0], [17.58, 3.0], [5.42, 12.6], [6.78, 16.4],
];

/* ---------- road network ---------- */

/** Avenues run along y (x0..x1), the main street runs along x (y0..y1). */
const ROADS = {
  main: { x0: 5.6, x1: 6.6, yMin: -8, yMax: 21 },
  west: { x0: -4.6, x1: -3.6, yMin: -6, yMax: 13.0 },
  east: { x0: 16.4, x1: 17.4, yMin: -6, yMax: 21 },
  street: { y0: 6.2, y1: 7.2, xMin: -11, xMax: 25 },
} as const;
const RIVER = { y0: 13.95, y1: 15.7 } as const;
const RAIL_Y = 13.1;
/** Bridge decks span from just after the railway to past the far bank. */
const BRIDGE_Y = { y0: 13.6, y1: 16.05 } as const;

type Lane = { axis: "x" | "y"; fixed: number; dir: 1 | -1; min: number; max: number };
const LANES: Lane[] = [
  { axis: "y", fixed: 5.85, dir: 1, min: ROADS.main.yMin, max: ROADS.main.yMax },
  { axis: "y", fixed: 6.35, dir: -1, min: ROADS.main.yMin, max: ROADS.main.yMax },
  { axis: "x", fixed: 6.45, dir: 1, min: ROADS.street.xMin, max: ROADS.street.xMax },
  { axis: "x", fixed: 6.95, dir: -1, min: ROADS.street.xMin, max: ROADS.street.xMax },
  { axis: "y", fixed: -4.35, dir: 1, min: ROADS.west.yMin, max: ROADS.west.yMax - 0.4 },
  { axis: "y", fixed: -3.85, dir: -1, min: ROADS.west.yMin, max: ROADS.west.yMax - 0.4 },
  { axis: "y", fixed: 16.65, dir: 1, min: ROADS.east.yMin, max: ROADS.east.yMax },
  { axis: "y", fixed: 17.15, dir: -1, min: ROADS.east.yMin, max: ROADS.east.yMax },
];

type VehicleDef = { lane: number; kind: VehicleKind; color: ColorKey; speed: number; offset: number; threshold: number };
const VEHICLE_KINDS: VehicleKind[] = ["car", "motor", "angkot", "car", "motor", "car", "bus", "motor", "car", "motor"];
const VEHICLE_COLORS: ColorKey[] = ["car1", "car2", "car3", "teal", "cream", "pink"];
export const CITY_VEHICLES: VehicleDef[] = Array.from({ length: 44 }).map((_, i) => ({
  lane: i % LANES.length,
  kind: VEHICLE_KINDS[i % VEHICLE_KINDS.length],
  color: VEHICLE_COLORS[(i * 5) % VEHICLE_COLORS.length],
  speed: 0.04 + rand(`veh-speed-${i}`) * 0.03,
  offset: rand(`veh-off-${i}`),
  // one delivery motorbike (i = 1, main avenue) keeps riding through the quiet city
  threshold: i === 1 ? -1 : 0.05 + rand(`veh-th-${i}`) * 0.9,
}));

type PedRoute =
  | { kind: "line"; axis: "x" | "y"; fixed: number; min: number; max: number }
  | { kind: "loop"; cx: number; cy: number; rx: number; ry: number }
  | { kind: "idle"; x: number; y: number };

type PedDef = { route: PedRoute; speed: number; offset: number; threshold: number; kid: boolean; carry: "none" | "bag" | "umbrella"; shirt: ColorKey; seed: number };

const SHIRTS: ColorKey[] = ["shirt", "pink", "teal", "car2", "cream", "car1", "car3", "beige"];
const peds: PedDef[] = [];
const sidewalks: PedRoute[] = [
  { kind: "line", axis: "y", fixed: 5.48, min: 0.2, max: 12.8 },
  { kind: "line", axis: "y", fixed: 6.72, min: 0.2, max: 12.8 },
  { kind: "line", axis: "x", fixed: 6.08, min: 0.2, max: 12.8 },
  { kind: "line", axis: "x", fixed: 7.32, min: 0.2, max: 12.8 },
  { kind: "line", axis: "x", fixed: 6.08, min: -9, max: 23 },
  { kind: "line", axis: "x", fixed: 7.32, min: -9, max: 23 },
  { kind: "line", axis: "y", fixed: -4.72, min: -4, max: 12.6 },
  { kind: "line", axis: "y", fixed: 17.52, min: -4, max: 12.6 },
];
for (let i = 0; i < 30; i++) {
  peds.push({
    route: sidewalks[i % sidewalks.length],
    speed: (rand(`ped-dir-${i}`) > 0.5 ? 1 : -1) * (0.008 + rand(`ped-sp-${i}`) * 0.006),
    offset: rand(`ped-off-${i}`),
    threshold: i === 3 ? -1 : 0.05 + rand(`ped-th-${i}`) * 0.9,
    kid: i % 6 === 2,
    carry: i % 5 === 0 ? "bag" : i % 7 === 3 ? "umbrella" : "none",
    shirt: SHIRTS[i % SHIRTS.length],
    seed: i,
  });
}
// school yard: children playing
for (let i = 0; i < 14; i++) {
  peds.push({
    route: { kind: "loop", cx: 1.8 + (i % 4) * 0.8, cy: 10.2 + Math.floor(i / 4) * 0.7, rx: 0.3 + rand(`yard-rx-${i}`) * 0.3, ry: 0.2 + rand(`yard-ry-${i}`) * 0.2 },
    speed: (i % 2 ? 1 : -1) * (0.02 + rand(`yard-sp-${i}`) * 0.015),
    offset: rand(`yard-off-${i}`),
    threshold: 0.05 + rand(`yard-th-${i}`) * 0.9,
    kid: true,
    carry: "none",
    shirt: "uniformWhite",
    seed: 100 + i,
  });
}
// mall plaza
for (let i = 0; i < 10; i++) {
  peds.push({
    route: i % 3 === 0 ? { kind: "idle", x: 7.6 + i * 0.38, y: 5.72 } : { kind: "line", axis: "x", fixed: 5.7 + (i % 2) * 0.12, min: 7.3, max: 11.3 },
    speed: (i % 2 ? 1 : -1) * (0.006 + rand(`mall-sp-${i}`) * 0.004),
    offset: rand(`mall-off-${i}`),
    threshold: 0.05 + rand(`mall-th-${i}`) * 0.9,
    kid: i === 4,
    carry: i % 2 ? "bag" : "none",
    shirt: SHIRTS[(i + 3) % SHIRTS.length],
    seed: 200 + i,
  });
}
// station platform
for (let i = 0; i < 10; i++) {
  peds.push({
    route: i % 2 === 0 ? { kind: "idle", x: 9.3 + i * 0.33, y: 12.72 } : { kind: "line", axis: "x", fixed: 12.82, min: 9.1, max: 12.5 },
    speed: (i % 4 === 1 ? 1 : -1) * 0.007,
    offset: rand(`st-off-${i}`),
    threshold: 0.05 + rand(`st-th-${i}`) * 0.9,
    kid: false,
    carry: i % 3 === 0 ? "bag" : "none",
    shirt: SHIRTS[(i + 5) % SHIRTS.length],
    seed: 300 + i,
  });
}
// vendor and a customer by the cart
peds.push({ route: { kind: "idle", x: 4.75, y: 7.95 }, speed: 0, offset: 0, threshold: 0.35, kid: false, carry: "none", shirt: "car2", seed: 400 });
peds.push({ route: { kind: "idle", x: 4.95, y: 8.35 }, speed: 0, offset: 0, threshold: 0.6, kid: true, carry: "none", shirt: "uniformWhite", seed: 401 });
export const CITY_PEDESTRIANS = peds;

/* ---------- surrounding neighbourhoods (procedural, deterministic) ---------- */

type Rect = { x0: number; y0: number; x1: number; y1: number };
const KEEP_CLEAR: Rect[] = [
  { x0: -0.4, y0: -0.4, x1: 13.4, y1: 13.0 }, // hand-built city centre
  { x0: ROADS.main.x0 - 0.35, y0: -99, x1: ROADS.main.x1 + 0.35, y1: 99 },
  { x0: ROADS.west.x0 - 0.35, y0: -99, x1: ROADS.west.x1 + 0.35, y1: 99 },
  { x0: ROADS.east.x0 - 0.35, y0: -99, x1: ROADS.east.x1 + 0.35, y1: 99 },
  { x0: -99, y0: ROADS.street.y0 - 0.35, x1: 99, y1: ROADS.street.y1 + 0.35 },
  { x0: -99, y0: 12.75, x1: 99, y1: 99 }, // railway, river and beyond
];
const overlaps = (a: Rect, b: Rect) => a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;

type FillerItem = { kind: "building"; def: BuildingDef } | { kind: "trees"; x: number; y: number; n: number; seed: number };
const HOUSE_WALLS: ColorKey[] = ["beige", "cream", "teal", "pink", "gray", "cream"];
const ROOFS: ColorKey[] = ["roofRed", "roofTeal", "roofRed", "pink"];
const TOWER_WALLS: ColorKey[] = ["teal", "gray", "beige", "blueGray", "cream"];
const CELL = 1.5;

export const CITY_FILLER: FillerItem[] = (() => {
  const out: FillerItem[] = [];
  for (let cx = -10.5; cx < 24; cx += CELL) {
    for (let cy = -7; cy < 12.75; cy += CELL) {
      const cell = { x0: cx, y0: cy, x1: cx + CELL, y1: cy + CELL };
      if (KEEP_CLEAR.some((r) => overlaps(cell, r))) continue;
      const mx = cx + CELL / 2;
      const my = cy + CELL / 2;
      if (mx + my < -3) continue; // behind the horizon line
      if (Math.abs(mx - my) > 18) continue; // outside every camera framing
      const r = rand(`blk-${cx}-${cy}`);
      const r2 = rand(`blk2-${cx}-${cy}`);
      const r3 = rand(`blk3-${cx}-${cy}`);
      const backRow = mx + my < 5;
      if (r < (backRow ? 0.35 : 0.52)) {
        const w = 0.9 + r2 * 0.3;
        const d = 0.85 + r3 * 0.3;
        out.push({
          kind: "building",
          def: {
            id: `house-${cx}-${cy}`,
            x: cx + (CELL - w) / 2,
            y: cy + (CELL - d) / 2,
            w,
            d,
            h: 38 + Math.round(r3 * 18),
            wall: HOUSE_WALLS[Math.floor(r2 * HOUSE_WALLS.length)],
            roof: "gable",
            roofColor: ROOFS[Math.floor(r3 * ROOFS.length)],
            door: true,
            windows: { rows: 1, cols: 2 },
          },
        });
      } else if (r < (backRow ? 0.8 : 0.74)) {
        const w = 1.0 + r2 * 0.25;
        const h = backRow ? 120 + Math.round(r3 * 140) : 60 + Math.round(r3 * 60);
        out.push({
          kind: "building",
          def: {
            id: `bldg-${cx}-${cy}`,
            x: cx + (CELL - w) / 2,
            y: cy + (CELL - w) / 2,
            w,
            d: w,
            h,
            wall: TOWER_WALLS[Math.floor(r2 * TOWER_WALLS.length)],
            windows: { rows: Math.max(2, Math.round(h / 32)), cols: 3 },
          },
        });
      } else if (r < 0.95) {
        out.push({ kind: "trees", x: mx, y: my, n: 1 + Math.floor(r2 * 3), seed: Math.round((cx + 20) * 31 + (cy + 20) * 7) });
      }
    }
  }
  return out;
})();

const pingPong = (v: number) => {
  const m = ((v % 2) + 2) % 2;
  return m < 1 ? m : 2 - m;
};

const pedPosition = (ped: PedDef, frame: number): { x: number; y: number; moving: boolean } => {
  const r = ped.route;
  if (r.kind === "idle") return { x: r.x, y: r.y, moving: false };
  if (r.kind === "loop") {
    const a = ped.offset * Math.PI * 2 + frame * ped.speed * 3;
    return { x: r.cx + Math.cos(a) * r.rx, y: r.cy + Math.sin(a) * r.ry, moving: true };
  }
  const len = r.max - r.min;
  const t = pingPong(ped.offset * 2 + (frame * ped.speed) / len);
  const along = r.min + t * len;
  return r.axis === "x" ? { x: along, y: r.fixed, moving: true } : { x: r.fixed, y: along, moving: true };
};

/** Road bridge over the river: deck on two piers, concrete edge and railings. */
const Bridge: React.FC<{ iso: IsoProjector; palette: Palette; x0: number; x1: number }> = ({ iso, palette, x0, x1 }) => {
  const { p, pts } = iso;
  const { y0, y1 } = BRIDGE_Y;
  const e0 = x0 - 0.26;
  const e1 = x1 + 0.26;
  const concrete = palette.gray;
  return (
    <g>
      {/* piers standing in the water */}
      {[14.45, 15.25].map((py) => (
        <IsoBox key={py} iso={iso} x={x0 + 0.1} y={py} w={x1 - x0 - 0.2} d={0.22} h={34} z0={-34} color={shade(concrete, 0.1)} />
      ))}
      {/* deck edge (thickness) on the visible +x side and the far end */}
      <polygon points={pts(p(e1, y0, 0), p(e1, y1, 0), p(e1, y1, -12), p(e1, y0, -12))} fill={shade(concrete, 0.25)} />
      <polygon points={pts(p(e0, y1, 0), p(e1, y1, 0), p(e1, y1, -12), p(e0, y1, -12))} fill={shade(concrete, 0.35)} />
      <Road iso={iso} palette={palette} x0={x0} y0={y0} x1={x1} y1={y1} sidewalk={0.26} />
      {/* railings */}
      <IsoBox iso={iso} x={e0} y={y0} w={0.05} d={y1 - y0} h={7} color={palette.cream} />
      <IsoBox iso={iso} x={e1 - 0.05} y={y0} w={0.05} d={y1 - y0} h={7} color={palette.cream} />
    </g>
  );
};

/** Camera focus points (world px) for the city landmarks. */
const fp = (x: number, y: number, z = 0) => {
  const [a, b] = CITY_ISO.p(x, y, z);
  return { x: a, y: b };
};
export const CITY_FOCUS = {
  overview: { x: 1200, y: 690 },
  street: fp(6.1, 6.7, 20),
  house: fp(7.9, 8.4, 30),
  school: fp(2.9, 10.0, 20),
  mall: fp(9.3, 5.6, 40),
  station: fp(10.8, 12.4, 25),
  bridge: fp(6.1, 14.8, 0),
} as const;

export type CityProps = {
  palette: Palette;
  frame: number;
  /** 0 = empty streets, 1 = normal daily life. */
  density: number;
  /** 0..1 window and street lights. */
  lit?: number;
  /** Fraction of pedestrians wearing a face mask. */
  masks?: number;
  /** Labels on buildings, from timing.ts ui strings. */
  signs: { school: string; mall: string; station: string };
};

/** Objects south of the railway (bridges, far bank) are drawn after the train. */
const FRONT_LAYER = 200;
const layerDepth = (x: number, y: number) => (y > BRIDGE_Y.y0 - 0.05 ? FRONT_LAYER + x + y : x + y);

/** The whole city diorama in world space (CITY_WORLD). Place inside <Camera>. */
export const City: React.FC<CityProps> = ({ palette, frame, density, lit = 0, masks = 0, signs }) => {
  const iso = CITY_ISO;
  const { p, pts } = iso;
  const W = CITY_WORLD.width;
  const H = CITY_WORLD.height;
  const vis = (threshold: number) => (threshold < 0 ? 1 : smoothstep(threshold - 0.07, threshold + 0.07, density));

  const objects: { depth: number; node: React.ReactNode }[] = [];
  const allBuildings: BuildingDef[] = [...CITY_BUILDINGS, ...CITY_FILLER.flatMap((f) => (f.kind === "building" ? [f.def] : []))];

  allBuildings.forEach((b) => {
    objects.push({
      depth: b.x + b.w / 2 + b.y + b.d / 2,
      node: (
        <Building
          key={b.id}
          iso={iso}
          palette={palette}
          x={b.x}
          y={b.y}
          w={b.w}
          d={b.d}
          h={b.h}
          wall={palette[b.wall]}
          roof={b.roof}
          roofColor={b.roofColor ? palette[b.roofColor] : undefined}
          windows={b.windows}
          lit={lit}
          sign={b.sign ? signs[b.sign] : undefined}
          signColor={b.sign === "mall" ? shade(palette.pink, 0.45) : undefined}
          door={b.door}
          awning={b.awning ? palette[b.awning] : undefined}
          dome={b.dome ? palette[b.dome] : undefined}
        />
      ),
    });
  });

  const treeList = [
    ...TREES,
    ...CITY_FILLER.flatMap((f) =>
      f.kind === "trees"
        ? Array.from({ length: f.n }).map((_, k) => ({
            x: f.x + (rand(`ft-x-${f.seed}-${k}`) - 0.5) * 0.9,
            y: f.y + (rand(`ft-y-${f.seed}-${k}`) - 0.5) * 0.9,
            s: 0.8 + rand(`ft-s-${f.seed}-${k}`) * 0.4,
            kind: rand(`ft-k-${f.seed}-${k}`) > 0.7 ? ("cone" as const) : ("round" as const),
          }))
        : [],
    ),
  ];
  treeList.forEach((t, i) => {
    const [bx, by] = p(t.x, t.y);
    objects.push({
      depth: layerDepth(t.x, t.y),
      node: <Tree key={`tree-${i}`} bx={bx} by={by} size={t.s} palette={palette} frame={frame} seed={i + 1} kind={t.kind} />,
    });
  });

  LIGHTS.forEach(([x, y], i) => {
    objects.push({ depth: layerDepth(x, y), node: <Streetlight key={`light-${i}`} iso={iso} x={x} y={y} palette={palette} lit={lit} /> });
  });

  [[7.9, 5.78], [10.3, 5.78], [5.0, 3.6]].forEach(([x, y], i) => {
    objects.push({ depth: x + y, node: <Bench key={`bench-${i}`} iso={iso} x={x} y={y} palette={palette} /> });
  });
  objects.push({ depth: 4.6 + 7.8, node: <VendorCart key="cart" iso={iso} x={4.4} y={7.62} palette={palette} open={vis(0.35)} frame={frame} /> });
  objects.push({ depth: 4.4 + 9.6, node: <Flag key="flag" iso={iso} x={4.5} y={9.6} palette={palette} frame={frame} /> });

  CITY_VEHICLES.forEach((v, i) => {
    const lane = LANES[v.lane];
    const len = lane.max - lane.min;
    const s = (((v.offset * len + frame * v.speed) % len) + len) % len;
    const along = lane.dir > 0 ? lane.min + s : lane.max - s;
    const edge = Math.min(along - lane.min, lane.max - along);
    const opacity = vis(v.threshold) * smoothstep(0, 0.8, edge);
    const x = lane.axis === "x" ? along : lane.fixed;
    const y = lane.axis === "x" ? lane.fixed : along;
    objects.push({
      depth: layerDepth(x, y) + 0.05,
      node: <IsoVehicle key={`veh-${i}`} iso={iso} palette={palette} x={x} y={y} axis={lane.axis} kind={v.kind} color={palette[v.color]} opacity={opacity} frame={frame} />,
    });
  });

  CITY_PEDESTRIANS.forEach((ped, i) => {
    const pos = pedPosition(ped, frame);
    const [sx, sy] = p(pos.x, pos.y);
    objects.push({
      depth: layerDepth(pos.x, pos.y) + 0.02,
      node: (
        <Pedestrian
          key={`ped-${i}`}
          sx={sx}
          sy={sy}
          frame={frame}
          seed={ped.seed}
          shirt={palette[ped.shirt]}
          pants={ped.kid ? palette.uniformRed : palette.pants}
          skin={i % 3 === 0 ? palette.skinShade : palette.skin}
          hair={palette.hair}
          kid={ped.kid}
          moving={pos.moving}
          carry={ped.carry}
          umbrella={palette.pink}
          opacity={vis(ped.threshold)}
          mask={rand(`mask-${ped.seed}`) < masks}
        />
      ),
    });
  });

  // commuter train, only while the city is busy: between the city and the bridges
  const trainHead = -12 + ((frame * 0.09) % 42);
  objects.push({
    depth: FRONT_LAYER - 1,
    node: <IsoTrain key="train" iso={iso} palette={palette} head={trainHead} y={RAIL_Y + 0.02} opacity={vis(0.55)} />,
  });

  objects.sort((a, b) => a.depth - b.depth);

  // background hills (flat silhouettes behind the grid)
  const ridge = (baseY: number, amp: number, seed: number) => {
    const out: string[] = [`-1200,${baseY + 200}`];
    for (let i = 0; i <= 24; i++) {
      const x = -1200 + i * 200;
      out.push(`${x},${baseY - amp * (0.5 + 0.5 * Math.sin(i * 1.3 + seed))}`);
    }
    out.push(`3600,${baseY + 200}`);
    return out.join(" ");
  };

  const ripples = Array.from({ length: 22 }).map((_, i) => {
    const u = ((i * 2.3 + frame * 0.012) % 40) - 12;
    const v = 14.4 + (i % 4) * 0.28;
    const [x1, y1] = p(u, v);
    const [x2, y2] = p(u + 0.8, v);
    return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke={palette.waterLight} strokeWidth={2.4} strokeLinecap="round" opacity={0.55} />;
  });

  // ground plate: whole grid, cut at a horizontal line (x + y = -3) so it never pokes into the hills
  const plate = pts(p(-11, 8), p(-11, 13.9), p(25, 13.9), p(25, -8), p(5, -8));

  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{ overflow: "visible" }}>
      <polygon points={ridge(330, 90, 1)} fill={palette.hillFar} />
      <polygon points={ridge(400, 70, 4)} fill={palette.hillNear} />
      <rect x={-1200} y={420} width={W + 2400} height={H + 1200} fill={palette.field} />
      <polygon points={plate} fill={palette.ground} />
      {[
        [1, 1, 3],
        [10, 2, 2.4],
        [3, 11, 2],
        [12, 11, 2.8],
        [-1, 7, 2],
        [-7, 9, 2.6],
        [19, 2, 2.6],
        [20, 10, 2.2],
        [-3, 1, 2],
      ].map(([x, y, r], i) => {
        const [cx, cy] = p(x, y);
        return <ellipse key={i} cx={cx} cy={cy} rx={r * 50} ry={r * 22} fill={palette.groundPatch} opacity={0.8} />;
      })}
      {/* river */}
      <polygon points={pts(p(-14, RIVER.y0), p(30, RIVER.y0), p(30, RIVER.y1), p(-14, RIVER.y1))} fill={palette.water} />
      <polygon points={pts(p(-14, RIVER.y0), p(30, RIVER.y0), p(30, RIVER.y0 + 0.15), p(-14, RIVER.y0 + 0.15))} fill={tint(palette.water, 0.35)} />
      {ripples}
      {/* yards and plazas */}
      <GroundRect iso={iso} x0={0.8} y0={9.3} x1={4.85} y1={12.7} fill={palette.field} />
      <GroundRect iso={iso} x0={1.2} y0={9.8} x1={4.3} y1={12.2} fill={tint(palette.field, 0.2)} opacity={0.5} />
      <GroundRect iso={iso} x0={7.2} y0={5.55} x1={11.4} y1={5.95} fill={tint(palette.sidewalk, 0.15)} />
      <GroundRect iso={iso} x0={8.9} y0={12.45} x1={12.7} y1={13.0} fill={palette.sidewalk} />
      {/* roads: avenues stop at the railway, bridges carry two of them over the river */}
      <Road iso={iso} palette={palette} x0={ROADS.west.x0} y0={ROADS.west.yMin} x1={ROADS.west.x1} y1={ROADS.west.yMax} />
      <Road iso={iso} palette={palette} x0={ROADS.main.x0} y0={ROADS.main.yMin} x1={ROADS.main.x1} y1={BRIDGE_Y.y0} />
      <Road iso={iso} palette={palette} x0={ROADS.east.x0} y0={ROADS.east.yMin} x1={ROADS.east.x1} y1={BRIDGE_Y.y0} />
      <Road iso={iso} palette={palette} x0={ROADS.street.xMin} y0={ROADS.street.y0} x1={ROADS.street.xMax} y1={ROADS.street.y1} />
      {[ROADS.main, ROADS.west, ROADS.east].map((r) => (
        <GroundRect key={r.x0} iso={iso} x0={r.x0} y0={ROADS.street.y0} x1={r.x1} y1={ROADS.street.y1} fill={palette.road} />
      ))}
      <Crosswalk iso={iso} palette={palette} x0={5.6} y0={7.25} x1={6.6} y1={7.6} alongX />
      <Rail iso={iso} palette={palette} x0={-14} x1={30} y={RAIL_Y} />
      {[ROADS.main, ROADS.east].map((r) => (
        <g key={`far-${r.x0}`}>
          <Bridge iso={iso} palette={palette} x0={r.x0} x1={r.x1} />
          <Road iso={iso} palette={palette} x0={r.x0} y0={BRIDGE_Y.y1} x1={r.x1} y1={r.yMax} />
        </g>
      ))}
      {/* shadows */}
      {allBuildings.map((b) => (
        <BuildingShadow key={`sh-${b.id}`} iso={iso} x={b.x} y={b.y} w={b.w} d={b.d} h={b.h} color={palette.shadow} />
      ))}
      {objects.map((o) => o.node)}
    </svg>
  );
};

/** A handful of leaves drifting across the frame (screen space). */
export const FallingLeaves: React.FC<{ frame: number; start: number; palette: Palette; count?: number }> = ({ frame, start, palette, count = 6 }) => {
  const { width, height } = useVideoConfig();
  const f = frame - start;
  if (f < 0) return null;
  return (
    <AbsoluteFill style={{ pointerEvents: "none" }}>
      <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`}>
        {Array.from({ length: count }).map((_, i) => {
          const local = f - i * 18;
          if (local < 0) return null;
          const x = width + 40 - local * (3.2 + rand(`leaf-v-${i}`) * 1.5) + Math.sin(local * 0.06 + i) * 30;
          const y = 520 + rand(`leaf-y-${i}`) * 700 + local * 1.6;
          const rot = local * (2 + i) + i * 40;
          if (x < -60 || y > height + 60) return null;
          return (
            <g key={i} transform={`translate(${x.toFixed(1)} ${y.toFixed(1)}) rotate(${rot.toFixed(1)})`}>
              <path d="M -12 0 Q 0 -8 12 0 Q 0 8 -12 0 Z" fill={i % 2 ? palette.treeLight : palette.car2} opacity={0.85} />
            </g>
          );
        })}
      </svg>
    </AbsoluteFill>
  );
};
