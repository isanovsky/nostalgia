import React from "react";
import { boxFaces, IsoProjector } from "../lib/iso";
import { shade, tint } from "../lib/color";
import { fitFontSize } from "../lib/anim";
import { FONT_STACK, Palette } from "../theme";

type BoxProps = {
  iso: IsoProjector;
  x: number;
  y: number;
  w: number;
  d: number;
  h: number;
  z0?: number;
  color: string;
  /** Override face colours. */
  topColor?: string;
  opacity?: number;
};

/** Shaded isometric box: light from the upper right. */
export const IsoBox: React.FC<BoxProps> = ({ iso, x, y, w, d, h, z0 = 0, color, topColor, opacity = 1 }) => {
  const f = boxFaces(iso, x, y, w, d, h, z0);
  return (
    <g opacity={opacity}>
      <polygon points={f.left} fill={shade(color, 0.22)} />
      <polygon points={f.right} fill={color} />
      <polygon points={f.top} fill={topColor ?? tint(color, 0.28)} />
    </g>
  );
};

type WindowGrid = { rows: number; cols: number; colsSide?: number };

export type BuildingProps = {
  iso: IsoProjector;
  palette: Palette;
  x: number;
  y: number;
  w: number;
  d: number;
  h: number;
  wall: string;
  roof?: "flat" | "gable";
  roofColor?: string;
  windows?: WindowGrid;
  /** 0 = daylight windows, 1 = all lit. */
  lit?: number;
  sign?: string;
  signColor?: string;
  door?: boolean;
  awning?: string;
  dome?: string;
  seed?: number;
};

/** Painterly brush strokes: a few translucent streaks that break up flat faces. */
const Strokes: React.FC<{ iso: IsoProjector; x: number; y: number; w: number; d: number; h: number; color: string }> = ({
  iso,
  x,
  y,
  w,
  d,
  h,
  color,
}) => {
  const { p, pts } = iso;
  const streak = (u0: number, u1: number, z: number, t: number, side: "left" | "right") =>
    side === "left"
      ? pts(p(x + w * u0, y + d, z), p(x + w * u1, y + d, z), p(x + w * u1, y + d, z + t), p(x + w * u0, y + d, z + t))
      : pts(p(x + w, y + d * u0, z), p(x + w, y + d * u1, z), p(x + w, y + d * u1, z + t), p(x + w, y + d * u0, z + t));
  return (
    <g fill={color} opacity={0.18}>
      <polygon points={streak(0.05, 0.7, h * 0.82, h * 0.06, "left")} />
      <polygon points={streak(0.3, 0.95, h * 0.6, h * 0.04, "right")} />
      <polygon points={streak(0.1, 0.55, h * 0.35, h * 0.05, "right")} />
    </g>
  );
};

export const Building: React.FC<BuildingProps> = ({
  iso,
  palette,
  x,
  y,
  w,
  d,
  h,
  wall,
  roof = "flat",
  roofColor,
  windows,
  lit = 0,
  sign,
  signColor,
  door,
  awning,
  dome,
}) => {
  const { p, pts } = iso;
  const f = boxFaces(iso, x, y, w, d, h);
  const leftWall = shade(wall, 0.2);
  const rightWall = wall;
  const winDay = palette.glass;

  const windowEls: React.ReactNode[] = [];
  if (windows) {
    const { rows, cols } = windows;
    const colsSide = windows.colsSide ?? Math.max(1, Math.round((cols * d) / w));
    const marginZ = h * 0.12;
    const rowH = (h - marginZ * 2) / rows;
    for (let r = 0; r < rows; r++) {
      const z0 = marginZ + r * rowH + rowH * 0.22;
      const z1 = z0 + rowH * 0.56;
      for (let c = 0; c < cols; c++) {
        const u0 = (c + 0.25) / cols;
        const u1 = (c + 0.75) / cols;
        const litThis = ((r * 7 + c * 3) % 5) / 5 < lit;
        windowEls.push(
          <polygon
            key={`l${r}-${c}`}
            points={pts(p(x + w * u0, y + d, z0), p(x + w * u1, y + d, z0), p(x + w * u1, y + d, z1), p(x + w * u0, y + d, z1))}
            fill={litThis ? palette.windowLit : shade(winDay, 0.15)}
            opacity={0.9}
          />,
        );
      }
      for (let c = 0; c < colsSide; c++) {
        const u0 = (c + 0.25) / colsSide;
        const u1 = (c + 0.75) / colsSide;
        const litThis = ((r * 5 + c * 2 + 1) % 5) / 5 < lit;
        windowEls.push(
          <polygon
            key={`r${r}-${c}`}
            points={pts(p(x + w, y + d * u0, z0), p(x + w, y + d * u1, z0), p(x + w, y + d * u1, z1), p(x + w, y + d * u0, z1))}
            fill={litThis ? palette.windowLit : tint(winDay, 0.15)}
            opacity={0.9}
          />,
        );
      }
    }
  }

  const ridge = h + Math.min(w, d) * iso.th * 0.55;
  // signs never run off the wall: shrink the text to the wall width
  const signMax = w * iso.unit * 0.9;
  const signSize = sign ? fitFontSize(sign, signMax - 20, 16, 0.7, 2) : 16;
  const signW = sign ? Math.min(signMax, sign.length * (signSize * 0.7 + 2) + 20) : 0;
  const rc = roofColor ?? palette.roofRed;

  return (
    <g>
      <polygon points={f.left} fill={leftWall} />
      <polygon points={f.right} fill={rightWall} />
      {/* ambient occlusion band at the foot of the walls */}
      <polygon
        points={pts(p(x, y + d, 0), p(x + w, y + d, 0), p(x + w, y + d, h * 0.12), p(x, y + d, h * 0.12))}
        fill={shade(wall, 0.45)}
        opacity={0.25}
      />
      <Strokes iso={iso} x={x} y={y} w={w} d={d} h={h} color={tint(wall, 0.6)} />
      {windowEls}
      {door ? (
        <polygon
          points={pts(
            p(x + w * 0.42, y + d, 0),
            p(x + w * 0.58, y + d, 0),
            p(x + w * 0.58, y + d, Math.min(28, h * 0.55)),
            p(x + w * 0.42, y + d, Math.min(28, h * 0.55)),
          )}
          fill={palette.woodDark}
        />
      ) : null}
      {awning ? (
        <g>
          <polygon
            points={pts(p(x, y + d, h * 0.62), p(x + w, y + d, h * 0.62), p(x + w, y + d + 0.28, h * 0.46), p(x, y + d + 0.28, h * 0.46))}
            fill={awning}
          />
          {[0.1, 0.3, 0.5, 0.7, 0.9].map((u) => (
            <polygon
              key={u}
              points={pts(
                p(x + w * (u - 0.05), y + d, h * 0.62),
                p(x + w * (u + 0.05), y + d, h * 0.62),
                p(x + w * (u + 0.05), y + d + 0.28, h * 0.46),
                p(x + w * (u - 0.05), y + d + 0.28, h * 0.46),
              )}
              fill={palette.cream}
              opacity={0.85}
            />
          ))}
        </g>
      ) : null}
      {roof === "flat" ? (
        <g>
          <polygon points={f.top} fill={tint(wall, 0.3)} />
          <polygon
            points={pts(
              p(x + w * 0.08, y + d * 0.08, h),
              p(x + w * 0.92, y + d * 0.08, h),
              p(x + w * 0.92, y + d * 0.92, h),
              p(x + w * 0.08, y + d * 0.92, h),
            )}
            fill={shade(wall, 0.08)}
          />
        </g>
      ) : (
        <g>
          <polygon
            points={pts(p(x, y, h), p(x + w, y, h), p(x + w, y + d / 2, ridge), p(x, y + d / 2, ridge))}
            fill={shade(rc, 0.1)}
          />
          <polygon points={pts(p(x + w, y, h), p(x + w, y + d, h), p(x + w, y + d / 2, ridge))} fill={tint(wall, 0.12)} />
          <polygon
            points={pts(p(x - 0.04, y + d + 0.06, h - 2), p(x + w + 0.04, y + d + 0.06, h - 2), p(x + w + 0.04, y + d / 2, ridge), p(x - 0.04, y + d / 2, ridge))}
            fill={rc}
          />
          <polygon
            points={pts(p(x, y + d * 0.78, h + (ridge - h) * 0.42), p(x + w, y + d * 0.78, h + (ridge - h) * 0.42), p(x + w, y + d * 0.74, h + (ridge - h) * 0.5), p(x, y + d * 0.74, h + (ridge - h) * 0.5))}
            fill={tint(rc, 0.25)}
            opacity={0.5}
          />
        </g>
      )}
      {dome ? (
        <g>
          {(() => {
            const [cx, cy] = p(x + w / 2, y + d / 2, h);
            const r = Math.min(w, d) * iso.tw * 0.28;
            return (
              <g>
                <ellipse cx={cx} cy={cy} rx={r} ry={r * 0.45} fill={shade(dome, 0.15)} />
                <path d={`M ${cx - r} ${cy} A ${r} ${r * 1.05} 0 0 1 ${cx + r} ${cy} Z`} fill={dome} />
                <path d={`M ${cx - r * 0.35} ${cy - r * 0.7} A ${r * 0.6} ${r * 0.5} 0 0 1 ${cx + r * 0.25} ${cy - r * 0.92}`} stroke={tint(dome, 0.45)} strokeWidth={3} fill="none" opacity={0.7} />
                <line x1={cx} y1={cy - r * 1.05} x2={cx} y2={cy - r * 1.35} stroke={palette.blueGray} strokeWidth={2} />
              </g>
            );
          })()}
        </g>
      ) : null}
      {sign ? (
        <g transform={iso.faceX(x + w * 0.5, y + d, h * 0.78)}>
          <rect x={-signW / 2} y={-16} width={signW} height={26} rx={5} fill={signColor ?? palette.uiDark} />
          <text
            x={0}
            y={3}
            textAnchor="middle"
            fontFamily={FONT_STACK}
            fontWeight={800}
            fontSize={signSize}
            letterSpacing={2}
            fill={palette.cream}
          >
            {sign}
          </text>
        </g>
      ) : null}
    </g>
  );
};

/** Soft ground shadow cast toward the lower left. */
export const BuildingShadow: React.FC<{
  iso: IsoProjector;
  x: number;
  y: number;
  w: number;
  d: number;
  h: number;
  color: string;
}> = ({ iso, x, y, w, d, h, color }) => {
  const { p, pts } = iso;
  const len = Math.min(2.2, h / 90);
  return (
    <polygon
      points={pts(p(x, y, 0), p(x + w, y, 0), p(x + w, y + d + len, 0), p(x, y + d + len, 0))}
      fill={color}
    />
  );
};
