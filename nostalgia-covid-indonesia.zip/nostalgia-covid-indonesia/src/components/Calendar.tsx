import React from "react";
import { FONT_STACK, Palette } from "../theme";
import { shade } from "../lib/color";
import { fitFontSize } from "../lib/anim";

/** Indonesian month names; the calendar layout is computed from the real 2020+ dates. */
const MONTHS = ["JANUARI", "FEBRUARI", "MARET", "APRIL", "MEI", "JUNI", "JULI", "AGUSTUS", "SEPTEMBER", "OKTOBER", "NOVEMBER", "DESEMBER"];
/** Minggu, Senin, Selasa, Rabu, Kamis, Jumat, Sabtu */
const WEEKDAYS = ["M", "S", "S", "R", "K", "J", "S"];

export const CALENDAR_SIZE = { width: 168, height: 220 } as const;

type Parsed = { kind: "month"; offset: number; days: number } | { kind: "year"; year: number } | { kind: "text" };

/** Real weekday layout for labels like "MARCH 2020"; a bare year renders a year page. */
const parseLabel = (label: string): Parsed => {
  const parts = label.trim().toUpperCase().split(/\s+/);
  if (parts.length === 1 && /^\d{4}$/.test(parts[0])) return { kind: "year", year: Number(parts[0]) };
  if (parts.length === 2) {
    const m = MONTHS.indexOf(parts[0]);
    const y = Number(parts[1]);
    if (m >= 0 && Number.isFinite(y)) {
      return { kind: "month", offset: new Date(y, m, 1).getDay(), days: new Date(y, m + 1, 0).getDate() };
    }
  }
  return { kind: "text" };
};

type PageProps = {
  label: string;
  palette: Palette;
  /** Days circled as "the plan", e.g. [16, 29]. */
  circle?: [number, number];
  /** 0..1 how far the circling has been drawn. */
  circleProgress?: number;
  /** Cross out every day (time already passed). */
  crossed?: number;
};

const Page: React.FC<PageProps> = ({ label, palette, circle, circleProgress = 0, crossed = 0 }) => {
  const { width, height } = CALENDAR_SIZE;
  const parsed = parseLabel(label);
  const paper = "#fbf6ea";
  const header = palette.accent;
  const cells: React.ReactNode[] = [];
  if (parsed.kind === "month") {
    const cw = (width - 16) / 7;
    const ch = 24;
    for (let d = 1; d <= parsed.days; d++) {
      const idx = parsed.offset + d - 1;
      const col = idx % 7;
      const row = Math.floor(idx / 7);
      const cx = 8 + col * cw + cw / 2;
      const cy = 92 + row * ch;
      const inCircle = circle && d >= circle[0] && d <= circle[1];
      const circleShown = inCircle && circleProgress > (d - circle[0]) / (circle[1] - circle[0] + 1);
      cells.push(
        <g key={d}>
          <text x={cx} y={cy + 4} textAnchor="middle" fontFamily={FONT_STACK} fontWeight={600} fontSize={11} fill={col === 0 ? palette.uniformRed : "#4a5562"}>
            {d}
          </text>
          {circleShown ? <circle cx={cx} cy={cy} r={9.5} fill="none" stroke={palette.uniformRed} strokeWidth={2} opacity={0.85} /> : null}
          {crossed > (d - 1) / parsed.days ? (
            <g stroke={shade(palette.uniformRed, 0.1)} strokeWidth={1.8} opacity={0.7} strokeLinecap="round">
              <line x1={cx - 6} y1={cy - 6} x2={cx + 6} y2={cy + 6} />
              <line x1={cx + 6} y1={cy - 6} x2={cx - 6} y2={cy + 6} />
            </g>
          ) : null}
        </g>,
      );
    }
  }
  return (
    <g>
      <rect x={0} y={0} width={width} height={height} rx={6} fill={paper} />
      <rect x={0} y={0} width={width} height={parsed.kind === "year" ? 70 : 54} rx={6} fill={header} />
      <rect x={0} y={44} width={width} height={10} fill={header} opacity={parsed.kind === "year" ? 1 : 0} />
      <text
        x={width / 2}
        y={parsed.kind === "year" ? 46 : 36}
        textAnchor="middle"
        fontFamily={FONT_STACK}
        fontWeight={800}
        fontSize={fitFontSize(label, width - 20, parsed.kind === "year" ? 30 : 19, 0.66, 1)}
        letterSpacing={1}
        fill="#ffffff"
      >
        {label}
      </text>
      {parsed.kind === "month"
        ? WEEKDAYS.map((w, i) => (
            <text key={i} x={8 + i * ((width - 16) / 7) + (width - 16) / 14} y={72} textAnchor="middle" fontFamily={FONT_STACK} fontWeight={800} fontSize={10} fill="#8a939c">
              {w}
            </text>
          ))
        : null}
      {cells}
      {parsed.kind === "year"
        ? Array.from({ length: 12 }).map((_, i) => {
            const col = i % 3;
            const row = Math.floor(i / 3);
            const x = 14 + col * 50;
            const y = 84 + row * 33;
            return (
              <g key={i}>
                <rect x={x} y={y} width={40} height={26} rx={3} fill="#efe6d4" />
                {crossed > i / 12 ? (
                  <line x1={x + 4} y1={y + 22} x2={x + 36} y2={y + 4} stroke={palette.uniformRed} strokeWidth={1.8} opacity={0.6} />
                ) : null}
              </g>
            );
          })
        : null}
    </g>
  );
};

type CalendarProps = {
  palette: Palette;
  pages: string[];
  /** Index of the page on top. */
  page: number;
  /** 0..1 progress of the top page flipping away to reveal `page + 1`. */
  flip?: number;
  circle?: [number, number];
  circleProgress?: number;
  /** Cross-out progress per page index. */
  crossedFor?: (pageIndex: number) => number;
};

/** Wall calendar drawn in its own flat coordinates (CALENDAR_SIZE). Mount it with an iso face transform. */
export const Calendar: React.FC<CalendarProps> = ({ palette, pages, page, flip = 0, circle, circleProgress, crossedFor }) => {
  const { width, height } = CALENDAR_SIZE;
  const current = pages[Math.min(page, pages.length - 1)];
  const next = pages[Math.min(page + 1, pages.length - 1)];
  const lift = Math.sin(flip * Math.PI);
  return (
    <g>
      <rect x={4} y={6} width={width} height={height} rx={6} fill="rgba(40,50,60,0.18)" />
      {flip > 0 ? <Page label={next} palette={palette} crossed={crossedFor ? crossedFor(page + 1) : 0} /> : null}
      <g transform={`translate(0 ${-lift * 10}) scale(1 ${Math.max(0.001, 1 - flip)})`} opacity={1 - flip * 0.4}>
        <Page label={current} palette={palette} circle={circle} circleProgress={circleProgress} crossed={crossedFor ? crossedFor(page) : 0} />
        {flip > 0 ? <rect x={0} y={0} width={width} height={height} rx={6} fill="#000" opacity={flip * 0.25} /> : null}
      </g>
      {[30, 64, 104, 138].map((rx) => (
        <rect key={rx} x={rx} y={-7} width={6} height={16} rx={3} fill="#7b8590" />
      ))}
    </g>
  );
};
