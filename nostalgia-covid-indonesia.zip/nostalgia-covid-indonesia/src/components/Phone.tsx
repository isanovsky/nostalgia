import React from "react";
import { AbsoluteFill, interpolate } from "remotion";
import { CLAMP, EASE_OUT } from "../lib/anim";
import { shade, tint } from "../lib/color";
import { FONT_STACK, Palette } from "../theme";

export type PhoneNotification = { app: string; text: string; at: number; icon?: "chat" | "video" };

type PhoneProps = {
  palette: Palette;
  frame: number;
  time: string;
  date: string;
  notifications: PhoneNotification[];
  /** Length of the shot in frames, drives the slow push-in. */
  duration: number;
};

const Card: React.FC<{ n: PhoneNotification; frame: number; palette: Palette; y: number }> = ({ n, frame, palette, y }) => {
  const t = interpolate(frame, [n.at, n.at + 16], [0, 1], { ...CLAMP, easing: EASE_OUT });
  if (t <= 0) return null;
  return (
    <div
      style={{
        position: "absolute",
        left: 34,
        right: 34,
        top: y,
        opacity: t,
        translate: `0px ${(1 - t) * -60}px`,
        scale: String(0.96 + t * 0.04),
        backgroundColor: "rgba(255,255,255,0.9)",
        borderRadius: 30,
        padding: "24px 26px",
        display: "flex",
        gap: 20,
        boxShadow: "0 18px 40px rgba(20,30,45,0.22)",
      }}
    >
      <div
        style={{
          width: 70,
          height: 70,
          borderRadius: 18,
          backgroundColor: n.icon === "video" ? "#e53935" : palette.teal,
          flexShrink: 0,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        {n.icon === "video" ? (
          <div style={{ width: 0, height: 0, borderTop: "14px solid transparent", borderBottom: "14px solid transparent", borderLeft: "24px solid #ffffff", marginLeft: 6 }} />
        ) : (
          <div style={{ width: 38, height: 30, borderRadius: 12, backgroundColor: "#ffffff" }} />
        )}
      </div>
      <div style={{ fontFamily: FONT_STACK, color: palette.uiDark, flex: 1 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
          <span style={{ fontWeight: 800, fontSize: 32 }}>{n.app}</span>
          <span style={{ fontWeight: 400, fontSize: 24, opacity: 0.6 }}>sekarang</span>
        </div>
        <div style={{ fontWeight: 600, fontSize: 34, lineHeight: 1.25, marginTop: 6 }}>{n.text}</div>
      </div>
    </div>
  );
};

/** Close-up of a hand-held 2020-era phone receiving group-chat notifications. */
export const Phone: React.FC<PhoneProps> = ({ palette, frame, time, date, notifications, duration }) => {
  const push = interpolate(frame, [0, duration], [1, 1.07], CLAMP);
  const bob = Math.sin(frame * 0.05) * 4;
  return (
    <AbsoluteFill>
      {/* out-of-focus living room behind */}
      <AbsoluteFill
        style={{
          background: `linear-gradient(180deg, ${palette.interiorWall} 0%, ${palette.interiorWallSide} 55%, ${palette.floor} 100%)`,
        }}
      />
      {[
        [160, 380, 140, palette.windowLit],
        [900, 300, 190, palette.sun],
        [820, 1500, 160, palette.fabric],
        [120, 1300, 120, palette.pink],
        [540, 200, 100, palette.cream],
      ].map(([x, y, r, c], i) => (
        <div
          key={i}
          style={{
            position: "absolute",
            left: (x as number) - (r as number),
            top: (y as number) - (r as number),
            width: (r as number) * 2,
            height: (r as number) * 2,
            borderRadius: "50%",
            backgroundColor: c as string,
            opacity: 0.35,
          }}
        />
      ))}
      <AbsoluteFill style={{ scale: String(push), translate: `0px ${bob}px` }}>
        {/* hand */}
        <div
          style={{
            position: "absolute",
            left: 210,
            top: 1240,
            width: 660,
            height: 760,
            borderRadius: "46% 46% 20% 20%",
            backgroundColor: palette.skin,
          }}
        />
        <div
          style={{
            position: "absolute",
            left: 250,
            top: 400,
            width: 580,
            height: 1180,
            borderRadius: 70,
            backgroundColor: "#1d242c",
            boxShadow: "0 40px 80px rgba(20,30,45,0.35)",
            padding: 18,
          }}
        >
          <div
            style={{
              position: "relative",
              width: "100%",
              height: "100%",
              borderRadius: 54,
              overflow: "hidden",
              background: `linear-gradient(170deg, ${tint(palette.skyTop, 0.1)} 0%, ${palette.pink} 60%, ${shade(palette.pink, 0.2)} 100%)`,
            }}
          >
            <div style={{ position: "absolute", left: "50%", top: 22, width: 22, height: 22, marginLeft: -11, borderRadius: "50%", backgroundColor: "#11161b" }} />
            <div
              style={{
                position: "absolute",
                top: 110,
                width: "100%",
                textAlign: "center",
                fontFamily: FONT_STACK,
                color: "#ffffff",
                textShadow: "0 3px 12px rgba(20,30,45,0.25)",
              }}
            >
              <div style={{ fontSize: 30, fontWeight: 600 }}>{date}</div>
              <div style={{ fontSize: 150, fontWeight: 800, letterSpacing: -2, lineHeight: 1.05 }}>{time}</div>
            </div>
            {notifications.map((n, i) => (
              <Card key={i} n={n} frame={frame} palette={palette} y={400 + i * 225} />
            ))}
          </div>
        </div>
        {/* thumb */}
        <div
          style={{
            position: "absolute",
            left: 720,
            top: 1500,
            width: 150,
            height: 300,
            borderRadius: 80,
            rotate: "-28deg",
            backgroundColor: palette.skinShade,
          }}
        />
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
