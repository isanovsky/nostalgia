import React from "react";
import { AbsoluteFill, useVideoConfig } from "remotion";
import { cameraAt, CamKey } from "../lib/anim";

type CameraProps = {
  /** Camera keys over normalised shot progress `t` (0..1) or any monotonic value. */
  keys: CamKey[];
  t: number;
  /** Frame used for a barely-perceptible hand-held drift. 0 disables it. */
  driftFrame?: number;
  children: React.ReactNode;
};

/**
 * Frames a world-space layer: the point (x, y) of the world is placed at the
 * centre of the video and the world is scaled by `zoom`.
 */
export const Camera: React.FC<CameraProps> = ({ keys, t, driftFrame = 0, children }) => {
  const { width, height } = useVideoConfig();
  const cam = cameraAt(keys, t);
  const dx = driftFrame ? Math.sin(driftFrame * 0.021) * 3 + Math.sin(driftFrame * 0.047) * 1.5 : 0;
  const dy = driftFrame ? Math.cos(driftFrame * 0.017) * 2.5 : 0;
  return (
    <AbsoluteFill style={{ overflow: "hidden" }}>
      <div
        style={{
          position: "absolute",
          left: 0,
          top: 0,
          transformOrigin: "0 0",
          translate: `${width / 2 - cam.x * cam.zoom + dx}px ${height / 2 - cam.y * cam.zoom + dy}px`,
          scale: String(cam.zoom),
        }}
      >
        {children}
      </div>
    </AbsoluteFill>
  );
};

/** Returns the camera so sibling layers (sky parallax) can follow it. */
export const useCameraState = (keys: CamKey[], t: number) => cameraAt(keys, t);
