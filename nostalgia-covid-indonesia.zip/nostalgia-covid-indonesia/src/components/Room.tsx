import React from "react";
import { useVideoConfig } from "remotion";
import { fitFontSize, sway } from "../lib/anim";
import { shade, tint } from "../lib/color";
import { IsoProjector, makeIso } from "../lib/iso";
import { FONT_STACK, Palette } from "../theme";
import { IsoBox } from "./Building";
import { Calendar, CALENDAR_SIZE } from "./Calendar";
import { Tree } from "./Tree";

/** Interior iso projection: a 5 x 5 room that fills a 1080-wide frame. */
export const ROOM_ISO = makeIso(200, 100, 540, 520);
export const ROOM_SIZE = 5;
export const ROOM_WALL_H = 420;

const rp = (x: number, y: number, z = 0) => {
  const [a, b] = ROOM_ISO.p(x, y, z);
  return { x: a, y: b };
};

/** Camera / placement anchors inside the room (world px). */
export const ROOM_ANCHORS = {
  center: { x: 540, y: 600 },
  sofaSeat: rp(0.85, 3.6),
  deskSeat: rp(3.0, 1.55),
  tv: rp(1.0, 0.18, 150),
  calendar: rp(0, 1.65, 300),
  window: rp(2.85, 0, 255),
  desk: rp(3.4, 2.5, 90),
} as const;

/** Floor slab + two cut-away walls. Shared by the home and the classroom. */
export const RoomShell: React.FC<{ iso: IsoProjector; palette: Palette; size: number; wallH: number; wallColor?: string; floorColor?: string }> = ({
  iso,
  palette,
  size,
  wallH,
  wallColor,
  floorColor,
}) => {
  const { p, pts } = iso;
  const wall = wallColor ?? palette.interiorWall;
  const floor = floorColor ?? palette.floor;
  const slab = 34;
  const boards: React.ReactNode[] = [];
  for (let i = 1; i < size * 2; i++) {
    const [x1, y1] = p(i / 2, 0);
    const [x2, y2] = p(i / 2, size);
    boards.push(<line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke={palette.floorShade} strokeWidth={2} opacity={0.45} />);
  }
  return (
    <g>
      {/* slab edges (diorama look) */}
      <polygon points={pts(p(0, size), p(size, size), p(size, size, -slab), p(0, size, -slab))} fill={shade(floor, 0.35)} />
      <polygon points={pts(p(size, 0), p(size, size), p(size, size, -slab), p(size, 0, -slab))} fill={shade(floor, 0.2)} />
      <polygon points={pts(p(0, 0), p(size, 0), p(size, size), p(0, size))} fill={floor} />
      {boards}
      {/* left wall (x = 0 plane) */}
      <polygon points={pts(p(0, 0), p(0, size), p(0, size, wallH), p(0, 0, wallH))} fill={palette.interiorWallSide} />
      {/* right wall (y = 0 plane) */}
      <polygon points={pts(p(0, 0), p(size, 0), p(size, 0, wallH), p(0, 0, wallH))} fill={wall} />
      {/* painterly wash */}
      <polygon points={pts(p(0.3, 0, wallH * 0.7), p(size * 0.8, 0, wallH * 0.75), p(size * 0.8, 0, wallH * 0.82), p(0.3, 0, wallH * 0.78))} fill={tint(wall, 0.5)} opacity={0.25} />
      <polygon points={pts(p(0, size * 0.85, wallH * 0.62), p(0, 0.4, wallH * 0.66), p(0, 0.4, wallH * 0.7), p(0, size * 0.85, wallH * 0.67))} fill={tint(palette.interiorWallSide, 0.5)} opacity={0.22} />
      {/* baseboards */}
      <polygon points={pts(p(0, 0, 0), p(size, 0, 0), p(size, 0, 14), p(0, 0, 14))} fill={palette.woodDark} opacity={0.7} />
      <polygon points={pts(p(0, 0, 0), p(0, size, 0), p(0, size, 14), p(0, 0, 14))} fill={palette.woodDark} opacity={0.8} />
      {/* wall rims */}
      <polygon points={pts(p(-0.08, -0.08, wallH), p(size, -0.08, wallH), p(size, 0, wallH), p(0, 0, wallH), p(0, size, wallH), p(-0.08, size, wallH))} fill={tint(wall, 0.4)} />
      <polygon points={pts(p(size, -0.08, wallH), p(size, 0, wallH), p(size, 0, 0), p(size, -0.08, 0))} fill={shade(wall, 0.15)} />
      <polygon points={pts(p(-0.08, size, wallH), p(0, size, wallH), p(0, size, 0), p(-0.08, size, 0))} fill={shade(palette.interiorWallSide, 0.25)} />
    </g>
  );
};

/** Window on the y = 0 wall showing the sky outside; casts a sunbeam on the floor. */
const RoomWindow: React.FC<{ palette: Palette; daylight: number; frame: number; x0: number; x1: number; z0: number; z1: number }> = ({
  palette,
  daylight,
  frame,
  x0,
  x1,
  z0,
  z1,
}) => {
  const { p, pts } = ROOM_ISO;
  const curtain = sway(frame, 0.04, 2) * 0.04;
  const midX = (x0 + x1) / 2;
  const midZ = (z0 + z1) / 2;
  const [cx, cy] = p(midX + 0.25, 0, midZ + 30);
  return (
    <g>
      <polygon points={pts(p(x0, 0, z0), p(x1, 0, z0), p(x1, 0, z1), p(x0, 0, z1))} fill={palette.skyBottom} />
      <polygon points={pts(p(x0, 0, midZ), p(x1, 0, midZ), p(x1, 0, z1), p(x0, 0, z1))} fill={palette.skyTop} opacity={0.75} />
      {/* sun or moon */}
      <circle cx={cx} cy={cy} r={14} fill={palette.sun} opacity={0.9} />
      {/* distant rooftops */}
      <polygon points={pts(p(x0, 0, z0), p(x0, 0, z0 + 40), p(x0 + 0.4, 0, z0 + 40), p(x0 + 0.4, 0, z0 + 60), p(x0 + 0.8, 0, z0 + 60), p(x0 + 0.8, 0, z0 + 30), p(x1, 0, z0 + 30), p(x1, 0, z0))} fill={palette.hillNear} opacity={0.8} />
      {/* frame */}
      <g fill="none" stroke={palette.cream} strokeWidth={8}>
        <polygon points={pts(p(x0, 0, z0), p(x1, 0, z0), p(x1, 0, z1), p(x0, 0, z1))} />
      </g>
      <line x1={p(midX, 0, z0)[0]} y1={p(midX, 0, z0)[1]} x2={p(midX, 0, z1)[0]} y2={p(midX, 0, z1)[1]} stroke={palette.cream} strokeWidth={6} />
      <polygon points={pts(p(x0 - 0.05, 0.03, z0 - 4), p(x1 + 0.05, 0.03, z0 - 4), p(x1 + 0.05, 0.16, z0), p(x0 - 0.05, 0.16, z0))} fill={palette.cream} />
      {/* curtains */}
      <polygon points={pts(p(x0 - 0.25, 0.02, z1 + 10), p(x0 + 0.12 + curtain, 0.02, z1 + 10), p(x0 + 0.02 + curtain * 2, 0.02, z0 - 30), p(x0 - 0.3, 0.02, z0 - 30))} fill={palette.pink} opacity={0.9} />
      <polygon points={pts(p(x1 - 0.12 - curtain, 0.02, z1 + 10), p(x1 + 0.25, 0.02, z1 + 10), p(x1 + 0.3, 0.02, z0 - 30), p(x1 - 0.02 - curtain * 2, 0.02, z0 - 30))} fill={palette.pink} opacity={0.9} />
      {/* sunbeam on the floor */}
      <polygon
        points={pts(p(x0 + 0.1, 0.1, 0), p(x1 + 0.1, 0.1, 0), p(x1 + 0.9, 2.4, 0), p(x0 + 0.9, 2.4, 0))}
        fill={palette.sunbeam}
        opacity={daylight}
      />
    </g>
  );
};

const WallClock: React.FC<{ palette: Palette; hourAngle: number; minuteAngle: number }> = ({ palette, hourAngle, minuteAngle }) => (
  <g transform={ROOM_ISO.faceX(1.0, 0, 340)}>
    <circle cx={0} cy={0} r={30} fill={palette.cream} stroke={palette.woodDark} strokeWidth={5} />
    {Array.from({ length: 12 }).map((_, i) => (
      <circle key={i} cx={Math.sin((i / 12) * Math.PI * 2) * 23} cy={-Math.cos((i / 12) * Math.PI * 2) * 23} r={1.6} fill={palette.blueGray} />
    ))}
    <line x1={0} y1={0} x2={Math.sin(hourAngle) * 14} y2={-Math.cos(hourAngle) * 14} stroke={palette.uiDark} strokeWidth={3.5} strokeLinecap="round" />
    <line x1={0} y1={0} x2={Math.sin(minuteAngle) * 21} y2={-Math.cos(minuteAngle) * 21} stroke={palette.uiDark} strokeWidth={2.2} strokeLinecap="round" />
    <circle cx={0} cy={0} r={2.5} fill={palette.accent} />
  </g>
);

export type TvContent = "program" | "news" | "off";

/** Split a headline into at most two balanced lines. */
const twoLines = (text: string): string[] => {
  const words = text.split(" ");
  if (words.length < 3) return [text];
  let best = 1;
  let bestDiff = Infinity;
  for (let i = 1; i < words.length; i++) {
    const diff = Math.abs(words.slice(0, i).join(" ").length - words.slice(i).join(" ").length);
    if (diff < bestDiff) {
      bestDiff = diff;
      best = i;
    }
  }
  return [words.slice(0, best).join(" "), words.slice(best).join(" ")];
};

const Television: React.FC<{ palette: Palette; content: TvContent; frame: number; label: string; headline: string }> = ({
  palette,
  content,
  frame,
  label,
  headline,
}) => {
  const iso = ROOM_ISO;
  const sw = 1.4 * iso.unit;
  const sh = 144;
  const pad = 7;
  const flicker = 0.92 + Math.sin(frame * 0.9) * 0.03;
  const lines = twoLines(headline);
  const headSize = Math.min(...lines.map((l) => fitFontSize(l, sw - pad * 2, 15)));
  const labelSize = fitFontSize(label, sw * 0.62 - pad * 2, 11, 0.7, 1);
  const barH = lines.length * headSize * 1.2 + 14;
  return (
    <g>
      <IsoBox iso={iso} x={0.18} y={0.02} w={1.64} d={0.42} h={56} color={palette.wood} />
      <IsoBox iso={iso} x={0.24} y={0.08} w={1.52} d={0.08} h={164} z0={68} color={palette.uiDark} />
      <g transform={iso.faceX(0.3, 0.16, 222)}>
        <rect x={0} y={0} width={sw} height={sh} fill={content === "off" ? "#1e2730" : palette.screen} />
        {content === "program" ? (
          <g opacity={flicker}>
            <rect x={0} y={0} width={sw} height={sh * 0.6} fill={palette.skyTop} />
            <rect x={0} y={sh * 0.6} width={sw} height={sh * 0.4} fill={palette.treeLight} />
            <circle cx={sw * 0.7} cy={sh * 0.3} r={16} fill={palette.sun} />
            <polygon points={`0,${sh * 0.62} ${sw * 0.3},${sh * 0.35} ${sw * 0.55},${sh * 0.62}`} fill={palette.hillNear} />
          </g>
        ) : null}
        {content === "news" ? (
          <g opacity={flicker}>
            <rect x={0} y={0} width={sw} height={sh} fill="#22344a" />
            <rect x={sw * 0.34} y={10} width={sw * 0.32} height={sh - barH - 30} rx={6} fill="#3c5674" />
            <circle cx={sw * 0.5} cy={28} r={11} fill={palette.skinShade} />
            <rect x={sw * 0.42} y={40} width={sw * 0.16} height={Math.max(8, sh - barH - 62)} rx={6} fill="#cfd8e2" />
            <rect x={0} y={sh - barH - 16} width={sw * 0.62} height={16} fill="#d64541" />
            <text x={pad} y={sh - barH - 4} fontFamily={FONT_STACK} fontWeight={800} fontSize={labelSize} fill="#ffffff" letterSpacing={1}>
              {label}
            </text>
            <rect x={0} y={sh - barH} width={sw} height={barH} fill="#ffffff" />
            {lines.map((line, i) => (
              <text key={i} x={pad} y={sh - barH + 7 + headSize * (i + 1) * 1.05} fontFamily={FONT_STACK} fontWeight={800} fontSize={headSize} fill="#1f2a36">
                {line}
              </text>
            ))}
          </g>
        ) : null}
        <rect x={0} y={0} width={sw} height={sh} fill="url(#tv-gloss)" opacity={0.25} />
      </g>
      {content !== "off" ? (
        <polygon
          points={iso.pts(iso.p(0.3, 0.2, 0), iso.p(1.7, 0.2, 0), iso.p(2.2, 1.9, 0), iso.p(0.1, 1.9, 0))}
          fill={content === "news" ? "#9fb7d6" : palette.screenGlow}
          opacity={0.08}
        />
      ) : null}
    </g>
  );
};

export type RoomProps = {
  palette: Palette;
  frame: number;
  /** 0 night .. 1 day, drives sunbeam and lamp. */
  daylight: number;
  tv: TvContent;
  tvLabel?: string;
  tvHeadline?: string;
  laptop: boolean;
  laptopGlow?: number;
  books: number;
  calendarPages: string[];
  calendarPage: number;
  calendarFlip?: number;
  calendarCircle?: [number, number];
  calendarCircleProgress?: number;
  calendarCrossed?: (page: number) => number;
  hourAngle: number;
  minuteAngle: number;
  plantGrowth?: number;
  /** Rendered on the sofa (between sofa and desk in depth). */
  onSofa?: React.ReactNode;
  /** Rendered behind the desk (character at the desk). */
  atDesk?: React.ReactNode;
};

/** The family living room / home office. Same layout in Scenes 01, 02 and 04. */
export const Room: React.FC<RoomProps> = ({
  palette,
  frame,
  daylight,
  tv,
  tvLabel = "",
  tvHeadline = "",
  laptop,
  laptopGlow = 0,
  books,
  calendarPages,
  calendarPage,
  calendarFlip = 0,
  calendarCircle,
  calendarCircleProgress,
  calendarCrossed,
  hourAngle,
  minuteAngle,
  plantGrowth = 0,
  onSofa,
  atDesk,
}) => {
  const { width, height } = useVideoConfig();
  const iso = ROOM_ISO;
  const { p, pts } = iso;
  const lamp = 1 - daylight;
  const [lx, ly] = p(2.73, 2.23, 150);
  const [px, py] = p(4.55, 4.55);

  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} style={{ overflow: "visible" }}>
      <defs>
        <linearGradient id="tv-gloss" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#ffffff" stopOpacity={0.6} />
          <stop offset="0.5" stopColor="#ffffff" stopOpacity={0} />
        </linearGradient>
        <radialGradient id="lamp-glow">
          <stop offset="0" stopColor={palette.windowLit} stopOpacity={0.55} />
          <stop offset="1" stopColor={palette.windowLit} stopOpacity={0} />
        </radialGradient>
        <linearGradient id="room-backdrop" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={shade(palette.skyBottom, 0.15)} />
          <stop offset="1" stopColor={shade(palette.interiorWallSide, 0.35)} />
        </linearGradient>
      </defs>
      <rect x={-2000} y={-2000} width={width + 4000} height={height + 4000} fill="url(#room-backdrop)" />
      <RoomShell iso={iso} palette={palette} size={ROOM_SIZE} wallH={ROOM_WALL_H} />
      {/* rug */}
      <polygon points={pts(p(1.4, 2.9), p(3.2, 2.9), p(3.2, 4.5), p(1.4, 4.5))} fill={palette.fabric} opacity={0.55} />
      <polygon points={pts(p(1.55, 3.05), p(3.05, 3.05), p(3.05, 4.35), p(1.55, 4.35))} fill="none" stroke={palette.cream} strokeWidth={3} opacity={0.5} />

      <RoomWindow palette={palette} daylight={daylight} frame={frame} x0={2.15} x1={3.55} z0={170} z1={350} />
      <WallClock palette={palette} hourAngle={hourAngle} minuteAngle={minuteAngle} />

      {/* calendar on the left wall */}
      <g transform={iso.faceY(0, 2.4, 410)}>
        <g transform={`scale(${(1.5 * iso.unit) / CALENDAR_SIZE.width} 1)`}>
          <Calendar
            palette={palette}
            pages={calendarPages}
            page={calendarPage}
            flip={calendarFlip}
            circle={calendarCircle}
            circleProgress={calendarCircleProgress}
            crossedFor={calendarCrossed}
          />
        </g>
      </g>

      {/* bookshelf (right wall, front end) */}
      <IsoBox iso={iso} x={4.3} y={0.02} w={0.62} d={0.42} h={250} color={palette.wood} />
      {[40, 100, 160, 220].map((z, i) => (
        <g key={z}>
          {[0, 1, 2, 3].map((j) => (
            <polygon
              key={j}
              points={pts(p(4.36 + j * 0.13, 0.44, z), p(4.44 + j * 0.13, 0.44, z), p(4.44 + j * 0.13, 0.44, z + 38 - (j % 2) * 8), p(4.36 + j * 0.13, 0.44, z + 38 - (j % 2) * 8))}
              fill={[palette.teal, palette.pink, palette.car2, palette.car3][(i + j) % 4]}
            />
          ))}
        </g>
      ))}

      <Television palette={palette} content={tv} frame={frame} label={tvLabel} headline={tvHeadline} />

      {/* sofa against the left wall */}
      <IsoBox iso={iso} x={0.04} y={2.7} w={0.3} d={1.8} h={118} color={palette.fabricDark} />
      <IsoBox iso={iso} x={0.34} y={2.7} w={0.65} d={1.8} h={44} color={palette.fabric} />
      <IsoBox iso={iso} x={0.04} y={2.55} w={0.95} d={0.2} h={74} color={palette.fabricDark} />
      <IsoBox iso={iso} x={0.36} y={3.0} w={0.26} d={0.5} h={40} z0={44} color={palette.pink} />
      {onSofa}
      <IsoBox iso={iso} x={0.04} y={4.45} w={0.95} d={0.2} h={74} color={palette.fabricDark} />

      {/* chair behind the desk */}
      <IsoBox iso={iso} x={2.75} y={1.05} w={0.55} d={0.12} h={120} z0={40} color={palette.blueGray} />
      <IsoBox iso={iso} x={2.75} y={1.1} w={0.55} d={0.55} h={10} z0={42} color={palette.blueGray} />
      {atDesk}

      {/* desk */}
      <IsoBox iso={iso} x={2.55} y={2.15} w={0.1} d={0.7} h={88} color={palette.woodDark} />
      <IsoBox iso={iso} x={2.55} y={2.78} w={1.7} d={0.08} h={70} z0={18} color={palette.woodDark} />
      <IsoBox iso={iso} x={4.15} y={2.15} w={0.1} d={0.7} h={88} color={palette.woodDark} />
      <IsoBox iso={iso} x={2.5} y={2.1} w={1.8} d={0.8} h={8} z0={88} color={palette.wood} />
      {/* desk lamp */}
      <IsoBox iso={iso} x={2.65} y={2.15} w={0.16} d={0.16} h={6} z0={96} color={palette.blueGray} />
      <line x1={p(2.73, 2.23, 100)[0]} y1={p(2.73, 2.23, 100)[1]} x2={lx} y2={ly} stroke={palette.blueGray} strokeWidth={4} />
      <circle cx={lx} cy={ly} r={12} fill={lamp > 0.3 ? palette.windowLit : palette.cream} />
      <circle cx={lx} cy={ly + 30} r={150} fill="url(#lamp-glow)" opacity={lamp} />
      {/* books on the desk */}
      {Array.from({ length: Math.max(0, Math.round(books)) }).map((_, i) => (
        <IsoBox
          key={i}
          iso={iso}
          x={2.95 + (i % 2) * 0.03}
          y={2.42 + (i % 3) * 0.02}
          w={0.38}
          d={0.3}
          h={11}
          z0={96 + i * 11}
          color={[palette.teal, palette.pink, palette.car2, palette.car3, palette.cream][i % 5]}
        />
      ))}
      {/* mug */}
      <IsoBox iso={iso} x={4.05} y={2.6} w={0.1} d={0.1} h={20} z0={96} color={palette.cream} />
      {/* laptop: base and lid facing the person at the desk */}
      {laptop ? (
        <g>
          <IsoBox iso={iso} x={3.55} y={2.13} w={0.58} d={0.42} h={5} z0={96} color={palette.gray} />
          <IsoBox iso={iso} x={3.55} y={2.51} w={0.58} d={0.04} h={70} z0={100} color={tint(palette.gray, 0.1)} />
          <circle cx={p(3.84, 2.55, 138)[0]} cy={p(3.84, 2.55, 138)[1]} r={6} fill={palette.cream} opacity={0.8} />
          {laptopGlow > 0 ? (
            <ellipse cx={p(3.0, 1.7, 160)[0]} cy={p(3.0, 1.7, 160)[1]} rx={110} ry={70} fill={palette.screenGlow} opacity={laptopGlow * 0.18} />
          ) : null}
        </g>
      ) : null}
      {/* potted plant in the front corner */}
      <IsoBox iso={iso} x={4.35} y={4.35} w={0.4} d={0.4} h={50} color={palette.roofRed} />
      <Tree bx={px} by={py - 48} size={1.6 + plantGrowth * 0.8} palette={palette} frame={frame} seed={7} kind="round" wind={0.3} />
    </svg>
  );
};
