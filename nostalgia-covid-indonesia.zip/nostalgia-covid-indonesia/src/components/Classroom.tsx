import React from "react";
import { useVideoConfig } from "remotion";
import { fitFontSize, smoothstep } from "../lib/anim";
import { shade } from "../lib/color";
import { makeIso } from "../lib/iso";
import { FONT_STACK, Palette } from "../theme";
import { IsoBox } from "./Building";
import { castOutfits, Character } from "./Character";
import { RoomShell } from "./Room";

export const CLASS_ISO = makeIso(180, 90, 540, 600);
const SIZE = 5;
const WALL_H = 360;

const DESKS = [1.6, 2.8, 4.0].flatMap((y, row) => [1.0, 2.2, 3.4].map((x, col) => ({ x, y, row, col })));
/** Order in which seats empty (scattered, not row by row). */
const LEAVE_ORDER = [4, 0, 7, 2, 8, 5, 1, 6, 3];

type ClassroomProps = {
  palette: Palette;
  frame: number;
  board: string;
  /** Frames (local) where children start / finish leaving. */
  emptyFrom: number;
  emptyTo: number;
};

export const Classroom: React.FC<ClassroomProps> = ({ palette, frame, board, emptyFrom, emptyTo }) => {
  const { width, height } = useVideoConfig();
  const iso = CLASS_ISO;
  const { p, pts } = iso;
  const cast = castOutfits(palette);
  const step = (emptyTo - emptyFrom) / DESKS.length;

  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} style={{ overflow: "visible" }}>
      <rect x={-2000} y={-2000} width={width + 4000} height={height + 4000} fill={shade(palette.skyBottom, 0.12)} />
      <RoomShell iso={iso} palette={palette} size={SIZE} wallH={WALL_H} wallColor={palette.cream} floorColor={palette.beige} />
      {/* windows on the left wall */}
      {[0.6, 2.6].map((y0) => (
        <g key={y0}>
          <polygon points={pts(p(0, y0, 150), p(0, y0 + 1.4, 150), p(0, y0 + 1.4, 300), p(0, y0, 300))} fill={palette.skyTop} />
          <polygon points={pts(p(0, y0, 150), p(0, y0 + 1.4, 150), p(0, y0 + 1.4, 300), p(0, y0, 300))} fill="none" stroke={palette.cream} strokeWidth={7} />
          <polygon points={pts(p(0.05, y0, 0), p(0.05, y0 + 1.4, 0), p(1.6, y0 + 1.6, 0), p(1.6, y0 + 0.2, 0))} fill={palette.sunbeam} />
        </g>
      ))}
      {/* whiteboard */}
      <polygon points={pts(p(0.9, 0, 140), p(3.9, 0, 140), p(3.9, 0, 300), p(0.9, 0, 300))} fill="#fbfbf7" stroke={palette.blueGray} strokeWidth={6} />
      <g transform={iso.faceX(2.4, 0, 230)}>
        <text x={0} y={0} textAnchor="middle" fontFamily={FONT_STACK} fontWeight={800} fontSize={fitFontSize(board, 3 * iso.unit - 40, 22, 0.68, 1)} fill={palette.uiDark} letterSpacing={1}>
          {board}
        </text>
        <line x1={-110} y1={16} x2={110} y2={16} stroke={palette.accent} strokeWidth={4} strokeLinecap="round" />
      </g>
      {/* flag and clock above the board */}
      <g transform={iso.faceX(4.3, 0, 300)}>
        <rect x={0} y={0} width={44} height={14} fill="#d9534f" />
        <rect x={0} y={14} width={44} height={14} fill="#fbf7f0" />
      </g>
      {/* teacher's desk */}
      <IsoBox iso={iso} x={3.6} y={0.35} w={1.0} d={0.5} h={70} color={palette.wood} />

      {DESKS.map((d, i) => {
        const order = LEAVE_ORDER.indexOf(i);
        const leaveAt = emptyFrom + order * step;
        const gone = smoothstep(leaveAt, leaveAt + step * 1.6, frame);
        const [sx, sy] = p(d.x + 0.35, d.y - 0.25);
        return (
          <g key={i}>
            <IsoBox iso={iso} x={d.x + 0.1} y={d.y - 0.55} w={0.5} d={0.08} h={60} z0={30} color={palette.blueGray} />
            {gone < 0.99 ? (
              <g opacity={1 - gone} transform={`translate(0 ${-gone * 30})`}>
                <Character
                  x={sx}
                  y={sy - 22}
                  scale={0.42}
                  outfit={cast.student(i)}
                  pose="sit"
                  expression={i % 3 === 0 ? "happy" : "neutral"}
                  headTurn={Math.sin(i * 2.1) * 0.6}
                  frame={frame}
                  seed={i * 7 + 3}
                  child
                  holding={i % 4 === 1 ? "books" : "none"}
                />
              </g>
            ) : null}
            <IsoBox iso={iso} x={d.x} y={d.y} w={0.7} d={0.42} h={6} z0={56} color={palette.wood} />
            <IsoBox iso={iso} x={d.x + 0.04} y={d.y + 0.36} w={0.62} d={0.05} h={50} z0={6} color={palette.woodDark} />
          </g>
        );
      })}
    </svg>
  );
};
