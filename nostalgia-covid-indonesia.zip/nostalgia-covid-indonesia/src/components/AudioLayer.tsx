import React from "react";
import { Audio } from "@remotion/media";
import { interpolate, Sequence, staticFile } from "remotion";
import { CLAMP } from "../lib/anim";
import { AmbienceCue, MUSIC, SCENES, sceneDuration, TOTAL_FRAMES, TRANSITION_FRAMES } from "../timing";

const envelope = (f: number, len: number, fadeIn: number, fadeOut: number) => {
  const a = Math.max(1, Math.min(fadeIn, len / 2 - 1));
  const b = Math.max(1, Math.min(fadeOut, len / 2 - 1));
  return interpolate(f, [0, a, len - b, len], [0, 1, 1, 0], CLAMP);
};

const Ambience: React.FC<{ cue: AmbienceCue }> = ({ cue }) => {
  const len = cue.to - cue.from;
  return (
    <Sequence from={cue.from} durationInFrames={len} name={cue.id} layout="none">
      <Audio src={staticFile(cue.file)} volume={(f) => cue.volume * envelope(f, len, cue.fadeIn, cue.fadeOut)} />
    </Sequence>
  );
};

/** Music bed + per-scene ambience and sound effects, all driven by timing.ts. */
export const AudioLayer: React.FC = () => (
  <>
    <Audio
      src={staticFile(MUSIC.file)}
      volume={(f) => MUSIC.volume * envelope(f, TOTAL_FRAMES, MUSIC.fadeIn, MUSIC.fadeOut)}
    />
    {SCENES.map((scene, i) => {
      const isLast = i === SCENES.length - 1;
      return (
        <Sequence
          key={scene.id}
          name={`audio-${scene.id}`}
          from={scene.from}
          durationInFrames={sceneDuration(scene) + (isLast ? 0 : TRANSITION_FRAMES)}
          layout="none"
        >
          {scene.ambience.map((cue) => (
            <Ambience key={cue.id} cue={cue} />
          ))}
          {scene.sfx.map((cue) => (
            <Sequence key={cue.id} name={cue.id} from={cue.at} durationInFrames={cue.duration} layout="none">
              <Audio src={staticFile(cue.file)} volume={cue.volume} />
            </Sequence>
          ))}
        </Sequence>
      );
    })}
  </>
);
