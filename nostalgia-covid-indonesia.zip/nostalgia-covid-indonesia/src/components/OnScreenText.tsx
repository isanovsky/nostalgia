import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { CLAMP, EASE_OUT } from "../lib/anim";
import { FONT_STACK, Palette, TYPE } from "../theme";
import { SAFE_AREA, SceneDef, TextCue } from "../timing";

const FADE = 12;

const CueText: React.FC<{ cue: TextCue; palette: Palette; frame: number }> = ({ cue, palette, frame }) => {
  if (frame < cue.from || frame > cue.to) return null;
  const style = TYPE[cue.variant];
  const fade = Math.min(FADE, (cue.to - cue.from) / 3);
  const opacity = interpolate(frame, [cue.from, cue.from + fade, cue.to - fade, cue.to], [0, 1, 1, 0], CLAMP);
  const rise = interpolate(frame, [cue.from, cue.from + 22], [22, 0], { ...CLAMP, easing: EASE_OUT });
  const spacing = interpolate(frame, [cue.from, cue.from + 40], [style.letterSpacing + 4, style.letterSpacing], {
    ...CLAMP,
    easing: EASE_OUT,
  });
  const color = cue.accent ? palette.accent : palette.text;
  const isBanner = cue.variant === "banner";
  const isNote = cue.variant === "note";

  return (
    <div
      style={{
        position: "absolute",
        left: SAFE_AREA.left,
        width: SAFE_AREA.right - SAFE_AREA.left,
        top: cue.y,
        display: "flex",
        justifyContent: "center",
        opacity,
        translate: `0px ${rise}px`,
      }}
    >
      <div
        style={{
          fontFamily: FONT_STACK,
          fontSize: style.size,
          fontWeight: style.weight,
          letterSpacing: spacing,
          lineHeight: 1.15,
          textAlign: "center",
          color: isNote ? palette.text : color,
          opacity: isNote ? 0.82 : 1,
          textShadow: isBanner ? "none" : `0 4px 18px ${palette.textShadow}, 0 2px 4px ${palette.textShadow}`,
          ...(isBanner
            ? {
                backgroundColor: "rgba(36, 48, 62, 0.88)",
                color: palette.ui,
                padding: "22px 30px",
                borderRadius: 18,
                borderLeft: `12px solid ${palette.accent}`,
                boxShadow: "0 18px 40px rgba(20, 30, 45, 0.3)",
              }
            : {}),
        }}
      >
        {cue.text}
      </div>
    </div>
  );
};

/** Renders every text cue of a scene from timing.ts. Must be placed inside the scene's Sequence. */
export const SceneTexts: React.FC<{ scene: SceneDef; palette: Palette; only?: string[] }> = ({
  scene,
  palette,
  only,
}) => {
  const frame = useCurrentFrame();
  const cues = only ? scene.texts.filter((c) => only.includes(c.id)) : scene.texts;
  return (
    <AbsoluteFill style={{ pointerEvents: "none" }}>
      {cues.map((cue) => (
        <CueText key={cue.id} cue={cue} palette={palette} frame={frame} />
      ))}
    </AbsoluteFill>
  );
};
