import React from "react";
import { IsoProjector } from "../lib/iso";
import { shade, tint } from "../lib/color";
import { IsoBox } from "./Building";
import { Palette } from "../theme";

export type VehicleKind = "car" | "angkot" | "motor" | "bus";

type IsoVehicleProps = {
  iso: IsoProjector;
  palette: Palette;
  /** Grid centre position. */
  x: number;
  y: number;
  axis: "x" | "y";
  kind: VehicleKind;
  color: string;
  opacity?: number;
  frame: number;
};

/**
 * Real-world sizes on the city grid: 1 grid unit = one two-lane road width (~7 m),
 * and ~8.8 px per metre of height. car 4.5 x 1.8 x 1.5 m, angkot 4.2 x 1.6 x 1.9 m,
 * motorbike 2 x 0.7 m, city bus 12 x 2.5 x 3.2 m.
 */
const DIMS: Record<VehicleKind, { len: number; wid: number; body: number; cabin: number }> = {
  car: { len: 0.64, wid: 0.26, body: 7, cabin: 6 },
  angkot: { len: 0.6, wid: 0.24, body: 16, cabin: 0 },
  motor: { len: 0.29, wid: 0.1, body: 5, cabin: 0 },
  bus: { len: 1.7, wid: 0.36, body: 28, cabin: 0 },
};

/** Low-poly vehicle on the isometric city grid. */
export const IsoVehicle: React.FC<IsoVehicleProps> = ({ iso, palette, x, y, axis, kind, color, opacity = 1, frame }) => {
  if (opacity <= 0.01) return null;
  const dim = DIMS[kind];
  const w = axis === "x" ? dim.len : dim.wid;
  const d = axis === "x" ? dim.wid : dim.len;
  const x0 = x - w / 2;
  const y0 = y - d / 2;
  const bob = Math.sin(frame * 0.6 + x * 3 + y * 5) * 0.4;
  const [sx, sy] = iso.p(x, y);
  return (
    <g opacity={opacity} transform={`translate(0 ${bob.toFixed(2)})`}>
      <ellipse cx={sx - 3} cy={sy + 2} rx={(w + d) * 32} ry={(w + d) * 12} fill={palette.shadow} />
      {kind === "motor" ? (
        <g>
          <IsoBox iso={iso} x={x0} y={y0} w={w} d={d} h={dim.body} z0={3} color={color} />
          {/* rider */}
          <ellipse cx={sx} cy={sy - 11} rx={2.6} ry={4} fill={palette.shirt} />
          <circle cx={sx} cy={sy - 16} r={2.7} fill={tint(color, 0.2)} />
        </g>
      ) : (
        <g>
          <IsoBox iso={iso} x={x0} y={y0} w={w} d={d} h={dim.body} z0={3} color={color} />
          {dim.cabin > 0 ? (
            <IsoBox
              iso={iso}
              x={x0 + w * 0.2}
              y={y0 + d * 0.12}
              w={w * 0.6}
              d={d * 0.76}
              h={dim.cabin}
              z0={3 + dim.body}
              color={palette.glass}
              topColor={tint(color, 0.15)}
            />
          ) : null}
          {kind !== "car" ? (
            // window band on the long sides
            <IsoBox
              iso={iso}
              x={x0 + (axis === "x" ? w * 0.08 : -0.005)}
              y={y0 + (axis === "x" ? -0.005 : d * 0.08)}
              w={axis === "x" ? w * 0.84 : w + 0.01}
              d={axis === "x" ? d + 0.01 : d * 0.84}
              h={dim.body * 0.32}
              z0={3 + dim.body * 0.55}
              color={palette.glass}
              topColor={tint(color, 0.3)}
            />
          ) : null}
        </g>
      )}
    </g>
  );
};

/** Three-car commuter train moving along +x. */
export const IsoTrain: React.FC<{ iso: IsoProjector; palette: Palette; head: number; y: number; opacity: number }> = ({
  iso,
  palette,
  head,
  y,
  opacity,
}) => {
  if (opacity <= 0.01) return null;
  const cars = [0, 1, 2];
  return (
    <g opacity={opacity}>
      {cars.map((i) => {
        const x0 = head - (i + 1) * 1.5;
        return (
          <g key={i}>
            <IsoBox iso={iso} x={x0} y={y} w={1.42} d={0.36} h={26} z0={4} color={palette.cream} topColor={palette.gray} />
            <IsoBox iso={iso} x={x0 + 0.06} y={y - 0.002} w={1.3} d={0.364} h={8} z0={16} color={palette.glass} topColor={palette.gray} />
            <IsoBox iso={iso} x={x0} y={y - 0.003} w={1.42} d={0.366} h={4} z0={8} color={palette.uniformRed} topColor={palette.uniformRed} />
          </g>
        );
      })}
    </g>
  );
};

/** Side-view car for the street (elevation) shots. Origin = ground under the car centre. */
export const SideCar: React.FC<{ x: number; y: number; color: string; palette: Palette; scale?: number; kind?: "car" | "angkot" }> = ({
  x,
  y,
  color,
  palette,
  scale = 1,
  kind = "car",
}) => (
  <g transform={`translate(${x} ${y}) scale(${scale})`}>
    <ellipse cx={0} cy={4} rx={130} ry={12} fill={palette.shadow} />
    {kind === "car" ? (
      <g>
        <path d="M -120 -20 L -120 -48 Q -116 -60 -100 -62 L -60 -64 L -32 -96 Q -24 -104 -10 -104 L 52 -104 Q 66 -104 74 -94 L 98 -64 L 112 -60 Q 124 -56 124 -42 L 124 -20 Z" fill={color} />
        <path d="M -48 -66 L -24 -94 L 8 -94 L 8 -66 Z" fill={palette.glass} />
        <path d="M 18 -66 L 18 -94 L 50 -94 Q 60 -94 66 -86 L 82 -66 Z" fill={palette.glass} />
        <rect x={-120} y={-44} width={244} height={8} fill={tint(color, 0.3)} opacity={0.6} />
      </g>
    ) : (
      <g>
        <path d="M -130 -20 L -130 -118 Q -130 -126 -122 -126 L 92 -126 Q 110 -126 118 -108 L 132 -70 L 132 -20 Z" fill={color} />
        {[-116, -66, -16, 34].map((wx) => (
          <rect key={wx} x={wx} y={-112} width={40} height={34} rx={5} fill={palette.glass} />
        ))}
        <path d="M 84 -112 L 104 -112 L 118 -78 L 84 -78 Z" fill={palette.glass} />
        <rect x={-130} y={-62} width={262} height={10} fill={tint(color, 0.35)} opacity={0.7} />
      </g>
    )}
    <rect x={-120} y={-26} width={244} height={8} fill={shade(color, 0.25)} />
    {[-72, 74].map((wx) => (
      <g key={wx}>
        <circle cx={wx} cy={-16} r={20} fill={palette.uiDark} />
        <circle cx={wx} cy={-16} r={9} fill={palette.gray} />
      </g>
    ))}
  </g>
);
