import { cancelRender, continueRender, delayRender, staticFile } from "remotion";
import { FONT_FAMILY, FONT_FILES } from "./theme";

/** Loads the bundled Plus Jakarta Sans (SIL OFL) before the first frame renders. */
const handle = delayRender("Loading Plus Jakarta Sans");

Promise.all(
  FONT_FILES.map((font) =>
    new FontFace(FONT_FAMILY, `url(${staticFile(font.file)}) format("woff2")`, { weight: font.weight }).load().then((face) => {
      document.fonts.add(face);
    }),
  ),
)
  .then(() => continueRender(handle))
  .catch((err) => cancelRender(err));
