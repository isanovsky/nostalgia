import { interpolateColors } from "remotion";

/**
 * Single source of truth for colour. Every component reads a `Palette`
 * (never a literal colour), so changing a value here restyles the film.
 *
 * Four moods are defined. Scenes blend between them with `mixPalette`.
 *  - day:    the default series palette (sky blue, soft green, teal, pink, beige)
 *  - muted:  desaturated, slightly dimmer - quiet / melancholic moments
 *  - night:  evening light used by the time-lapse (window light, city lamps)
 *  - warm:   golden, brighter - nostalgia and resolution
 */
export type Palette = {
  skyTop: string;
  skyBottom: string;
  haze: string;
  sun: string;
  cloud: string;
  hillFar: string;
  hillNear: string;

  ground: string;
  groundPatch: string;
  field: string;
  water: string;
  waterLight: string;

  road: string;
  roadLine: string;
  sidewalk: string;
  rail: string;

  teal: string;
  pink: string;
  beige: string;
  gray: string;
  blueGray: string;
  cream: string;
  roofRed: string;
  roofTeal: string;
  glass: string;
  windowLit: string;

  treeLight: string;
  treeDark: string;
  trunk: string;

  interiorWall: string;
  interiorWallSide: string;
  floor: string;
  floorShade: string;
  wood: string;
  woodDark: string;
  fabric: string;
  fabricDark: string;
  screen: string;
  screenGlow: string;
  sunbeam: string;

  skin: string;
  skinShade: string;
  hair: string;
  shirt: string;
  shirtShade: string;
  pants: string;
  uniformWhite: string;
  uniformRed: string;

  car1: string;
  car2: string;
  car3: string;

  shadow: string;
  text: string;
  textShadow: string;
  accent: string;
  accentSoft: string;
  ui: string;
  uiDark: string;
  /** Full-frame colour grade laid over each shot. */
  grade: string;
  vignette: string;
};

const day: Palette = {
  skyTop: "#7fb8e6",
  skyBottom: "#cfe6f1",
  haze: "rgba(236, 244, 246, 0.55)",
  sun: "#fff3d1",
  cloud: "#fbfdff",
  hillFar: "#a9cdbf",
  hillNear: "#8fbf9f",

  ground: "#a7d08e",
  groundPatch: "#97c482",
  field: "#b7dc95",
  water: "#79c0cf",
  waterLight: "#c7ecf1",

  road: "#6f7a84",
  roadLine: "#f2ede0",
  sidewalk: "#e7dcc6",
  rail: "#8b7f74",

  teal: "#5fa8a0",
  pink: "#f0a9b4",
  beige: "#ecdcbf",
  gray: "#b9c0c6",
  blueGray: "#55687a",
  cream: "#fbf3e2",
  roofRed: "#d9786c",
  roofTeal: "#4f8f8a",
  glass: "#a9d6e8",
  windowLit: "#ffe3a0",

  treeLight: "#7fc27a",
  treeDark: "#4f9a64",
  trunk: "#8a6a50",

  interiorWall: "#f3e6d3",
  interiorWallSide: "#e4d2bb",
  floor: "#d8b68f",
  floorShade: "#c49e78",
  wood: "#b98a62",
  woodDark: "#8f6646",
  fabric: "#6fa6a3",
  fabricDark: "#548985",
  screen: "#2f3c4a",
  screenGlow: "#9fd3e6",
  sunbeam: "rgba(255, 238, 190, 0.35)",

  skin: "#e9b894",
  skinShade: "#d39c79",
  hair: "#3a2c28",
  shirt: "#5f9fb0",
  shirtShade: "#4a8496",
  pants: "#4a5868",
  uniformWhite: "#f7f5ef",
  uniformRed: "#c8574f",

  car1: "#e57f6f",
  car2: "#f2c46d",
  car3: "#78a9d6",

  shadow: "rgba(40, 60, 80, 0.22)",
  text: "#fffaf0",
  textShadow: "rgba(20, 30, 45, 0.45)",
  accent: "#ffb37a",
  accentSoft: "#ffd9b8",
  ui: "#ffffff",
  uiDark: "#2b3946",
  grade: "rgba(255, 240, 220, 0.06)",
  vignette: "rgba(30, 40, 60, 0.28)",
};

const muted: Palette = {
  ...day,
  skyTop: "#9fb4c3",
  skyBottom: "#d6dde0",
  haze: "rgba(222, 228, 232, 0.6)",
  sun: "#eef0ea",
  cloud: "#eef2f4",
  hillFar: "#a9bbb5",
  hillNear: "#97ada2",

  ground: "#a7b99c",
  groundPatch: "#9aae90",
  field: "#b1c2a2",
  water: "#8eb3bb",
  waterLight: "#c9dde0",

  road: "#7a8188",
  sidewalk: "#dcd5c8",

  teal: "#7ea19d",
  pink: "#d6b0b4",
  beige: "#ddd2c0",
  gray: "#b4b9bd",
  blueGray: "#5e6b77",
  roofRed: "#bf8a83",
  roofTeal: "#6d8f8c",
  glass: "#b4c9d1",

  treeLight: "#93b48f",
  treeDark: "#6c8f74",

  interiorWall: "#e6ddd1",
  interiorWallSide: "#d5c9b9",
  floor: "#c8b096",
  floorShade: "#b39b82",
  fabric: "#839e9c",
  fabricDark: "#6b8785",
  sunbeam: "rgba(240, 236, 220, 0.22)",

  car1: "#c7958d",
  car2: "#d8c290",
  car3: "#93a9bf",

  shadow: "rgba(40, 50, 60, 0.2)",
  accent: "#f2b48c",
  grade: "rgba(150, 170, 185, 0.12)",
  vignette: "rgba(30, 40, 55, 0.34)",
};

const night: Palette = {
  ...muted,
  skyTop: "#2f3f63",
  skyBottom: "#6b6f93",
  haze: "rgba(90, 100, 140, 0.35)",
  sun: "#f6e7c4",
  cloud: "#8a90ad",
  interiorWall: "#a99fae",
  interiorWallSide: "#968ca0",
  floor: "#8f7f82",
  floorShade: "#7d6f74",
  wood: "#8d7066",
  woodDark: "#6c544d",
  fabric: "#647a8a",
  fabricDark: "#536676",
  screenGlow: "#bfe7ff",
  sunbeam: "rgba(160, 180, 230, 0.10)",
  skin: "#c9a08c",
  skinShade: "#b0887a",
  shirt: "#587f96",
  shirtShade: "#486c80",
  grade: "rgba(60, 70, 120, 0.16)",
  vignette: "rgba(15, 20, 40, 0.42)",
};

const warm: Palette = {
  ...day,
  skyTop: "#8fc0e4",
  skyBottom: "#ffe2bf",
  haze: "rgba(255, 232, 205, 0.5)",
  sun: "#fff0c4",
  cloud: "#fff6ea",
  hillFar: "#b9d3b1",
  hillNear: "#9fca98",
  ground: "#b5d68f",
  groundPatch: "#a6cc84",
  field: "#c6e09a",
  water: "#84c6cf",
  waterLight: "#e3f4ef",
  teal: "#62ada3",
  pink: "#f4adb3",
  beige: "#f1dcb8",
  roofRed: "#e27f68",
  treeLight: "#8bc977",
  treeDark: "#5aa065",
  sunbeam: "rgba(255, 222, 160, 0.42)",
  accent: "#ffb877",
  grade: "rgba(255, 205, 150, 0.12)",
  vignette: "rgba(70, 45, 30, 0.24)",
};

export const PALETTES = { day, muted, night, warm } as const;
export type PaletteName = keyof typeof PALETTES;

/** Blend two palettes key by key. `t` = 0 returns `a`, 1 returns `b`. */
export const mixPalette = (a: Palette, b: Palette, t: number): Palette => {
  const clamped = Math.min(1, Math.max(0, t));
  if (clamped <= 0) return a;
  if (clamped >= 1) return b;
  const out = {} as Palette;
  (Object.keys(a) as (keyof Palette)[]).forEach((key) => {
    out[key] = interpolateColors(clamped, [0, 1], [a[key], b[key]]);
  });
  return out;
};

export const FONT_FAMILY = "Plus Jakarta Sans";
export const FONT_STACK = `"${FONT_FAMILY}", "Helvetica Neue", Arial, sans-serif`;

export const FONT_FILES = [
  { weight: "400", file: "fonts/PlusJakartaSans-400.woff2" },
  { weight: "600", file: "fonts/PlusJakartaSans-600.woff2" },
  { weight: "800", file: "fonts/PlusJakartaSans-800.woff2" },
] as const;

export const TYPE = {
  headline: { size: 100, weight: 800, letterSpacing: 2 },
  subhead: { size: 64, weight: 800, letterSpacing: 1 },
  closing: { size: 84, weight: 800, letterSpacing: 1 },
  date: { size: 54, weight: 800, letterSpacing: 6 },
  caption: { size: 42, weight: 600, letterSpacing: 0.5 },
  tag: { size: 34, weight: 800, letterSpacing: 8 },
  note: { size: 26, weight: 400, letterSpacing: 0.5 },
  banner: { size: 46, weight: 800, letterSpacing: 0.5 },
  credit: { size: 32, weight: 600, letterSpacing: 0.3 },
} as const;
export type TextVariant = keyof typeof TYPE;
