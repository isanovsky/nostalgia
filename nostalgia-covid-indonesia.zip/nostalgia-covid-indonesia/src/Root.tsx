import React from "react";
import { Composition } from "remotion";
import "./fonts";
import { TwoWeeksToTwoYears } from "./Video";
import { COMPOSITION_ID, FPS, HEIGHT, TOTAL_FRAMES, WIDTH } from "./timing";

export const RemotionRoot: React.FC = () => (
  <Composition
    id={COMPOSITION_ID}
    component={TwoWeeksToTwoYears}
    durationInFrames={TOTAL_FRAMES}
    fps={FPS}
    width={WIDTH}
    height={HEIGHT}
  />
);
